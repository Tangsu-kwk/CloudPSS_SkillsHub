"""Caller-owned canvas edits; browser pixel viewports remain UI state."""

from copy import deepcopy

_OMITTED = object()

def _canvas_list(model):
    return model.revision.implements.diagram.canvas

def add_diagram_canvas(model, name):
    """Allocate the official collision-checked key and open the new canvas.

    Reproduces handler plus navigation selection, without inventing pixel pos.
    No save, computation or network access occurs.
    """
    if not isinstance(name, str):
        raise TypeError('name must be a string')
    canvases = _canvas_list(model)
    if not hasattr(model, 'context'):
        model.context = {}
    counter = model.context.setdefault('counter', {})
    number = counter.get('canvas_', 0)
    if type(number) is not int or number < 0:
        raise ValueError('Unsupported canvas counter state')
    while True:
        number += 1
        counter['canvas_'] = number
        key = f'canvas_{number}'
        if not any(c and c.get('key') == key for c in canvases):
            break
    canvases.append({'key': key, 'name': name})
    diagram = model.context.setdefault('diagram', {})
    opened = diagram.setdefault('openedCanvas', [])
    position = next((i for i, c in enumerate(opened) if c.get('key') == key), None)
    if position is None:
        opened.append({'key': key})
        position = len(opened) - 1
    diagram['currentCanvas'] = position
    return key

def update_diagram_canvas(model, key, name=_OMITTED):
    """Omitted name leaves it unchanged; empty names work; explicit null fails.

    Python uses TypeError for input validation, not MCP validation envelopes.
    SimStudio 5.0.39 rejects null despite its advertised input schema.
    """
    if not isinstance(key, str):
        raise TypeError("key must be a string")
    if name is not _OMITTED and not isinstance(name, str):
        raise TypeError("name must be a string; omit name to leave it unchanged")
    for canvas in _canvas_list(model):
        if canvas.get("key") == key:
            if name is not _OMITTED:
                canvas["name"] = name
            return None
    raise LookupError(f"panic: Canvas {key} not found")


def delete_diagram_canvas(model, key):
    """Delete a canvas and its own cells, following public action module 8415.

    No inferred cross-canvas cascade or pin rewrites: the official action deletes
    cells whose canvas equals key. Browser history/navigation is not reproduced.
    Invalid SDK state is rejected before any write.
    """
    if not isinstance(key, str):
        raise TypeError("Canvas key must be a string")
    diagram = model.revision.implements.diagram
    canvases = diagram.canvas
    if len(canvases) <= 1:
        raise ValueError("At least one canvas must be kept")
    index = next((i for i, c in enumerate(canvases) if c.get("key") == key), None)
    if index is None:
        raise LookupError("Canvas not found")
    cells = model.getAllComponents()
    selected = [(k, c.id) for k, c in cells.items() if getattr(c, "canvas", None) == key]
    context = deepcopy(model.context)
    view = context.get("diagram")
    if view is not None and not isinstance(view, dict):
        raise ValueError("Invalid diagram context")
    if view is not None and view.get("openedCanvas") is not None:
        opened = view["openedCanvas"]
        current = view.get("currentCanvas")
        if current is None:
            current = 0
        if (not isinstance(opened, list) or any(not isinstance(c, dict) for c in opened)
                or type(current) is not int):
            raise ValueError("Invalid opened canvas context")
        opened_index = next((i for i, c in enumerate(opened) if c.get("key") == key), None)
        if opened_index is not None:
            opened.pop(opened_index)
            if opened_index <= current and current > 0:
                current -= 1
        view["currentCanvas"] = current
        # Official canvas-list view removes stale tabs and opens the first
        # remaining canvas if the last open tab was deleted. No pixel pos is
        # generated here; the renderer owns it.
        remaining = [c for i, c in enumerate(canvases) if i != index]
        valid = {c.get('key') for c in remaining}
        opened[:] = [c for c in opened if c.get('key') in valid]
        if not opened and remaining:
            opened.append({'key': remaining[0]['key']})
        if current >= len(opened):
            view['currentCanvas'] = len(opened) - 1
    canvases.pop(index)
    for cell_key, _ in selected:
        del cells[cell_key]
    model.context = context
    return [cell_id for _, cell_id in selected]
