"""Check parameter/calculation schemes in memory (SimStudio worker 37082).

functions=None means function definitions were not supplied; calculation
schemes are then explicitly pending. An explicit mapping, including {}, is an
observed function cache: missing entries produce the official unknown warning.
"""
from copy import deepcopy

from .diagram_connections import _DiagramScope, _evaluate, _js_entries
from .graphic_checks import _condition_result
from .job_inputs import _fields, _convert, _expression, _json_numbers
from .parameter_checks import check_parameter_constraints
from .runtime_checks import resolve_runtime_field, validate_runtime
from .expression_diagnostics import expression_error


def _defaults(parameters, args):
    local = deepcopy(args or {})
    fields = _fields(parameters)
    for field in fields:
        key = field['key']
        value = local.get(key)
        if value is None:
            value = deepcopy(field.get('value'))
            if _expression(value):
                value['ɵexp'] = ''
        if not _expression(value):
            value = _convert(value, field, value)
        local[key] = value
    keys = {field['key'] for field in fields}
    for key in list(local):
        if key not in keys and not key.startswith(('_', '$', '@', 'ɵ')):
            del local[key]
    return local


def _enabled(scope, condition):
    # Official F9 logs invalid conditions and falls back to true.
    valid, value = _condition_result(scope, condition)
    return value if valid else True


def prepare_case_checks(model, *, functions=None, runtime=None):
    """Return cases problems, an isolated normalized document, and coverage.

    Unsupported expressions/constraints raise, rather than returning a clean
    model. VM diagnostic strings differ from the browser, so expression errors
    remain refusals. No fetch/save/run is performed.
    """
    document = deepcopy(model if isinstance(model, dict) else model.toJSON())
    validate_runtime(runtime)
    parameters = document['revision'].get('parameters', [])
    globals_ = _defaults(parameters, {})
    problems = []
    pending = []

    def check(scheme, index, kind, definition):
        active = index == document.get('context', {}).get('currentConfig' if kind == 'config' else 'currentJob')
        plural = 'configs' if kind == 'config' else 'jobs'
        base = f'{plural}.{index}.args'
        name = scheme.get('name')
        data = {'path': base, kind: index, kind + 'Name': name if name is not None else f'[{index + 1}]'}
        local = _defaults(definition, scheme.get('args'))
        scheme['args'] = local
        # Config locals are also their $global values; jobs use the evaluated
        # current config (or parameter defaults if none is selected).
        scope = _DiagramScope(local, {'args': local} if kind == 'config' else scheme,
                              document, local if kind == 'config' else globals_)
        fields = {}
        for gi, group in enumerate(definition):
            for field in group['items']:
                effective = deepcopy(field)
                fields[field['key']] = (effective, gi)  # official Map: last key wins
        expression_problems={}
        for key, value in _js_entries(local):
            if key in fields:
                field = fields[key][0]
                try:local[key] = _convert(_evaluate(scope, value), field, field.get('value'))
                except ValueError as exc:
                    expression_problems[key]={'message':f'{kind} arg:invalid expression','level':'error' if active else 'warning',
                        'data':{**data,'path':f'{base}.{key}','argName':field.get('name') or key,'error':expression_error(exc)}}
                    local[key]=deepcopy(field.get('value'))
        enabled = [_enabled(scope, group.get('condition')) for group in definition]
        for key, value in _js_entries(local):
            if key not in fields:
                continue
            field, gi = fields[key]
            if kind == 'job':
                field,missing=resolve_runtime_field(field,runtime=runtime,rid=scheme.get('rid'),args=local,value=value)
            else:
                missing=[i for i,c in enumerate(field.get('constraints') or [])
                         if isinstance(c,dict) and 'condition' not in c]
            for _ in missing:
                pending.append(f'{base}.{key}: constraint callback absent from JSON definition')
            visible=enabled[gi] and _enabled(scope, field.get('condition'))
            if key in expression_problems:
                problem=expression_problems[key]
                if not visible:problem['level']='info'
                problems.append(problem)
            elif visible:
                found = check_parameter_constraints(value, field, scope=scope,
                    message=f'{kind} arg:unsatisfied constraint',
                    data={**data, 'path': f'{base}.{key}', 'argName': field.get('name') or key})
                if not active:
                    found = [dict(p, level='warning') for p in found if p['level'] == 'error']
                problems.extend(found)

    for index, scheme in enumerate(document.get('configs') or []):
        check(scheme, index, 'config', parameters)
    current = document.get('context', {}).get('currentConfig')
    configs = document.get('configs') or []
    if type(current) is int and 0 <= current < len(configs):
        globals_ = configs[current]['args']
    jobs = document.get('jobs') or []
    if functions is not None:
        if not isinstance(functions, dict):
            raise TypeError('functions must be a mapping or None')
        for index, scheme in enumerate(jobs):
            definition = functions.get(scheme.get('rid'))
            if definition is None:
                name = scheme.get('name')
                problems.append({'message': 'job:unknown', 'level': 'warning' if index == document.get('context', {}).get('currentJob') else 'info',
                    'data': {'path': f'jobs.{index}.args', 'job': index,
                             'jobName': name if name is not None else f'[{index + 1}]',
                             **({'jobRid': scheme['rid']} if 'rid' in scheme else {})}})
            else:
                check(scheme, index, 'job', definition.get('parameters') or [])
    if jobs and functions is None:
        pending.append('calculation function definitions')
    complete = not pending
    return {'complete': complete, 'problems': _json_numbers(problems),
            'document': _json_numbers(document),
            'pending': pending}
