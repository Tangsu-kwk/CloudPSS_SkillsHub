"""Independent GraphQL environment for checking an in-memory SDK model.

No MCP/browser snapshots, saves, revisions or task mutations. Fetch definitions
actually referenced by cells, the executable-function registry, and policies
including queue load. Never replace unknown/failed reads with an empty cache.
"""
from copy import deepcopy
import json
import math
import re

from .remote_reads import _request
from .job_functions import load_job_functions
from .runtime_checks import validate_runtime

POLICIES_QUERY = '''query SdkCheckPolicies($input:JobPoliciesInput!) {
 jobPolicies(input:$input) { count total cursor items {
  id name users functions minPriority maxPriority maxDuration visibility
  tres { cpu ecpu mem }
  queue { id name load machines { id name valid tres { cpu ecpu mem } } }
 } }
}'''
DEFINITION_QUERY = '''query SdkCheckDefinition($rid:ResourceId!) {
 model(input:{rid:$rid}) { rid name description tags keywords
  revision { version documentation parameters pins graphic } }
}'''


class CheckEnvironmentError(RuntimeError):
    """Required check inputs unavailable; no task should be submitted."""


def load_job_policies(*, requester=None):
    result, seen, cursors = [], set(), set()
    inputs = {'orderBy': [], 'limit': 1000}
    for _ in range(1000):
        page = _request(POLICIES_QUERY, {'input': deepcopy(inputs)}, requester).get('jobPolicies')
        if (not isinstance(page, dict) or not isinstance(page.get('items'), list)
                or type(page.get('count')) is not int or type(page.get('total')) is not int
                or page['count'] != len(page['items']) or page['count'] < 0 or page['total'] < page['count']):
            raise CheckEnvironmentError('Invalid policy page')
        added = 0
        for position, policy in enumerate(page['items']):
            validate_runtime({'policies': [policy]})
            queue = policy['queue']
            if (type(queue.get('load')) not in (int, float) or not math.isfinite(queue['load'])
                    or type(policy.get('id')) is not int):
                raise CheckEnvironmentError('Policy identity and queue load are required')
            identifier = policy['id']
            if identifier in seen:
                if position == 0 and result and policy == result[-1]:
                    continue
                raise CheckEnvironmentError('Duplicate or conflicting policy across pages')
            seen.add(identifier)
            result.append(deepcopy(policy))
            added += 1
        if page['count'] == 0:
            if page['total'] != 0:
                raise CheckEnvironmentError('Empty policy page with remaining records')
            return result
        cursor = page.get('cursor')
        if page['count'] == page['total']:
            return result
        if not added or not isinstance(cursor, list) or not cursor:
            raise CheckEnvironmentError('Incomplete policy page')
        marker = json.dumps(cursor, sort_keys=True)
        if marker in cursors:
            raise CheckEnvironmentError('Repeated policy cursor')
        cursors.add(marker)
        inputs['cursor'] = deepcopy(cursor)
    raise CheckEnvironmentError('Policy page limit exceeded')


def load_check_environment(model, *, requester=None):
    """Return detached definitions/functions/policies/runtime read via GraphQL.

    Only public definition metadata used by the checker is requested; protected
    implementation bodies are not needed for checking component arguments/pins.
    A missing definition, unsupported version or unreadable source aborts rather
    than pretending that its checks ran. This loads inputs, not checker parity.
    """
    document = deepcopy(model if isinstance(model, dict) else model.toJSON())
    definitions, pending = {}, []
    def references(doc):
        cells = doc.get('revision', {}).get('implements', {}).get('diagram', {}).get('cells', {})
        if not isinstance(cells, dict):
            raise CheckEnvironmentError('Invalid diagram cells')
        for cell in cells.values():
            if not isinstance(cell, dict) or cell.get('shape') not in ('diagram-component', 'diagram-component-edge'):
                continue
            value = cell.get('definition')
            if isinstance(value, dict):
                references(value)
            elif not isinstance(value, str) or not re.fullmatch(r'model/[^/\s]+/[^/\s]+', value):
                raise CheckEnvironmentError('Invalid component definition identity')
            elif value not in definitions and value not in pending:
                pending.append(value)
    references(document)
    while pending:
        if len(definitions) >= 10000:
            raise CheckEnvironmentError('Component definition limit exceeded')
        rid = pending.pop(0)
        item = _request(DEFINITION_QUERY, {'rid': rid}, requester).get('model')
        revision = item.get('revision') if isinstance(item, dict) else None
        if (not isinstance(item, dict) or item.get('rid') != rid or not isinstance(revision, dict)
                or not isinstance(revision.get('parameters'), list) or not isinstance(revision.get('pins'), list)):
            raise CheckEnvironmentError('Missing or inconsistent component definition: ' + rid)
        if revision.get('version') != 5:
            raise NotImplementedError('Check definitions must be version 5')
        definitions[rid] = deepcopy(item)
        references(item)
    functions = load_job_functions(requester=requester) if document.get('jobs') else {}
    policies = load_job_policies(requester=requester) if document.get('jobs') else []
    return {'definitions': definitions, 'functions': functions, 'policies': policies,
            'runtime': {'policies': deepcopy(policies)}}
