"""Message translations backed by captured MCP or archived official messages.

Unverified messages retain worker codes; callers must consult complete and
limitations. Do not infer full MCP-language compatibility from this helper.
"""
from .parameter_checks import _string


def check_message(group, problem):
    data=problem['data']
    # Archived official Chinese locale, module 88c6410094e3c66dabe0.js.
    # These translations expose the existing topology findings, without
    # claiming the other run_check stages or expression diagnostics complete.
    if group == 'diagram':
        code = problem['message']
        if code == 'pin no link':
            return f"{data['componentName']} 的引脚 {data['pinName']} 悬空"
        if code == 'component input pin no link':
            return f"{data['componentName']} 的输入引脚 {data['pinName']} 悬空，无信号输入"
        if code == 'component pin dim error':
            return (f"{data['componentName']} 的引脚 {data['pinName']} 的 {data['dimName']} "
                    f"维度 {_string(data['dim'])} 与相连元件的引脚维度 {_string(data['otherDim'])} 不相等")
        if code == 'edge terminal:no link':
            side = {'source': '首端', 'target': '末端'}[data['terminal']]
            return f"连接线 {data['key']} 的{side}悬空"
    # Captured full run_check on the migrated legacy fixture, 2026-11-04.
    if group=='parameters' and problem['message']=='group description:empty':
        return f"参数组 {data['groupPointer']} 的详细描述未填写"
    if group=='parameters' and problem['message']=='parameter description:empty':
        return f"参数 {data['paramPointer']} 的详细描述未填写"
    # Official Chinese locale, module file 88c6410094e3c66dabe0.js.
    # Choice metadata omissions are diagnostics, not missing checker inputs.
    if group=='parameters' and problem['message']=='parameter choices:description:empty':
        return f"参数 {data['paramPointer']} 的选项 {data['choicePointer']} 的详细描述未填写"
    if group=='pinDefinitions' and problem['message']=='pin description:empty':
        return f"引脚 {data['pinPointer']} 的详细描述未填写"
    if group=='cases' and problem['message'] in ('job arg:invalid expression','config arg:invalid expression'):
        return f"{data.get('jobName',data.get('configName'))} 的参数 {data['argName']} 无效：{data['error']}"
    if ((group=='cases' and problem['message'] in ('job arg:unsatisfied constraint','config arg:unsatisfied constraint'))
            or (group=='parameters' and problem['message']=='parameter value:unsatisfied constraint')):
        suffix={'value is not a valid choice':'参数不是一个有效的选项',
                'value is not an enabled choice':'参数是一个不可用的选项',
                '核心数应小于等于计算资源中配置的值':'核心数应小于等于计算资源中配置的值'}.get(data.get('constraint'))
        constraint=data.get('constraint')
        detail=data.get('constraintData') or {}
        bounds={
            'value less than minimum':('参数值小于最小值','minimum'),
            'value equal to minimum':('参数值等于最小值','minimum'),
            'value greater than maximum':('参数值大于最大值','maximum'),
        }
        if constraint in bounds:
            label,key=bounds[constraint]
            if key in detail:suffix=f'{label} {_string(detail[key])}'
        if constraint=='value must be integer':suffix='参数值必须为整数'
        if constraint=='结束时间应大于开始时间':suffix=constraint
        if data.get('constraint')=='value not in range' and isinstance(data.get('constraintData'),dict) and 'range' in data['constraintData']:
            suffix=f"参数值不在范围 {data['constraintData']['range']} 内"
        if suffix is not None:
            if group=='parameters':return f"参数 {data['paramPointer']} 的默认值无效：{suffix}"
            return f"{data.get('jobName',data.get('configName'))} 的参数 {data['argName']} = {data['value']} 无效：{suffix}"
    if (group=='cases' and problem['message']=='job arg:unsatisfied constraint'
            and data.get('constraint')=='value less than minimum'
            and isinstance(data.get('constraintData'),dict)
            and 'minimum' in data['constraintData']):
        return (f"{data['jobName']} 的参数 {data['argName']} = {data['value']} 无效："
                f"参数值小于最小值 {_string(data['constraintData']['minimum'])}")
    return problem['message']
