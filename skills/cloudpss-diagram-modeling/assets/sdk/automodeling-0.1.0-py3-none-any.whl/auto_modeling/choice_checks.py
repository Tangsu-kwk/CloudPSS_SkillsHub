"""Evaluate and normalize parameter choices (official evaluator method).

Expressions use the existing explicit MiraScript scope. Browser callbacks and
failed expressions remain refusals, rather than an empty/valid choices list.
"""
from copy import deepcopy
from .job_inputs import _choice_type, _primitive, _FAIL, _expression, _json_numbers
from .diagram_connections import _evaluate


def evaluate_choices(field, scope):
    raw=field.get('choices')
    if callable(raw):raise NotImplementedError('Browser choice callbacks require explicit runtime resolution')
    values=_evaluate(scope,raw) if _expression(raw) else deepcopy(raw)
    if values is not None and not isinstance(values,list):
        raise NotImplementedError('Choice expression must evaluate to an array')
    kind=_choice_type(field)
    logical=field.get('type')=='logical'
    defaults=([False,True] if kind in ('','boolean') else [0,1] if kind=='number' else ['0','1']) if logical else []
    result=[]
    for index,item in enumerate(values or []):
        if logical and index>=2:break
        key=item.get('key') if isinstance(item,dict) else item if type(item) in (str,bool,int,float) else None
        if key is None:key=defaults[index] if index<len(defaults) else index
        converted=_primitive(key,kind,_FAIL)
        if converted is _FAIL:raise NotImplementedError('Choice key conversion failed')
        condition=item.get('condition') if isinstance(item,dict) else None
        result.append({'key':converted,**({'condition':deepcopy(condition)} if condition not in (None,'') else {})})
    while logical and len(result)<2:result.append({'key':defaults[len(result)]})
    return _json_numbers(result)
