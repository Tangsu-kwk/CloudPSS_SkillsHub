import os
from pathlib import Path

from dotenv import load_dotenv

from auto_modeling.core import setup_logging
from auto_modeling.mcp_server import register_all_tools
from auto_modeling.providers.factory import ProviderFactory
from fastmcp import FastMCP


def _load_config() -> dict:
    """从环境变量构建配置字典。"""

    def _bool(val: str | None, default: bool = False) -> bool:
        if val is None:
            return default
        return val.strip().lower() in ("1", "true", "yes")

    return {
        "platform_type": os.getenv("PLATFORM_TYPE", "cloudpss"),
        "cloudpss_settings": {
            "api_url": os.getenv("CLOUDPSS_API_URL", "https://cloudpss.net/"),
            "token": os.getenv("CLOUDPSS_TOKEN"),
            "model": os.getenv("CLOUDPSS_MODEL"),
            "auto_save": _bool(os.getenv("CLOUDPSS_AUTO_SAVE")),
            "auto_save_name": os.getenv("CLOUDPSS_AUTO_SAVE_NAME", "test_tool"),
        },
        "server": {
            "transport": os.getenv("MCP_TRANSPORT", "http"),
            "host": os.getenv("MCP_HOST", "0.0.0.0"),
            "port": int(os.getenv("MCP_PORT", "4210")),
            "path": os.getenv("MCP_PATH", "/autoModeling"),
            "log_level": os.getenv("MCP_LOG_LEVEL", "debug"),
        },
    }


def _build_server_config(config: dict) -> dict:
    return dict(config.get("server", {}))


def main() -> None:
    # 自动加载项目根目录的 .env 文件
    load_dotenv(dotenv_path=Path(__file__).resolve().parents[2] / ".env")

    setup_logging()
    config = _load_config()

    provider = ProviderFactory.create_provider(config)

    server = FastMCP("AutoModeling")

    # 注册工具
    register_all_tools(provider, server)

    server_config = _build_server_config(config)
    if server_config:
        server.run(**server_config)
    else:
        server.run(transport="stdio")
