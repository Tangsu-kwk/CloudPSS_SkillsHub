"""Parameter operations on an existing, caller-owned SDK memory model.

All IDs/shapes are checked before mutation; parameter types use independently
queried definitions. Expressions are preserved without evaluation.
"""

from copy import deepcopy


def _components(model, ids):
    from .diagram_edit import _selected_cells
    selected = _selected_cells(model, ids)
    result = {}
    for key, component in zip(ids, selected):
        if getattr(component, "shape", None) not in ("diagram-component", "diagram-component-edge"):
            raise ValueError(f"panic: Cell {key} is not a diagram component")
        result[key] = component
    return result


def get_diagram_components_args(model, ids):
    """Return detached parameter dictionaries keyed by component ID."""
    return {key: deepcopy(comp.toJSON().get('args')) for key, comp in _components(model, ids).items()}


def get_diagram_components(model, ids):
    """Project SDK cells to the public tool's nine fields as detached objects.

    Missing projected fields yield None, matching official tuple projection.
    Input order is retained, including duplicates.
    """
    components = _components(model, ids)
    fields = ("id", "label", "canvas", "definition", "args", "pins", "props", "position", "size")
    result = []
    for key in ids:
        cell = components[key].toJSON()
        result.append({field: deepcopy(cell.get(field)) for field in fields})
    return result


def update_diagram_components_args(model, ids, args, *, definition_resolver=None):
    """Validate types against definitions, then update components in order.

    All IDs/shapes are checked first. Definition/argument failures later in a
    heterogeneous batch can leave earlier writes, matching the official loop.
    Expressions remain unevaluated; omitted keys are preserved.
    """
    from .diagram_edit import _selected_cells
    from .diagram_contract import resolve_definition
    from .scheme_args import fill_args
    if not isinstance(args, dict):
        raise TypeError("args must be an object")
    if not isinstance(ids, list) or any(not isinstance(key, str) for key in ids):
        raise TypeError("ids must be a list of strings")
    components = []
    for key in ids:
        cell = _selected_cells(model, [key])[0]
        if cell.shape not in ('diagram-component', 'diagram-component-edge'):
            raise ValueError(f"panic: Cell {key} is not a diagram component")
        components.append(cell)
    definition, last_rid = None, None
    for cell in components:
        if definition is None or last_rid != cell.definition:
            last_rid = cell.definition
            definition = resolve_definition(last_rid, definition_resolver)
            if definition is None:
                raise ValueError(f"panic: Component definition {last_rid} not found")
        cell.args = fill_args(cell.args, args, definition['parameters'])
