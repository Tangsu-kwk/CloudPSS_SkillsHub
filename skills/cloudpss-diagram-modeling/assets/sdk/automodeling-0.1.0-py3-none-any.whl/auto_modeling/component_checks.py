"""Check component arguments/conditions in memory; not full MCP run_check.

Definitions explicit; unsupported expression diagnostics or browser callbacks
raise. Public helper returns problems plus the isolated evaluated document for
the connection stage, preserving the caller's model and definitions.
"""
from copy import deepcopy
from .diagram_connections import _DiagramScope, _evaluate, _condition, _js_entries
from .job_inputs import _convert, _expression, _json_numbers, evaluate_args, _js_truth
from .parameter_checks import check_parameter_constraints
from .expression_diagnostics import expression_error


def prepare_component_checks(model, *, definitions):
    document=deepcopy(model if isinstance(model,dict) else model.toJSON())
    revision=document['revision'];diagram=revision.get('implements',{}).get('diagram')
    if diagram is None:return {'problems':[],'document':document}
    index=document.get('context',{}).get('currentConfig',0)
    configs=document.get('configs',[])
    if type(index) is not int or not 0<=index<len(configs):raise ValueError('No valid current parameter scheme')
    globals_=evaluate_args(configs[index].get('args',{}),revision.get('parameters',[]))
    # Valid variables resolve lazily so expressions can reference later items.
    for variable in diagram.get('variables',[]):
        if variable['key'] in globals_:raise NotImplementedError('Duplicate variable diagnostics are not yet supported')
        globals_[variable['key']]=deepcopy(variable.get('value'))
    active=set()
    class GlobalScope(_DiagramScope):
        def __getitem__(self,key):
            if key.startswith('$') and key not in ('$','$$'):
                return resolve_global(key[1:])
            return super().__getitem__(key)
    global_scope=GlobalScope({},None,document,globals_)
    def resolve_global(key):
        value=globals_[key]
        if _expression(value):
            if key in active:raise ValueError('Cyclic diagram variable expression')
            active.add(key)
            try:globals_[key]=_evaluate(global_scope,value)
            finally:active.remove(key)
        return deepcopy(globals_[key])
    for key in list(globals_):resolve_global(key)
    problems=[]
    for key,cell in _js_entries(diagram.get('cells',{})):
        if cell is None or cell.get('shape') not in ('diagram-component','diagram-component-edge'):continue
        path=f'revision.implements.diagram.cells.{key}'
        data={'path':path,'component':key,'componentName':cell.get('label') or key}
        rid=cell['definition'];definition=rid if isinstance(rid,dict) else definitions.get(rid)
        if definition is None:
            problems.append({'message':'component:unknown','data':data,'level':'warning'});continue
        params=definition['revision'].get('parameters',[])
        local=deepcopy(cell.get('args') or {})
        scope=_DiagramScope(local,cell,document,globals_)
        cell['props']=cell.get('props') or {'enabled':True,'outlineLevel':0}
        enabled=cell['props'].get('enabled')
        try:enabled=True if enabled is None else _evaluate(scope,enabled)
        except ValueError as exc:
            problems.append({'message':'component props:enabled:invalid expression','level':'error',
                'data':{**data,'path':path+'.props.enabled','error':expression_error(exc)}})
            enabled=True
        cell['props']['enabled']=enabled
        fields={}
        for group_no,group in enumerate(params):
            for field in group['items']:
                fields.setdefault(field['key'],(field,group_no))
                value=local.get(field['key'])
                if value is None:
                    value=deepcopy(field.get('value'))
                    if _expression(value):value['ɵexp']=''
                local[field['key']]=value if _expression(value) else _convert(value,field,value)
        cell['args']=local
        expression_problems={}
        for name,value in list(_js_entries(local)):
            if name not in fields:del local[name];continue
            field=fields[name][0]
            # SDK VM error messages differ from browser messages. Preserve a
            # refusal rather than fabricate an MCP-compatible error string.
            try:local[name]=_convert(_evaluate(scope,value),field,deepcopy(field.get('value')))
            except ValueError as exc:
                expression_problems[name]={'message':'component arg:invalid expression','level':'error',
                    'data':{**data,'path':f'{path}.args.{name}','argName':field.get('name') or name,'error':expression_error(exc)}}
                local[name]=deepcopy(field.get('value'))
        group_conditions=[_condition(scope,g.get('condition')) for g in params]
        for name,value in _js_entries(local):
            field,group_no=fields[name]
            visible=group_conditions[group_no] and _condition(scope,field.get('condition'))
            if name in expression_problems:
                problem=expression_problems[name]
                if not visible:problem['level']='info'
                elif not _js_truth(enabled):problem['level']='warning'
                problems.append(problem)
            elif _js_truth(enabled) and visible:
                problems.extend(check_parameter_constraints(value,field,scope=scope,
                    data={**data,'path':f'{path}.args.{name}','argName':field.get('name') or name}))
        pins={}
        from mirascript import to_string
        raw_pins=cell.get('pins') or {}
        from .dynamic_pins import check_pin_definitions
        for pin in check_pin_definitions(definition,local):
            value=raw_pins.get(pin['key'])
            visible=_condition(scope,pin.get('condition'))
            try:evaluated=_evaluate(scope,'' if value is None else value)
            except ValueError as exc:
                problems.append({'message':'component pin:invalid expression','level':'error' if visible else 'warning',
                    'data':{**data,'path':f'{path}.pins.{pin["key"]}','pinName':pin.get('name') or pin['key'],'error':expression_error(exc)}})
                evaluated=''
            pins[pin['key']]=to_string(evaluated,'') if visible else ''
        cell['pins']=pins
    return {'problems':_json_numbers(problems),'document':_json_numbers(document)}
