"""Read component definitions through GraphQL without MCP or model mutation."""

from typing import Any


COMPONENT_MODEL_QUERY = """
query ComponentModel($rid: ResourceId!) {
  model(input: {rid: $rid}) {
    rid
    name
    description
    revision {
      documentation
      parameters
      pins
    }
  }
}
"""


class ComponentModelError(RuntimeError):
    """The request failed or its response did not satisfy the tool contract."""

    def __init__(self, message, graphql_errors=None):
        super().__init__(message)
        self.graphql_errors = graphql_errors


def _error_diagnostics(errors):
    """Keep diagnostic fields only; never emit full extensions or request data."""
    import os
    import re

    def clean(value):
        text = str(value)
        token = os.environ.get("CLOUDPSS_TOKEN")
        if token:
            text = text.replace(token, "[REDACTED]")
        return re.sub(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", "[REDACTED]", text)[:2000]

    result = []
    for error in errors if isinstance(errors, list) else []:
        if not isinstance(error, dict):
            continue
        item = {"message": clean(error.get("message", "Unknown GraphQL error"))}
        if isinstance(error.get("path"), list):
            item["path"] = [clean(part) for part in error["path"]]
        extensions = error.get("extensions")
        if isinstance(extensions, dict):
            for key in ("code", "status", "statusCode"):
                if key in extensions:
                    item[key] = clean(extensions[key])
        result.append(item)
    return result


def get_component_model(rid: str) -> dict[str, Any] | None:
    """Return the public tool's six fields, or None for an unavailable model.

    Authentication uses the CloudPSS SDK configuration (CLOUDPSS_TOKEN and
    CLOUDPSS_API_URL). The observed model-level 404 ('不存在或权限不足') maps
    to None for MCP compatibility; it cannot distinguish absence from access.
    Other request/authentication/GraphQL failures raise an error.
    Nested metadata is returned unchanged, including missing optional fields.
    """
    if not isinstance(rid, str) or not rid.strip():
        raise ValueError("rid must be a non-empty string")

    from cloudpss.utils import graphql_request

    try:
        response = graphql_request(COMPONENT_MODEL_QUERY, {"rid": rid}, timeout=30)
    except Exception:
        # Do not include transport exception text: it can contain credentials.
        raise ComponentModelError(
            "GraphQL request failed; check connectivity, API URL and API token."
        ) from None

    if not isinstance(response, dict):
        raise ComponentModelError("Invalid GraphQL response: expected an object")
    if response.get("errors"):
        errors = response["errors"]
        # Match only the observed response. Never suppress additional errors,
        # nested field failures, or an error accompanying a non-null model.
        data = response.get("data")
        no_model = data is None or (
            isinstance(data, dict) and data.get("model") is None
        )
        if isinstance(errors, list) and len(errors) == 1 and no_model:
            error = errors[0]
            if isinstance(error, dict):
                extensions = error.get("extensions")
                if (
                    isinstance(extensions, dict)
                    and str(extensions.get("status")) == "404"
                    and extensions.get("code") == "INTERNAL_SERVER_ERROR"
                    and error.get("path") == ["model"]
                    and error.get("message") == f"{rid} 不存在或权限不足"
                ):
                    return None
        raise ComponentModelError(
            "GraphQL returned errors; component lookup failed",
            graphql_errors=_error_diagnostics(response["errors"]),
        )
    data = response.get("data")
    if not isinstance(data, dict) or "model" not in data:
        raise ComponentModelError("Invalid GraphQL response: missing data.model")
    model = data["model"]
    if model is None:
        return None
    if not isinstance(model, dict) or not isinstance(model.get("revision"), dict):
        raise ComponentModelError("Invalid GraphQL response: missing model revision")
    revision = model["revision"]
    expected_types = {
        "rid": str, "name": str, "description": str,
        "documentation": str, "parameters": list, "pins": list,
    }
    result = {}
    for field, expected in expected_types.items():
        source = model if field in ("rid", "name", "description") else revision
        if field not in source or type(source[field]) is not expected:
            raise ComponentModelError(f"Invalid or missing component field: {field}")
        result[field] = source[field]
    return result


def compare_json(expected: Any, actual: Any, path: str = "$") -> list[str]:
    """Compare JSON strictly, ignoring object key order only."""
    if type(expected) is not type(actual):
        return [f"{path}: type {type(expected).__name__} != {type(actual).__name__}"]
    differences = []
    if isinstance(expected, dict):
        for key in expected:
            if key not in actual:
                differences.append(f"{path}.{key}: missing")
            else:
                differences.extend(compare_json(expected[key], actual[key], f"{path}.{key}"))
        for key in actual:
            if key not in expected:
                differences.append(f"{path}.{key}: unexpected field")
    elif isinstance(expected, list):
        if len(expected) != len(actual):
            differences.append(f"{path}: length {len(expected)} != {len(actual)}")
        for index, (left, right) in enumerate(zip(expected, actual)):
            differences.extend(compare_json(left, right, f"{path}[{index}]"))
    elif expected != actual:
        differences.append(f"{path}: {expected!r} != {actual!r}")
    return differences
