"""Detached component props and pin-value projections from an existing Model."""
from copy import deepcopy
from .diagram_edit import _selected_cells


def _read_field(model, ids, field):
    cells = _selected_cells(model, ids)
    result = {}
    for key, cell in zip(ids, cells):
        if cell.shape not in ("diagram-component", "diagram-component-edge"):
            raise ValueError(f"panic: Cell {key} is not a diagram component")
        raw = cell.toJSON()
        result[key] = deepcopy(raw.get(field))
    return result


def get_diagram_components_props(model, ids):
    """Return properties keyed by ID; repeated IDs collapse, empty IDs return {}."""
    return _read_field(model, ids, "props")


def get_diagram_components_pins(model, ids):
    """Return stored pin values, not definition-level pin metadata or topology."""
    return _read_field(model, ids, "pins")
