"""Standard SimStudio component groups: independent GraphQL + client rules.

Source: component service initGroups/loadSubscriptions in archived 5.0.39.
No browser caches or MCP responses are used as runtime answers.
"""
from copy import deepcopy
import math
from .remote_reads import _request, _current_user_name, RemoteReadError

GROUPS_QUERY = '''query ComponentSubscriptionGroups($input: ModelsInput!) {
  models(input: $input) { count total cursor items { rid name description tags keywords } }
}'''


def official_subscriptions():
    return [{'key':'project-support:job-definition/cloudpss/'+key,'name':name,
             'visible':visible,'type':'official'}
            for key,name,visible in [('emtp','EMTP 元件',True),('sfemt','SFEMT 元件',True),
               ('power-flow','潮流元件',True),('ies-simulation','综合能源系统元件',False)]]


def _index(text):
    if not text:return math.inf
    try:
        value=text.strip()
        return float(int(value,0)) if value.lower().startswith(('0x','0b','0o')) else float(value or 0)
    except ValueError:return math.nan


def load_component_subscriptions(stored=None, *, requester=None):
    """Discover groups and retain visibility for standard SimStudio mode.

    Fresh registry per call; existing browser sessions can retain stale caches.
    Pagination/transport failures propagate, never silently yield partial groups.
    """
    username=_current_user_name()
    inputs={'orderBy':['updatedAt<','owner','key'],'limit':1000000,
            'tags':'project-category:component','access':{'permission':65536}}
    seen=set();cursors=set();entries=[]
    for _ in range(100):
        page=_request(GROUPS_QUERY,{'input':deepcopy(inputs)},requester).get('models')
        if (not isinstance(page,dict) or type(page.get('count')) is not int
            or type(page.get('total')) is not int or not isinstance(page.get('items'),list)
            or page['count']!=len(page['items']) or min(page['count'],page['total'])<0):
            raise RemoteReadError('Invalid component group registry page')
        for item in page['items']:
            if not isinstance(item,dict) or not isinstance(item.get('rid'),str) or not isinstance(item.get('tags'),list):
                raise RemoteReadError('Invalid component group registry item')
            rid=item['rid'];parts=rid.split('/')
            if len(parts)!=3 or parts[0]!='model':raise RemoteReadError('Invalid component group model RID')
            if rid in seen:continue
            seen.add(rid);owner=parts[1]
            for tag in item['tags']:
                if not isinstance(tag,str):raise RemoteReadError('Invalid component group tag')
                if not tag.startswith('project-group:'):continue
                fields=tag.split(':');group=fields[1]
                # cleanUpModel drops mismatched owner-qualified group tags.
                if not group or ('/' in group and group.split('/')[0]!=owner):continue
                entries.append((group,_index(fields[2] if len(fields)>2 else '')))
        if page['count']==0 or page['count']>=page['total']:break
        cursor=page.get('cursor')
        if not isinstance(cursor,list) or not cursor:raise RemoteReadError('Missing component group registry cursor')
        marker=repr(cursor)
        if marker in cursors:raise RemoteReadError('Repeated component group registry cursor')
        cursors.add(marker);inputs['cursor']=deepcopy(cursor)
    else:raise RemoteReadError('Component group registry page limit exceeded')
    # JS stable sort: subtraction yielding NaN compares as equal.
    from functools import cmp_to_key
    def order(a,b):
        delta=a[1]-b[1]
        return 0 if math.isnan(delta) or delta==0 else -1 if delta<0 else 1
    entries.sort(key=cmp_to_key(order));groups=list(dict.fromkeys(g for g,_ in entries))
    result=official_subscriptions()+[{'key':g,'name':g,'visible':True,'type':'self'}
                                   for g in groups if g.startswith(username+'/')]
    if stored is None:stored=[]
    if not isinstance(stored,list) or any(not isinstance(s,dict) for s in stored):
        raise TypeError('groupSubscriptions must be an array of objects')
    for subscription in result:
        match=next((s for s in stored if s.get('key')==subscription['key'] and s.get('type')==subscription['type']),None)
        if match is not None:
            if 'visible' in match:subscription['visible']=deepcopy(match['visible'])
            else:subscription.pop('visible',None)
    result.extend(deepcopy(s) for s in stored if s.get('type')=='thirdParty' and s.get('key') in groups)
    return result
