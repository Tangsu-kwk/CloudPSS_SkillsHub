"""Read/edit caller-owned parameter schemes without save or computation."""
from copy import deepcopy
from .scheme_args import fill_args, default_args
from .scheme_indices import numeric_index, read_index, write_index


def list_configs(model):
    """Observed public list projection; does not expose args or pins."""
    return [{"index": index, "name": deepcopy(config["name"])}
            for index, config in enumerate(model.configs)]


def get_config(model, index=None):
    """Return a detached scheme; None uses model.context['currentConfig'].

    Finite numeric indices truncate toward zero, then negative indices address
    the end of the array, as in MiraScript. Out-of-range returns None.
    Current selection belongs to this Python model, not a browser session.
    Known discrepancy (user report 2026-11-04): with currentConfig=1 and a
    single item, omitted index returns None but explicit JSON null reportedly
    returns item 0. This signature currently treats both inputs identically.
    See docs/config_ui_selection_followup_20261104.md before claiming parity.
    """
    if index is None:
        index = getattr(model, 'context', {}).get('currentConfig')
        if index is None:
            index = 0
    index = numeric_index(index)
    try:
        config = model.configs[index]
    except IndexError:
        return None
    return deepcopy(config)


def _parameters(model):
    revision = getattr(model, "revision", None)
    if revision is None:
        raise NotImplementedError("config editing requires model.revision.parameters")
    return revision.parameters or []


def _validated_args(model, args, original=None):
    # Definition-less test doubles can still reproduce empty-argument writes.
    if args == {} and not hasattr(model, "revision"):
        return deepcopy(original or {})
    return fill_args(original or {}, args, _parameters(model))


def _name(name):
    if not isinstance(name, str):
        raise TypeError("name must be a string")


def add_config(model, name, args):
    """Append provided converted args, with no implicit defaults or selection."""
    _name(name)
    prepared = _validated_args(model, args)
    model.configs.append({"name": name, "args": prepared})
    return len(model.configs) - 1


def update_config(model, index, args, name=None):
    """Merge whole argument values atomically; None leaves the name unchanged."""
    position = read_index(model.configs, index, "config")
    if name is not None:
        _name(name)
    config = deepcopy(model.configs[position])
    config["args"] = _validated_args(model, args, config["args"])
    if name is not None:
        config["name"] = name
    write_index(model.configs, index, config)


def delete_config(model, index):
    """Splice a scheme, preserving currentConfig, materializing a new selection.

    Browser args-editor defaults are reproduced when a valid current slot gets
    a different scheme. Historical unexplained selection drift is not invented.
    """
    position = numeric_index(index)
    if not 0 <= index < len(model.configs):
        raise IndexError(f"panic: config index {index} out of range")
    current = model.context.get('currentConfig')
    current = 0 if current is None else numeric_index(current)
    replacement = None
    if position <= current < len(model.configs) - 1:
        replacement = default_args(_parameters(model), model.configs[current + 1]["args"])
    del model.configs[position]
    if replacement is not None:
        model.configs[current]["args"] = replacement
