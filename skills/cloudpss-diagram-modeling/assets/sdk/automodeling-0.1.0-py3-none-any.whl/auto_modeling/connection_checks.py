"""Connection rules for already evaluated topology, not the run_check tool.

Caller supplies connected groups, resolved pin definitions and dimensions.
No expression evaluation, definition loading, model mutation or submission.
Problem records are the worker's untranslated message/data/level records.
Source: SimStudio 5.0.39 worker 8961, module 91148.
"""
from copy import deepcopy
import math

_MIXED_TYPES = {"electricalAc", "electricalDc", "water", "hotWater", "coldWater",
                "ice", "hydrogen", "nitrogen", "ammonia"}
_GROUND = "model/CloudPSS/GND"


def check_connection_groups(groups, *, components, pins, pin_info, port_group, dimensions):
    """Return worker connection problems from explicit prepared inputs.

    groups maps group IDs to terminal paths (edges may also occur). components
    maps IDs to {definition, enabled}; pins and pin_info map terminal paths to
    definitions and worker location records. dimensions maps terminals to two
    evaluated numbers. Missing dimensions for a checked terminal raise; this
    must never turn unsupported evaluation into a clean check.
    """
    problems, linked = [], set()

    def problem(message, terminal, level="error", **data):
        problems.append({"message": message, "data": {**deepcopy(pin_info[terminal]), **data},
                         "level": level})

    def connection_problems(nodes, message):
        for node in nodes:
            info = pin_info.get(node)
            if info and components.get(info["key"], {}).get("definition") != _GROUND:
                problem(message, node)

    def checked_dimension(node):
        values = dimensions[node]
        if not isinstance(values, (tuple, list)) or len(values) != 2:
            raise ValueError("Resolved dimensions must contain X and Y")
        result = []
        for name, value in zip(("X", "Y"), values):
            if type(value) not in (int, float):
                raise TypeError("Dimensions must be evaluated numbers")
            if not math.isfinite(value):
                raise ValueError("Nonfinite dimensions require expression diagnostics")
            if value < 0 or int(value) != value or abs(value) > 2**53 - 1:
                problem("component pin dim:invalid value", node, "warning", dimName=name, dim=value)
            result.append(value)
        return result

    for terminals in groups.values():
        # JS Set preserves first occurrence order; an edge is not a pin.
        nodes = list(dict.fromkeys(node for node in terminals if node in pin_info
                     and pin_info[node]["key"] in components
                     and components[pin_info[node]["key"]].get("enabled", True)))
        counts = {}
        for node in nodes:
            linked.add(node)
            if node in pins:
                kind = pins[node].get("connection")
                counts[kind] = counts.get(kind, 0) + 1
        if len(counts) > 1 and _MIXED_TYPES.intersection(counts):
            for node in nodes:
                if pins.get(node, {}).get("connection") in _MIXED_TYPES:
                    problem("component mixed link", node, connectionType=pins[node]["connection"])
        output, electrical, incoming = (counts.get(k, 0) for k in ("output", "electrical", "input"))
        if output < 1 and len(nodes) < 2:
            connection_problems(nodes, "pin no link")
            continue
        if output > 1:
            connection_problems(nodes, "component output pin error")
            continue
        if output > 0 and electrical > 0:
            for node in nodes:
                message = "component output link electrical" if pins.get(node, {}).get("connection") == "output" else "component electrical link output"
                problem(message, node)
            continue
        if output == 0 and electrical == 0 and incoming > 0:
            connection_problems(nodes, "component input pin no link")
            continue
        if electrical > 0 and incoming > 0:
            for node in nodes:
                message = "component input link electrical" if pins.get(node, {}).get("connection") == "input" else "component electrical link input"
                problem(message, node, "warning")
            continue
        reference = None
        for node in nodes:
            if node not in pins or node not in pin_info or pin_info[node]["key"] not in components:
                continue
            dim = checked_dimension(node)
            if reference is None:
                reference = dim
                continue
            for index, name in enumerate(("X", "Y")):
                if reference[index] != 0 and dim[index] != 0 and reference[index] != dim[index]:
                    problem("component pin dim error", node, dimName=name, dim=dim[index], otherDim=reference[index])
                if reference[index] == 0:
                    reference[index] = dim[index]
    for node in port_group:
        pin, info = pins.get(node), pin_info.get(node)
        if pin is None or info is None or pin.get("visible") is False:
            continue
        component = components.get(info["key"], {})
        if (component and component.get("enabled", True) and component.get("definition") != _GROUND
                and node not in linked and pin.get("connection") != "output"):
            problem("pin no link", node)
    return problems
