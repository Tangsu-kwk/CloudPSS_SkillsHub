from abc import ABC
from typing import List, Dict, Any, Callable

class ExtensionTool:
    """描述一个可暴露给应用层的工具"""
    def __init__(
        self,
        name: str,
        description: str,
        func: Callable,
        parameters: List[Dict[str, Any]] = None
    ):
        self.name = name
        self.description = description
        self.func = func
        self.parameters = parameters or []
        
        

class BaseExtension(ABC):
    """
    专属工具类的基类。
    子类通过重写 get_tools() 来声明自己希望暴露给MCP的工具。
    """
        
    def get_tools(self) -> List[ExtensionTool]:
        """
        返回扩展希望注册到MCP的工具列表。
        默认不暴露任何工具，子类按需重写。
        """
        return []