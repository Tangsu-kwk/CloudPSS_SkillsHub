from abc import ABC, abstractmethod
from typing import Dict, List, Tuple

from auto_modeling.core.schemas import ServiceResult

class BaseModelEdit(ABC):
    """
    模型操作类工具基类
    """
    @abstractmethod
    def add_component(self,comp_rid:str, comp_label:str, args:Dict, pins:Dict, position:Tuple, canvas:str)->ServiceResult:
        """
        向模型中添加元件

        :param comp_rid: 目标平台中对应元件的rid
        :param comp_label: 元件标签
        :param args: 元件参数
        :param pins: 元件引脚
        :param position: 元件放置位置
        :param canvas: 元件放置图纸名称
        """
        pass
    
    @abstractmethod
    def add_shunt_component(self, comp_rid:str, target_comp_label:str, comp_label:str, args:Dict, position:Tuple, canvas:str)->ServiceResult:
        """
        向模型中添加元件, 并与指定的某个元件相连

        :param comp_rid: 目标平台中对应元件的rid
        :param target_comp_label: 目标元件标签/名称
        :param comp_label: 新增元件标签/名称
        :param args: 元件参数
        :param position: 元件放置位置
        :param canvas: 元件放置图纸名称
        """
        pass

    @abstractmethod
    def insert_series_component(self, comp_rid:str, comp_key_A:str, comp_key_B:str, comp_label:str, args:Dict, position:Tuple, canvas:str)->ServiceResult:
        """
        在两个元件之间插入一个元件，需确保两个元件之间是直连的。

        :param comp_rid: 目标平台中对应元件的rid
        :param target_comp_label_A: 元件A的标签/名称
        :param target_comp_label_B: 元件B的标签/名称
        :param comp_label: 新增元件标签/名称
        :param args: 元件参数
        :param position: 元件放置位置
        :param canvas: 元件放置图纸名称
        """
        pass

    @abstractmethod
    def conn_components(self, source_comp_key:str, target_comp_key:str, source_pin:Dict, target_pin:Dict)->ServiceResult:
        """
        连接模型中的元件

        :param source_comp_label: 源元件标签/名称
        :param target_comp_label: 目标元件标签/名称
        :param source_pin: 源元件引脚
        :param target_pin: 目标元件引脚
        """
        pass

    @abstractmethod
    def create_canvas(self, canvas_name:str, canvas_key:str)->ServiceResult:
        """
        创建图纸

        :param canvas_name: 图纸名称
        :param canvas_key: 图纸key
        """
        pass

    @abstractmethod
    def update_params(self, comp_labels:List, comp_rid:str, args:Dict)->ServiceResult:
        """
        更新元件参数

        :param comp_labels: 元件标签/名称列表
        :param comp_rid: 元件rid(用于批量更新，与comp_key二选一)
        :param args: 元件参数
        """
        pass

    @abstractmethod
    def del_component(self, comp_labels:List, comp_rid:str)->ServiceResult:
        """
        删除模型中的元件

        :param comp_keys: 待删除元件标签/名称列表
        :param comp_rid: 元件rid(用于批量删除，与comp_key二选一)
        """
        pass
