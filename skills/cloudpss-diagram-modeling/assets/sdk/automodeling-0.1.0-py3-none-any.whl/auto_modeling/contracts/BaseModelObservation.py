from abc import ABC, abstractmethod
from typing import Dict, List, Tuple
from auto_modeling.core.schemas import ServiceResult

class BaseModelObservation(ABC):
    """
    模型观察类工具基类
    """

    @abstractmethod
    def get_topology_relation(self, comp_label: str, max_depth: int, min_depth: int) -> ServiceResult:
        """
        基于BFS获取指定元件周围指定跳数内的拓扑连接关系，支持增量观察（通过min_depth控制）。

        :param comp_label (str): 目标元件的标签/名称
        :param max_depth (int): 最大遍历深度（跳数）
        :param min_depth (int): 最小遍历深度，默认0。设置为 >0 可仅返回新增层级的数据。
        """
        pass
        
    @abstractmethod
    def get_comp_params(self, comp_labels: List[str]) -> ServiceResult:
        """
        获取指定元件的详细参数

        :param comp_labels (List[str]): 目标元件标签/名称列表
        """
        pass


    @abstractmethod
    def get_comp_pins(self, comp_labels: List[str]) -> ServiceResult:
        """
        获取指定元件的引脚信息

        :param comp_labels (List[str]): 目标元件标签/名称列表
        """
        pass     