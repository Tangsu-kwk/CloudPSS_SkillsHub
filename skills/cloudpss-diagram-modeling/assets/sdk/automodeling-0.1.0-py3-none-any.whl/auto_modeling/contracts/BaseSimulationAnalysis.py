from abc import ABC, abstractmethod
from typing import Dict, List, Tuple
from auto_modeling.core.schemas import ServiceResult

class BaseSimulationAnalysis(ABC):
    
    """
    仿真分析类工具基类
    """

    @abstractmethod
    def create_or_update_job(self,flag: str, stype: str, name: str,param: Dict) -> ServiceResult:
        """
        创建或更新一个计算方案
        :param flag (str): 操作标识，表示创建一个计算方案还是修改已有的计算方案。'create'表示创建，'update'表示修改
        :param stype (str): 计算方案的类型，'emtps'表示电磁暂态仿真，'power-flow'表示潮流计算
        :param name (str): 计算方案名称
        :param param (Dict): 计算方案参数
        """
        pass

    @abstractmethod
    def create_or_update_config(self,flag: str,name: str,param: Dict, pins: Dict) -> ServiceResult:
        """
        创建或修改一个仿真参数方案。
        :param flag (str): 操作标识，表示创建一个仿真配置还是修改已有的仿真配置。'create'表示创建，'update'表示修改
        :param name (str): 仿真配置名称
        :param param (Dict): 仿真配置参数
        :param pins (Dict): 仿真配置引脚信息
        """
        pass

    @abstractmethod
    def get_current_job(self,job_name: str, stype: str) -> ServiceResult:
        """
        获取模型中当前已有的计算方案。
        :param stype (str): 计算方案的类型，'emtps'表示电磁暂态仿真，'power-flow'表示潮流计算
        :param job_name (str): 计算方案名称，不指定时默认查询所有计算方案
        """
        pass

    @abstractmethod
    def get_current_config(self, config_name: str) -> ServiceResult:
        """
        获取模型中当前已有的仿真参数方案。
        :param config_name (str): 仿真配置名称，不指定时默认查询所有仿真配置
        """
        pass

    @abstractmethod
    def run_simulation(self, job_name: str, config_name: str) -> ServiceResult:
        """
        运行仿真计算。
        :param job_name (str): 计算方案名称
        :param config_name (str): 仿真配置名称
        """
        pass

    @abstractmethod
    def check_simulation_status(self) -> ServiceResult:
        """
        检查仿真计算状态。
        """
        pass

    @abstractmethod
    def save_simulation_results(self, job_name: str) -> ServiceResult:
        """
        保存仿真计算结果。
        :param job_name (str): 当前仿真使用的计算方案名称
        """
        pass
