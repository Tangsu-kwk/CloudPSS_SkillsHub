from dataclasses import dataclass, field
from typing import Callable, List, Optional
from contextlib import contextmanager
from collections import deque
import logging

logger = logging.getLogger(__name__)

@dataclass
class Action:
    """原子操作单元"""
    # Callable表示这是一个可以被调用的东西。
    # 第一部分表示这个函数可以接受的参数列表，这里为空列表，表示它不需要任何参数；第二部分表示这个函数的返回值类型，这里是None，表示不返回任何有意义的值
    undo: Callable[[], None] # 逆操作
    redo: Callable[[], None] # 重做操作
    name: str = "未知操作"

@dataclass
class TransactionAction(Action):
    """事务操作"""
    actions: List[Action] = field(default_factory=list)

    def __post_init__(self):
        """
        复用内部的事务撤销与重做实现
        """
        # 覆盖初始化时传入的undo/redo逻辑，使用该类内部的具体实现来代替
        self.undo = self._undo_impl
        self.redo = self._redo_impl

    def _undo_impl(self):
        """
        执行事务撤销操作
        """
        # 事务回滚：必须倒序执行（后进先出）
        for action in reversed(self.actions):
            action.undo()

    def _redo_impl(self):
        """
        执行事务重做操作
        """
        # 事务重做：正序执行
        for action in self.actions:
            action.redo()

class HistoryManager:
    """历史记录管理器"""
    def __init__(self, max_history: int = 100):
        """
        初始化历史记录管理器

        :param max_history: 撤销栈的最大容量
        """
        # 限制Undo栈的最大长度，防止内存无线增长
        # 当超过max_history时，最旧的记录会被自动且高效的移除
        self.undo_stack: deque[Action] = deque(maxlen=max_history)
        self.redo_stack: List[Action] = []

        self._active_transaction: Optional[TransactionAction] = None
        self._is_paused = False # 是否暂停记录历史

    @contextmanager
    def paused(self):
        """
        暂停记录历史的上下文管理器
        """
        original_state = self._is_paused # 记录当前的状态
        self._is_paused = True # 强制暂停，避免在undo/redo过程中再次记录历史，造成无限递归

        try:
            yield # 把控制权交还给调用者（with 语句块，即执行 with 语句块中的代码）
        finally:
            self._is_paused = original_state # 恢复状态

    @contextmanager
    def transaction(self, name: str):
        """
        事务上下文管理器

        :param name: 事务名称
        """

        # 如果暂停记录，直接yield，不进行任何事务操作
        if self._is_paused:
            yield
            return

        # 支持嵌套事务（扁平处理：只认最外层，即如果已经在事务中，就把当前 with transaction 当成普通代码块，不创建新事务，也不提交，只执行内容。防止嵌套事务导致结构混乱）
        if self._active_transaction:
            yield
            return
        
        # 1. 开启事务
        self._active_transaction = TransactionAction(name=name, undo=None, redo=None)
        logger.debug(f"[HistoryManager] === [Transaction Start] {name} ===")

        try:
            yield

            # 2. 提交事务
            if self._active_transaction.actions:
                self.undo_stack.append(self._active_transaction)
                self.redo_stack.clear() # 新操作清空重做栈
                logger.debug(f"[HistoryManager] === [Transaction Commit] {name} (Actions: {len(self._active_transaction.actions)}) ===")
            else:
                pass
                logger.debug(f"[HistoryManager] === [Transaction Commit] {name} (No Actions)")
        except Exception as e:
            logger.error(f"[HistoryManager] Transaction failed: {e}")
            raise e
        finally:
            self._active_transaction = None

    def push(self, undo_func: Callable, redo_func: Callable, name = 'Operation'):
        """
        记录一个操作

        :param undo_func: 撤销函数
        :param redo_func: 重做函数
        :param name: 操作名称
        """
        # 如果暂停记录，直接忽略
        if self._is_paused:
            return
        
        action = Action(undo=undo_func, redo=redo_func, name=name)
        if self._active_transaction:
            # 如果在事务中，加入当前事务包
            self._active_transaction.actions.append(action)
        else:
            # 否则直接入栈
            self.undo_stack.append(action)
            self.redo_stack.clear()

    def undo(self) -> bool:
        """
        撤销上一步操作
        """
        if not self.undo_stack:
            return False, "没有可执行的撤销操作"
        
        action = self.undo_stack.pop()
        try:
            action.undo() # 如果是 TransactionAction，会自动倒序 undo 内部子项
            self.redo_stack.append(action) # 将当前的action重新放入到redo栈中，允许用户反悔‘反悔’
            return True,f"撤销执行成功：{action.name}"

        except Exception as e:
            # 如果撤销失败，通常状态已经不一致，这里简单放回（或者应该抛出异常）
            self.undo_stack.append(action) 
            return False, f"撤销执行失败: {str(e)}"

    def redo(self) -> bool:
        """
        重做上一步操作
        """
        if not self.redo_stack:
            return False, "没有可执行的重做操作" 
        
        action = self.redo_stack.pop()
        try:
            action.redo()
            self.undo_stack.append(action)
            return True, f"重做执行成功：{action.name}"
        except Exception as e:
            self.redo_stack.append(action)
            return False, f"重做执行失败: {str(e)}"


