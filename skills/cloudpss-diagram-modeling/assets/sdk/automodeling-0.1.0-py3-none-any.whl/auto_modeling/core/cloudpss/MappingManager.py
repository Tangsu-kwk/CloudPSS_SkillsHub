import copy
import time
import logging
from typing import Dict, List, Set
from cloudpss.model.model import Model
from auto_modeling.core.utils_config import fetch_component_details_by_rid,fetch_component_details_all


logger = logging.getLogger(__name__)

BUS_RID = 'model/CloudPSS/_newBus_3p'
CHANNEL_RID = 'model/CloudPSS/_newChannel'


class MappingManager:
    """映射表管理器 - 负责所有映射表的CRUD操作"""

    def __init__(self, model: Model):
        """
        初始化映射表管理器

        :param model: 目标模型实例
        """
        self.model = model
        self.channel_pin_mapping = {} # 通道引脚字典
        self.comp_label_mapping = {} # 从元件label指向元件的字典
        self.bus_pin_mapping = {}  # 专门存储母线的引脚，格式：{bus_comp_key: pin_value}
        self.comp_pin_mapping = {}  # 存储所有元件的引脚映射表，格式：{comp_key: {pin_idx: pin_value}}
        self.node_to_edges = {}  # { 'node1': {'edge1', 'edge2'} }
        self.edge_to_nodes = {}  # { 'edge1': ('node1', 'node2') }
        self.comp_library = {}  # 元件库


        logger.info("MappingManager 初始化开始...")
        try:
            seen_definitions = self._build_init_mapping() # 创建其他的映射表
            self._build_comp_library(seen_definitions) # 创建元件库

            logger.info(f"MappingManager 初始化完成 - "
                        f"comp: {len(self.comp_pin_mapping)}, "
                       f"comp_pin: {len(self.comp_pin_mapping)}, "
                       f"bus_pin: {len(self.bus_pin_mapping)}, "
                       f"channel_pin: {len(self.channel_pin_mapping)}, "
                       f"label: {len(self.comp_label_mapping)}")
        except Exception as e:
            logger.exception("MappingManager 初始化失败")
            raise RuntimeError(f"映射表管理器初始化失败: {str(e)}") from e

    
    def update_all_mapping(self):
        """
        更新所有映射表(不包含元件库)（对外公开）
        
        根据当前模型状态重新构建所有映射表。
        适用场景：
        - 模型从外部文件重新加载后
        - 怀疑映射表与模型不同步时
        - 执行了大量修改操作后需要刷新

        :return: 更新后的映射表统计信息
        """
        # 更新时无需考虑元件库
        logger.info("开始更新所有映射表...")
        try:
            self._build_init_mapping()

            result = {
                "comp_pin_count": len(self.comp_pin_mapping),
                "bus_pin_count": len(self.bus_pin_mapping),
                "channel_pin_count": len(self.channel_pin_mapping),
                "label_count": len(self.comp_label_mapping),
                "edge_count": len(self.edge_to_nodes)
            }

            logger.info(f"映射表更新完成 - {result}")
            return True, "映射表更新成功"
        except Exception as e:
            logger.exception("映射表更新失败")
            return False, f"映射表更新失败: {str(e)}"

    def get_comp_key(self, label_or_key: str) -> str:
        """
        根据元件标签(label)或键(key)获取元件的内部唯一键(key)

        该方法会自动识别输入是 label 还是 key：
        1. 首先尝试作为 label 在映射表中查找
        2. 如果未找到，检查输入是否本身就是有效的 key
        3. 都找不到则返回 None

        :param label_or_key: 元件的标签名称或内部key
        :return: 找到时返回元件的内部key，找不到返回 None
        """
        if not label_or_key:
            return None

        # 1. 首先尝试作为 label 查找
        comp_key = self.comp_label_mapping.get(label_or_key)
        if comp_key is not None:
            logger.debug(f"通过 label 找到元件: {label_or_key} -> {comp_key}")
            return comp_key

        # 2. 检查输入是否本身就是有效的 key
        if label_or_key in self.comp_pin_mapping.values():
            logger.debug(f"输入本身就是有效的 key: {label_or_key}")
            return label_or_key

        # 3. 都找不到，返回 None
        logger.debug(f"未找到元件: {label_or_key}")
        return None
        
    def search_comp_detail_in_library(self, rid: str) -> Dict:
        """
        根据 rid 获取元件数据

        :param rid: 元件rid
        :return: 元件数据
        """
        comp_id = rid.split('/')[-1]

        # 从元件库中获取数据
        cell = self.comp_library.get(comp_id)

        # 判断是否为空
        if not cell:
            # 如果为空，使用GraphQL API获取该元件的结构信息
            logger.info(f"元件 {comp_id} 缓存为空，正在调用加载函数...")
            comp = fetch_component_details_by_rid(rid)
            if comp:
                cell = self._create_library_cell(comp)
                # 进行缓存，以便下次使用
                self.comp_library[comp_id] = cell

        return cell

    def get_unconnected_pins(self, comp_key: str, pins_meta: Dict) -> List | None:
        """
        获取未创建连接的引脚
        
        :param comp_key: 元件key
        :param pins_meta: 引脚元数据
        :return: 未连接引脚列表，没有则返回 None
        """
        comp_pins = self.comp_pin_mapping.get(comp_key, {})
        # 只保留非空的电气引脚
        target_pin_keys = {key  for key, name in comp_pins.items() if name and pins_meta[key]["type"] == "electrical"}
        if not target_pin_keys:
            # 如果没有任何有效引脚名，直接返回None
            return None

        # 收集其他元件所有使用过的引脚名
        other_used_names = set()
        for other_comp_key, other_pins in self.comp_pin_mapping.items():
            if other_comp_key == comp_key:
                continue
            for name in other_pins.values():
                if name:
                    other_used_names.add(name)

        # 过滤出未连接的 pin_key
        unconnected_keys = [
            key for key in target_pin_keys
            if comp_pins.get(key) not in other_used_names
        ]

        return unconnected_keys or None



    def _build_init_mapping(self):
        """
        初始化出元件库外的所有映射表

        :return: 当前模型中出现的所有元件类型 RID
        """
        logger.debug("开始构建映射表...")
        # ✅ 修复：调用正确的方法并接收对应数量的返回值
        comp_pin_mapping, bus_pin_mapping, channel_pin_mapping, seen_definitions= self._build_pin_mappings()
        logger.debug(f"引脚映射构建完成 - comp: {len(comp_pin_mapping)}, bus: {len(bus_pin_mapping)}, channel: {len(channel_pin_mapping)}")

        comp_label_mapping = self._build_label_mappings()
        logger.debug(f"标签映射构建完成 - {len(comp_label_mapping)} 个标签")

        node_to_edges, edge_to_nodes = self._build_node_edge_mapping()
        logger.debug(f"拓扑边映射构建完成 - {len(edge_to_nodes)} 条边")

        # 使用 clear() + update() 保持字典引用不变
        self.comp_label_mapping.clear()
        self.comp_label_mapping.update(comp_label_mapping)

        self.comp_pin_mapping.clear()
        self.comp_pin_mapping.update(comp_pin_mapping)

        self.bus_pin_mapping.clear()
        self.bus_pin_mapping.update(bus_pin_mapping)

        self.channel_pin_mapping.clear()
        self.channel_pin_mapping.update(channel_pin_mapping)

        self.node_to_edges.clear()
        self.node_to_edges.update(node_to_edges)

        self.edge_to_nodes.clear()
        self.edge_to_nodes.update(edge_to_nodes)
        
        return seen_definitions
            
    def _build_node_edge_mapping(self):
        """
        构建节点与边的拓扑映射

        :return: (node_to_edges, edge_to_nodes)
        """
        node_to_edges = {}
        edge_to_nodes = {}

        try:
            all_components = self.model.getAllComponents()
            if not all_components:
                logger.warning("模型中没有元件，返回空节点-边映射")
                return {}, {}

            for _, comp in all_components.items():
                if comp.shape != 'diagram-edge':
                    continue

                edge_id = comp.id
                source = comp.source.get('cell')
                target = comp.target.get('cell')

                if not source or not target:
                    logger.warning(f"边 {edge_id} 缺少 source 或 target，跳过")
                    continue

                # 为 source 和 target 分别记录这个 edge id
                for node in [source, target]:
                    if node not in node_to_edges:
                        node_to_edges[node] = set()
                    node_to_edges[node].add(edge_id)

                # 记录边与两端节点的关系 (O(1) 查找邻居的关键)
                edge_to_nodes[edge_id] = (source, target)

            return node_to_edges, edge_to_nodes
        except Exception as e:
            logger.error(f"构建节点-边映射失败: {e}")
            raise RuntimeError(f"节点-边映射构建失败: {str(e)}") from e



    def _build_label_mappings(self):
        """
        构建元件标签映射表

        :return: 标签到元件key的映射表
        """
        comp_label_mapping = {}

        try:
            all_components = self.model.getAllComponents()
            if not all_components:
                logger.warning("模型中没有元件，返回空标签映射")
                return {}

            for key in all_components.keys():
                comp = self.model.getComponentByKey(key)
                if comp and 'diagram-component' in comp.shape:
                    label = comp.label
                    comp_label_mapping[label] = key

            return comp_label_mapping
        except Exception as e:
            logger.error(f"构建标签映射失败: {e}")
            raise RuntimeError(f"标签映射构建失败: {str(e)}") from e


    def _build_pin_mappings(self):
        """
        构建元件引脚映射表

        此方法对拓扑进行两次遍历：
        1. 收集每个拓扑节点的所有现有引脚名称。
        2. 创建最终的映射 (`self.comp_pin_mapping`)，为没有名称的节点上的引脚生成新的唯一名称。
        同时，它还会为母线元件填充 `self.bus_pin_mapping`。

        :return: (comp_pin_mapping, bus_pin_mapping, channel_pin_mapping, seen_definitions)
        """

        topo_pin_name_dict = {}
        comp_pin_mapping = {} # 格式: {comp_key: {pin_idx: pin_value}}
        bus_pin_mapping = {} # 格式: {bus_comp_key: pin_value}
        channel_pin_mapping = {} # 格式: {pin_value: channel_comp_key}
        seen_definitions = set() # 当前模型中出现的所有元件类型 RID

        # 1. 获取最新拓扑
        try:
            topo = self.model.fetchTopology(maximumDepth=0)
        except Exception as e:
            logger.error(f"获取模型拓扑失败: {e}")
            raise RuntimeError(f"无法获取模型拓扑，映射表构建终止: {str(e)}") from e

        if not topo:
            raise RuntimeError("模型拓扑为空（topo is None），无法构建映射表")

        if not topo.components:
            logger.warning("模型拓扑中没有元件，返回空映射表")
            return {}, {}, {}, set()

        components = topo.components
        # TODO:存在两个元件使用同一个引脚编号的情况，需要完善。
        # NOTE：当在前端中对某个元件进行复制时，在底层cell中，新增元件和原元件的引脚编号是一样的，可能会导致其中某个元件的引脚名称被覆盖
        # 遍历 1：为每个拓扑节点ID收集现有的引脚名称
        for comp_id, comp_data in components.items():
            comp_key = comp_id.lstrip('/')
            comp_obj = self.model.getComponentByKey(comp_key)
            if not comp_obj:
                continue

            for pin_key, topo_node_id_str in comp_data.get('pins', {}).items():
                if not topo_node_id_str:
                    continue
                
                node_id = int(topo_node_id_str)
                pin_name = comp_obj.pins.get(pin_key)
                
                if pin_name:
                    # 确保给定 node_id 的引脚名称是唯一的
                    name_list = topo_pin_name_dict.setdefault(node_id, [])
                    if pin_name not in name_list:
                        name_list.append(pin_name)

        # 遍历 2：构建最终的引脚映射，必要时创建新名称
        auto_prefix = f'AutoPin_{time.strftime("%Y%m%d%H%M%S")}'
        pin_counter = 0
        for comp_id, comp_data in components.items():
            comp_key = comp_id.lstrip('/')
            comp_obj = self.model.getComponentByKey(comp_key)
            if not comp_obj:
                continue

            # 从元件原始引脚的深拷贝开始
            comp_pin_mapping[comp_key] = copy.deepcopy(comp_obj.pins)

            for pin_key, topo_node_id_str in comp_data.get('pins', {}).items():
                if not topo_node_id_str:
                    continue

                node_id = int(topo_node_id_str)
                
                # 如果有现有名称则使用，否则生成一个新名称
                pin_names = topo_pin_name_dict.get(node_id)
                if pin_names:
                    target_name = pin_names[0]
                else:
                    target_name = f"{auto_prefix}_{pin_counter}"
                    pin_counter += 1
                    # 存储新名称以保持一致性
                    topo_pin_name_dict[node_id] = [target_name]

                comp_pin_mapping[comp_key][pin_key] = target_name

            if comp_obj.definition == BUS_RID:
                # 对母线元件的特殊处理
                pin_values = list(comp_pin_mapping[comp_key].values())
                if pin_values:
                    bus_pin_mapping[comp_key] = pin_values[0]
            
            if comp_obj.definition == CHANNEL_RID:
                # 对通道元件的特殊处理
                pin0 = comp_obj.pins.get('0')
                channel_pin_mapping[str(pin0)] = comp_key

            # 收集当前模型中出现的所有元件类型（用于按需构建元件库）
            if comp_obj.definition:
                seen_definitions.add(comp_obj.definition)

        return comp_pin_mapping, bus_pin_mapping, channel_pin_mapping, seen_definitions
    
    def _build_comp_library(self, seen_definitions: Set):
        """
        构建元件库

        :param seen_definitions: 当前模型中出现的所有元件类型
        :return: None
        """
        logger.info("开始构建元件库...")
        comps = fetch_component_details_all()

        # 使用字典推导式一步到位
        self.comp_library.update({
            comp['rid'].split('/')[-1]: (
                self._create_library_cell(comp) if comp['rid'] in seen_definitions else {}
            )
            for comp in comps if 'rid' in comp
        })


    def _create_library_cell(self, comp: Dict):
        """
        创建元件库单元

        :param comp: 元件详细信息
        :return: 元件库单元
        """
        args = {}
        args_meta = {}
        parameters = comp['revision']['parameters']
        for param in parameters:
            #TODO: 有些参数不是手动设置的，需从指定的范围内选择
            for v in param['items']:
                args[v['key']] = v['value']
                description = v.get('description', '')
                if '<br/>' in description:
                    description = description.split('<br/>', 1)[0]
                args_meta[v['key']] = description
    
        pins = {}
        pins_meta = {}
        for pin in comp['revision']['pins']:
            pins[pin['key']] = ''
            pins_meta[pin['key']] = {"description": pin.get('description',''), "type": pin.get('connection', '')}

        size = {
            "height": comp['revision']['graphic']['height'],
            "width": comp['revision']['graphic']['width'],
        }
        cell = {
            "args": args,       # 参数默认值
            "args_meta": args_meta,   # 参数说明
            "pins": pins,       # 引脚
            "pins_meta": pins_meta,   # 引脚类型及说明
            "size": size,       # 元件尺寸
            }
        return cell
