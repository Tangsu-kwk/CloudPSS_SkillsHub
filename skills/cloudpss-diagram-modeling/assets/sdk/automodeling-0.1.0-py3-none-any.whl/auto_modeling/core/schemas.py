from enum import Enum
from typing import TypeVar, Generic, Optional, Any, Dict, Tuple, Annotated
from pydantic import BaseModel, Field

# 定义泛型变量，用于支持不同的 data 数据结构
T = TypeVar("T")

class ResultStatus(str, Enum):
    """业务执行状态枚举"""
    SUCCESS = "success"
    FAILED = "failed"
    PARTIAL = "partial_success"  # 支持部分成功场景

class ServiceResult(BaseModel, Generic[T]):
    """统一业务返回类"""
    status: ResultStatus = Field(..., description="执行状态")
    message: str = Field(..., description="提示信息")
    data: Optional[T] = Field(None, description="业务数据内容")
    partial_details: Optional[Dict[Any, Any]] = Field(None, description="用于批量操作，记录失败的元件")
    

    @property
    def is_success(self) -> bool:
        return self.status == ResultStatus.SUCCESS

    @classmethod
    def success(cls, data: T = None, message: str = "Success"):
        return cls(status=ResultStatus.SUCCESS, message=message, data=data)

    @classmethod
    def failed(cls, message: str, data: Any = None,partial_details: Dict[Any, Any] = None):
        return cls(status=ResultStatus.FAILED, message=message, data=data, partial_details=partial_details)
    
    @classmethod
    def partial(cls, message: str, data: T = None, partial_details: Dict[Any, Any] = None):
        return cls(status=ResultStatus.PARTIAL, message=message, data=data, partial_details=partial_details)