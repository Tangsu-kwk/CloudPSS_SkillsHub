from datetime import datetime
import logging
import os
import time
from typing import Optional, Dict, List
import uuid
import cloudpss





# 配置日志
def setup_logging():
    """
    配置日志

    :return: None
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

# 配置环境变量的获取
def safe_get_env(key: str, default: Optional[str] = None) -> str:
    """
    安全获取环境变量

    :param key: 环境变量名
    :param default: 默认值
    :return: 环境变量值

    Raises:
        RuntimeError: 如果环境变量不存在且没有默认值
    """
    value = os.getenv(key, default)
    if value is None:
        raise RuntimeError(f"环境变量 {key} 未设置")
    return value

# 配置唯一存储路径的生成
def generate_unique_path(
    project_key: str,
    base_path: str,
    file_prefix: str,
    file_extension: str = 'png',
) -> str:
    """
    统一生成存储路径

    :param project_key: 项目key
    :param base_path: 基础路径
    :param file_prefix: 文件名前缀
    :param file_extension: 文件扩展名
    :return: 统一的存储路径
    """
    now = datetime.now()
    
    # 唯一模式：生成带时间戳和随机位的唯一文件名
    timestamp = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
    unique_id = uuid.uuid4().hex[:6]
    filename = f"{file_prefix}_{timestamp}_{unique_id}.{file_extension}"

    # 构建统一的目录结构：项目/业务路径/年/月/日/文件名
    return f'{project_key}/{base_path}/{now.year}/{now.month}/{now.day}/{filename}'


def fetch_component_details_by_rid(rid: str) -> Dict:
    """
    通过rid获取元件的详细信息

    :param rid: 元件rid
    :return: 元件详细信息
    """
    query = """
    query t($rid: ResourceId!) {
        model(input: {rid: $rid}) {
            description
            name
            rid
            revision {
                graphic
                parameters
                pins
            }
        }
    }
    """
    
    variables = {
        "rid": rid
    }
    ret=cloudpss.utils.graphql_request(query,variables)
    return ret["data"]["model"]


def fetch_component_details_all() -> List:
    """
    获取所有元件的详细信息

    :return: 元件详细信息列表
    """
    query= "query($_a:ModelsInput!){models(input:$_a){count total items{rid name description tags keywords revision{graphic parameters pins documentation}}}}"
    variables= {
        "_a": {
            "orderBy": [
                "updatedAt<"
            ],
            "limit": 1000000,
            "owner": [
                "or",
                "CloudPSS"
            ],
            "tags": "project-category:component",
            "access": {
                "permission": 65536
            }
        }
    }
    ret=cloudpss.utils.graphql_request(query,variables)
    return ret['data']['models']['items']
