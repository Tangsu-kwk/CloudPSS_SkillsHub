"""Build detached SimStudio custom graphics using its archived local engine.

The Node.js helper contains standalone geometry/SVG/builder modules, with no
browser, network or application runtime. Dynamic conditions use Python
MiraScript with the builder's two flags, never the model's parameter scope.
"""
from copy import deepcopy
import json
import os
from pathlib import Path
import shutil
import subprocess


class GraphicRuntimeError(RuntimeError):
    """Local graphic runtime unavailable or failed; nothing has been saved."""


def _conditions(nodes):
    values = nodes.values() if isinstance(nodes, dict) else nodes if isinstance(nodes, list) else []
    expressions = set()
    for node in values:
        if not isinstance(node, dict) or node.get('shape') == 'port':
            continue
        expression = node.get('condition')
        if isinstance(expression, str):
            expression = expression.strip()
            if expression not in ('', 'true', 'false', '@PREVIEW', '@ICON', '!@PREVIEW', '!@ICON'):
                expressions.add(expression)
    if not expressions:
        return {}
    try:
        from mirascript import compile, VmContext
    except ImportError as exc:
        raise GraphicRuntimeError('Dynamic graphic conditions require mirascript==0.1.103') from exc
    results = {}
    for expression in sorted(expressions):
        try:
            script, diagnostics = compile(expression)
            if script is None:
                results[expression] = True
                continue
            result = script(VmContext({'@PREVIEW': False, '@ICON': False}))
            # Official evaluateCondition requires bool; all invalid expressions
            # and nonboolean results fall back to visible, including numbers.
            results[expression] = result if type(result) is bool else True
        except Exception:
            results[expression] = True
    return results


def custom_graphic(document):
    """Build graphic and normalize only this detached document after success.

    Node.js (>=18, full ICU) is required for custom drawing nodes. The installed
    package carries the engine; docs/public_client is only a verification input.
    An explicit save_document graphic_builder can still replace this backend.
    """
    from .project_hooks import default_graphic
    context = document.get('context', {}).get('graphic') or {}
    nodes = context.get('nodes')
    if not nodes:
        return default_graphic(document)
    executable = os.environ.get('AUTOMODELING_NODE') or shutil.which('node')
    if not executable:
        raise GraphicRuntimeError('Custom graphics require local Node.js >=18 (or AUTOMODELING_NODE)')
    payload = json.dumps({'document': document, 'conditions': _conditions(nodes)},
                         ensure_ascii=False, allow_nan=False)
    try:
        process = subprocess.run(
            [executable, str(Path(__file__).with_name('custom_graphic_runtime.cjs'))],
            input=payload, capture_output=True, text=True, encoding='utf8', timeout=30,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GraphicRuntimeError('Local custom graphic engine could not run') from exc
    if process.returncode:
        raise GraphicRuntimeError('Local custom graphic engine failed before save')
    try:
        response = json.loads(process.stdout)
        graphic = response['graphic']
        if not isinstance(graphic, dict) or not all(k in graphic for k in ('width', 'height', 'markup', 'attrs', 'pins')):
            raise ValueError('Invalid graphic response')
        normalized = response.get('context')
        if normalized is not None:
            if not isinstance(normalized, dict):
                raise ValueError('Invalid graphic context')
            document['context']['graphic'] = deepcopy(normalized)
        return deepcopy(graphic)
    except (KeyError, ValueError, TypeError) as exc:
        raise GraphicRuntimeError('Invalid local custom graphic engine response') from exc
