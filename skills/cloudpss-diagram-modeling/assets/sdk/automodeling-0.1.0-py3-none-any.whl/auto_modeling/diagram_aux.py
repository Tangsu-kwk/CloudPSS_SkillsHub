"""Text/link cells in caller-owned SDK Models; no browser, save or network calls."""
from copy import deepcopy
import math
from .diagram_edit import DiagramCellNotFoundError
from .diagram_batch import _OMITTED, _numeric_object, _string_number

_SHAPES = {"rect", "rounded-rect", "line", "ellipse-1", "ellipse-2", "ellipse-3"}
_STYLE = {"stroke": str, "stroke-width": float, "fill": str, "text": str,
          "font-size": float, "font-family": str}


class _DeletedCell:
    """Preserve browser null slots through SDK 5.0.9 serialization."""
    shape = None

    def toJSON(self):
        return None


def model_from_document(document):
    """Load a detached browser document, preserving deleted (null) cell slots.

    SDK 5.0.9's Model constructor otherwise raises on these slots. Use this
    loader for raw browser snapshots; ordinary SDK Models need no conversion.
    """
    from cloudpss import Model
    raw = deepcopy(document)
    cells = raw["revision"]["implements"]["diagram"]["cells"]
    deleted = [key for key, cell in cells.items() if cell is None]
    for key in deleted:
        del cells[key]
    model = Model(raw)
    for key in deleted:
        model.getAllComponents()[key] = _DeletedCell()
    # Deleted slots retain their insertion positions in the browser record.
    ordered = {key: model.getAllComponents()[key] for key in document["revision"]["implements"]["diagram"]["cells"]}
    model.getAllComponents().clear()
    model.getAllComponents().update(ordered)
    return model


def _style(style):
    if not isinstance(style, dict) or set(style) - set(_STYLE):
        raise TypeError("Unsupported style input")
    result = {}
    for key, value in style.items():
        if _STYLE[key] is str:
            if not isinstance(value, str): raise TypeError("Style text must be a string")
        elif type(value) not in (int, float) or not math.isfinite(value):
            raise TypeError("Style numeric value must be finite")
        result["--" + key] = _string_number(value) if type(value) in (int, float) else value
    return result


def _select(model, ids, shape, kind):
    if not isinstance(ids, list) or any(not isinstance(key, str) for key in ids):
        raise TypeError("ids must be a list of strings")
    cells = model.getAllComponents()
    selected = []
    # Validate in input order, as the published __check_diagram_cells does.
    for key in ids:
        if key not in cells or isinstance(cells[key], _DeletedCell):
            raise DiagramCellNotFoundError(key)
        if cells[key].shape != shape:
            raise ValueError(f"panic: Cell {key} is not a diagram {kind} element")
        selected.append(cells[key])
    return selected


def _new_cell(model, label, position, size, canvas, style, *, link=False, content=None, href=None, shape=None):
    if not isinstance(label, str) or not isinstance(canvas, str):
        raise TypeError("label and canvas must be strings")
    diagram = model.revision.implements.diagram
    if not any(c and c.get("key") == canvas for c in diagram.canvas):
        raise ValueError(f"panic: Canvas {canvas} not found")
    _numeric_object(position, ("x", "y"), "position")
    _numeric_object(size, ("width", "height"), "size")
    root = {"style": _style(style)}
    cells = model.getAllComponents()
    prefix = "link_" if link else "element_"
    counter = deepcopy(model.context.get("counter", {}))
    number = counter.get(prefix, 0)
    if type(number) is not int or number < 0:
        raise ValueError("Unsupported cell counter state")
    while True:
        number += 1
        key = prefix + str(number)
        if key not in cells: break
    counter[prefix] = number
    raw = {"id": key, "canvas": canvas, "shape": "link" if link else "element",
           "position": deepcopy(position), "size": deepcopy(size)}
    if link:
        root["link-shape"] = shape
        raw["href"] = href
    else:
        raw.update(align={"h": "stretch", "v": "stretch"}, tag="cwe-markdown",
                   properties={"srcdoc": content})
    raw["attrs"] = {"root": root, "label": {"text": label}}
    from cloudpss.model.implements.diagram import Component
    cell = Component(raw)
    cells[key] = cell
    model.context["counter"] = counter
    return key


def add_diagram_text(model, label, position, size, canvas, content, style):
    if not isinstance(content, str): raise TypeError("content must be a string")
    return _new_cell(model, label, position, size, canvas, style, content=content)


def get_diagram_texts(model, ids):
    return [{"id": c.id, "canvas": c.canvas, "label": deepcopy(c.attrs.get("label", {}).get("text")),
             "position": deepcopy(c.position), "size": deepcopy(c.size),
             "content": deepcopy(c.properties.get("srcdoc"))}
            for c in _select(model, ids, "element", "text")]


def update_diagram_texts(model, ids, content=_OMITTED):
    if content is not _OMITTED and not isinstance(content, str):
        raise TypeError("content must be a string")
    cells = _select(model, ids, "element", "text")
    if content is not _OMITTED:
        for cell in cells:
            cell.properties = {**deepcopy(cell.properties), "srcdoc": content}


def _find(model, shape, canvases, label):
    if canvases is not _OMITTED and (not isinstance(canvases, list) or
                                    any(not isinstance(c, str) for c in canvases)):
        raise TypeError("canvases must be a list of strings")
    if label is not _OMITTED and not isinstance(label, str):
        raise TypeError("label must be a string")
    result = []
    for cell in model.getAllComponents().values():
        if cell.shape != shape: continue
        text = cell.attrs.get("label", {}).get("text")
        if canvases is not _OMITTED and cell.canvas not in canvases: continue
        if label is not _OMITTED and text != label: continue
        result.append({"id": cell.id, "canvas": cell.canvas, "label": deepcopy(text if text is not None else "")})
    return result


def find_diagram_texts(model, canvases=_OMITTED, label=_OMITTED):
    return _find(model, "element", canvases, label)


def add_diagram_link(model, label, position, size, canvas, href, shape, style):
    if not isinstance(href, str):
        raise TypeError("href must be a string")
    if not isinstance(shape, str) or shape not in _SHAPES:
        raise TypeError("Invalid link shape")
    return _new_cell(model, label, position, size, canvas, style,
                     link=True, href=href, shape=shape)


def get_diagram_links(model, ids):
    return [{"id": c.id, "canvas": c.canvas,
             "label": deepcopy(c.attrs.get("label", {}).get("text")),
             "position": deepcopy(c.position), "size": deepcopy(c.size),
             "href": deepcopy(c.href),
             "shape": deepcopy(c.attrs.get("root", {}).get("link-shape"))}
            for c in _select(model, ids, "link", "link")]


def update_diagram_links(model, ids, href=_OMITTED, shape=_OMITTED):
    if href is not _OMITTED and not isinstance(href, str):
        raise TypeError("href must be a string")
    if shape is not _OMITTED and (not isinstance(shape, str) or shape not in _SHAPES):
        raise TypeError("Invalid link shape")
    cells = _select(model, ids, "link", "link")
    for cell in cells:
        if href is not _OMITTED:
            cell.href = href
        if shape is not _OMITTED:
            attrs = deepcopy(cell.attrs)
            attrs.setdefault("root", {})["link-shape"] = shape
            cell.attrs = attrs


def find_diagram_links(model, canvases=_OMITTED, label=_OMITTED):
    return _find(model, "link", canvases, label)
