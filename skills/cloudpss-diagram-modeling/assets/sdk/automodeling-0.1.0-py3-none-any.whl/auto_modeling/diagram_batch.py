"""Observed diagram edits/searches; operates only on caller-owned SDK Models."""
from copy import deepcopy
from collections import deque
import math
import re

from .diagram_edit import _selected_cells
from .component_model import compare_json

_OMITTED = object()


def _numeric_object(value, fields, name):
    if value is None:
        raise ValueError(f"Invalid input:\n  #/{name}: must be object")
    if not isinstance(value, dict) or set(value) != set(fields):
        raise TypeError(f"{name} requires {fields}")
    if any(type(value[k]) not in (int, float) or not math.isfinite(value[k]) for k in fields):
        raise TypeError(f"{name} requires finite numbers")


def _nodes(model, ids):
    if not isinstance(ids, list) or any(not isinstance(key, str) for key in ids):
        raise TypeError("ids must be a list of strings")
    cells = []
    for key in ids:
        cell = _selected_cells(model, [key])[0]
        if cell.shape.endswith("edge"):
            raise ValueError(f"panic: Cell {cell.id} is not a diagram node")
        cells.append(cell)
    return cells


def _input_object(value, types, name):
    """Observed AJV object validation (Zod validates outer fields separately)."""
    prefix = f"Invalid input:\n  #/{name}"
    if not isinstance(value, dict):
        raise ValueError(prefix + ": must be object")
    for key in types:
        if key not in value:
            raise ValueError(prefix + f": must have required property '{key}'")
    if set(value) - set(types):
        raise ValueError(prefix + ": must NOT have additional properties")
    for key, kind in types.items():
        v = value[key]
        valid = (type(v) in (int, float) and math.isfinite(v)) if kind == "number" else type(v) is bool
        if not valid:
            raise ValueError(prefix + f"/{key}: must be {kind}")


def _node_label(raw):
    value = raw.get("label")
    return value if value is not None else raw.get("attrs", {}).get("label", {}).get("text")


def get_diagram_nodes(model, ids):
    return [{"id": key, "canvas": deepcopy(raw.get("canvas")),
             "label": deepcopy(_node_label(raw)), "position": deepcopy(raw.get("position")),
             "size": deepcopy(raw.get("size"))}
            for key, cell in zip(ids, _nodes(model, ids)) for raw in [cell.toJSON()]]


def update_diagram_nodes(model, ids, position=_OMITTED, size=_OMITTED):
    for name, value, fields in (("position", position, ("x", "y")),
                                ("size", size, ("width", "height"))):
        if value is not _OMITTED:
            _input_object(value, dict.fromkeys(fields, "number"), name)
    cells = _nodes(model, ids)
    for cell in cells:
        if position is not _OMITTED:
            cell.position = deepcopy(position)
        if size is not _OMITTED:
            cell.size = deepcopy(size)


def _canvases(value):
    if value is not _OMITTED and (not isinstance(value, list)
                                  or any(not isinstance(v, str) for v in value)):
        raise TypeError("canvases must be a list of strings")


def find_diagram_nodes(model, canvases=_OMITTED, area=_OMITTED):
    _canvases(canvases)
    if area is not _OMITTED:
        _input_object(area, {"x": "number", "y": "number", "width": "number", "height": "number", "strict": "boolean"}, "area")

    out = []
    for cell in model.getAllComponents().values():
        if cell.shape is None:
            if canvases is not _OMITTED:
                continue
            if area is not _OMITTED:
                raise ValueError("Failed to convert value to number: nil")
            out.append({"id": None, "canvas": None, "label": None})
            continue
        if cell.shape.endswith("edge"):
            continue
        if canvases is not _OMITTED and cell.canvas not in canvases:
            continue
        if area is not _OMITTED:
            x, y, w, h = (area[k] for k in ("x", "y", "width", "height"))
            raw = cell.toJSON()
            position, size = raw.get('position') or {}, raw.get('size') or {}
            def number(value):
                from mirascript import to_string
                try:
                    if value is None or type(value) is bool:raise ValueError
                    return float(value)
                except (ValueError,TypeError):
                    raise ValueError('Failed to convert value to number: '+('nil'if value is None else to_string(value))) from None
            # Preserve the official lazy boolean evaluation: a strict area can
            # reject a node on position alone without reading its absent size.
            cx,cy = (number(position.get(k)) for k in ('x','y'))

            if area["strict"]:
                match = cx >= x and cy >= y and cx + number(size.get('width')) <= x + w and cy + number(size.get('height')) <= y + h
            else:
                match = cx + number(size.get('width')) > x and cy + number(size.get('height')) > y and cx < x + w and cy < y + h
            if not match:
                continue
        out.append({"id": cell.id, "canvas": deepcopy(cell.canvas),
                    "label": deepcopy(_node_label(cell.toJSON()))})
    return out


def update_diagram_edges(model, ids, source=_OMITTED, target=_OMITTED, vertices=_OMITTED,
                         *, definition_resolver=None):
    from .diagram_contract import terminal_input, check_terminal
    if not isinstance(ids, list) or any(not isinstance(key, str) for key in ids):
        raise TypeError('ids must be a list of strings')
    for name, value in (("source", source), ("target", target)):
        if value is not _OMITTED:
            terminal_input(value, name)
    if vertices is not _OMITTED and not isinstance(vertices, list):
        raise TypeError("vertices must be an array")
    if source is not _OMITTED and target is not _OMITTED and source == target:
        raise ValueError('panic: Edge source and target cannot be the same')
    edges = []
    for key in ids:
        edge = _selected_cells(model, [key])[0]
        if not edge.shape.endswith('edge'):
            raise ValueError(f'panic: Cell {key} is not a diagram edge')
        edges.append(edge)
    if vertices is not _OMITTED:
        for point in vertices:
            _input_object(point, {'x': 'number', 'y': 'number'}, 'vertices')
    for name, value, other in (("source", source, target), ("target", target, source)):
        if value is _OMITTED:
            continue
        canvas = check_terminal(model, value, name, definition_resolver)
        for key, edge in zip(ids, edges):
            if edge.canvas != canvas:
                raise ValueError(f'panic: Edge {key} is not on the same canvas as the new {name}')
            opposite = edge.target if name == 'source' else edge.source
            if other is _OMITTED and value == opposite:
                raise ValueError(f'panic: Edge {key} source and target cannot be the same')
    for edge in edges:
        for name, value in (("vertices", vertices), ("source", source), ("target", target)):
            if value is not _OMITTED:
                setattr(edge, name, deepcopy(value))


def find_diagram_edges(model, canvases=_OMITTED, terminals=_OMITTED):
    _canvases(canvases)
    if terminals is not _OMITTED:
        if not isinstance(terminals, list) or any(
                not isinstance(t, dict) or "cell" not in t or set(t) - {"cell", "port"}
                or any(not isinstance(v, str) for v in t.values()) for t in terminals):
            raise TypeError("terminals must be an array of cell/optional port objects")
    out = []
    for cell in model.getAllComponents().values():
        if cell.shape != "diagram-edge":
            continue
        if canvases is not _OMITTED and cell.canvas not in canvases:
            continue
        if terminals is not _OMITTED and not any(
                all(end.get(k) == v for k, v in terminal.items())
                for end in (cell.source, cell.target) for terminal in terminals):
            continue
        out.append({k: deepcopy(getattr(cell, k)) for k in ("id", "canvas", "source", "target")})
    return out


def _components(model, ids):
    cells = _selected_cells(model, ids)
    for cell in cells:
        if cell.shape != "diagram-component":
            raise ValueError(f"panic: Cell {cell.id} is not a diagram component")
    return cells


def update_diagram_components_props(model, ids, props):
    if not isinstance(props, dict) or set(props) - {"enabled", "outlineLevel"}:
        raise TypeError("props must contain only enabled/outlineLevel")
    if "enabled" in props and type(props["enabled"]) is not bool:
        raise TypeError("enabled must be boolean")
    if "outlineLevel" in props and (type(props["outlineLevel"]) not in (int, float)
                                   or not math.isfinite(props["outlineLevel"])):
        raise TypeError("outlineLevel must be numeric")
    cells = _components(model, ids)
    prepared = [(cell, {**deepcopy(cell.props), **deepcopy(props)}) for cell in cells]
    for cell, value in prepared:
        cell.props = value


def update_diagram_components_pins(model, ids, pins):
    if not isinstance(pins, dict):
        raise TypeError("pins must be an object")
    cells = _components(model, ids)
    for cell in cells:
        for key, value in pins.items():
            if key not in cell.pins:
                raise ValueError(f"Unknown pin: {key}")
            expression = (isinstance(value, dict) and set(value) == {"source", "ɵexp"}
                          and isinstance(value["source"], str) and value["ɵexp"] == "")
            if not isinstance(value, str) and not expression:
                kind = {int: "number", float: "number", bool: "boolean", type(None): "nil"}.get(type(value), "object")
                raise ValueError(f"Pin {key} has invalid type: expected string or expression, got {kind}")
    prepared = [(cell, {**deepcopy(cell.pins), **deepcopy(pins)}) for cell in cells]
    for cell, value in prepared:
        cell.pins = value


def _string_number(value):
    # Official handlers interpolate through MiraScript, not JS String(number).
    from mirascript import to_string
    return to_string(value)


def update_diagram_cells(model, ids, label=_OMITTED, style=_OMITTED):
    if label is not _OMITTED and not isinstance(label, str):
        raise TypeError("label must be a string")
    if style is None:
        raise ValueError("Invalid input:\n  #/style: must be object")
    allowed = {"stroke": str, "stroke-width": float, "fill": str, "text": str,
               "font-size": float, "font-family": str}
    if style is not _OMITTED:
        if not isinstance(style, dict):
            raise ValueError("Invalid input:\n  #/style: must be object")
        if set(style) - set(allowed):
            raise ValueError("Invalid input:\n  #/style: must NOT have additional properties")
        for key, value in style.items():
            if allowed[key] is str:
                if not isinstance(value, str):
                    raise ValueError(f"Invalid input:\n  #/style/{key}: must be string")
            elif type(value) not in (int, float) or not math.isfinite(value):
                raise ValueError(f"Invalid input:\n  #/style/{key}: must be number")
    cells = _selected_cells(model, ids)
    prepared = []
    for cell in cells:
        raw = deepcopy(cell.toJSON())
        if label is not _OMITTED:
            if cell.shape in ("diagram-component", "diagram-component-edge"):
                raw["label"] = label
            elif cell.shape != "diagram-edge":
                raw.setdefault("attrs", {}).setdefault("label", {})["text"] = label
        if style is not _OMITTED:
            target = (raw.setdefault("style", {}) if cell.shape == "diagram-component" else
                      raw.setdefault("attrs", {}).setdefault("root", {}).setdefault("style", {}))
            target.update({"--" + k: _string_number(v) if type(v) in (int, float) else v
                           for k, v in style.items()})
        prepared.append((cell, raw))
    for cell, raw in prepared:
        cell.__dict__.update(raw)


def find_diagram_components(model, canvases=None, definitions=None, labels=None, args=None):
    for value in (canvases, definitions, labels):
        if value is not None and (not isinstance(value, list) or any(not isinstance(v, str) for v in value)):
            raise TypeError("Filters must be lists of strings")
    if definitions is not None and any(not re.fullmatch(r"model/[^/]+/[^/]+", rid) for rid in definitions):
        raise ValueError("参数 rid 必须是模型的资源 ID")
    if args is not None and not isinstance(args, dict):
        raise TypeError("args must be an object")
    out = []
    for cell in model.getAllComponents().values():
        raw = cell.toJSON() or {}
        if raw.get('definition') is None:
            continue
        if canvases is not None and raw.get('canvas') not in canvases:
            continue
        if definitions is not None and raw['definition'] not in definitions:
            continue
        if labels is not None and raw.get('label') not in labels:
            continue
        if args is not None and any(compare_json((raw.get('args') or {}).get(k), v) for k, v in args.items()):
            continue
        out.append({key: deepcopy(raw.get(key)) for key in ("id", "canvas", "definition", "label")})
    return out


def connected_diagram_components(model, ids, min_depth=0, max_depth=1):
    min_depth = 0 if min_depth is None else min_depth
    max_depth = 1 if max_depth is None else max_depth
    if any(type(v) not in (int, float) or not math.isfinite(v) for v in (min_depth, max_depth)):
        raise TypeError('depth must be a finite number')
    _selected_cells(model, ids)
    cells = {key: cell.toJSON() or {} for key, cell in model.getAllComponents().items()}
    adjacency = {}
    for key, cell in cells.items():
        if cell.get('shape') != 'diagram-edge':
            continue
        source = (cell.get('source') or {}).get('cell')
        target = (cell.get('target') or {}).get('cell')
        if source is None or target is None:
            continue
        for other in (source, target):
            if other in cells and key not in adjacency.setdefault(other, []):
                adjacency[other].append(key)
    queue = deque((key, 0) for key in ids)
    visited = set(ids)
    selected = {'components': [], 'edges': []}
    while queue:
        key, depth = queue.popleft()
        cell = cells[key]
        is_edge = cell.get('shape') == 'diagram-edge'
        group = 'edges' if is_edge else 'components'
        if min_depth <= depth <= max_depth and key not in selected[group]:
            selected[group].append(key)
        if depth >= max_depth:
            continue
        neighbors = [(cell.get(end) or {}).get('cell') for end in ('source', 'target')] if is_edge else adjacency.get(key, [])
        for neighbor in neighbors:
            if neighbor is not None and neighbor in cells and neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, depth + 1))
    return {'components': [{'id': key, 'canvas': deepcopy(cells[key].get('canvas')),
                            'definition': deepcopy(cells[key].get('definition'))} for key in selected['components']],
            'edges': [{end: {field: deepcopy((cells[key].get(end) or {}).get(field))
                            for field in ('cell', 'port')} for end in ('source', 'target')}
                      for key in selected['edges']]}
