"""Prepare and check a model's connections without fetching or mutating it.

This is the diagram connection stage, not complete run_check. Definitions are
explicit inputs. Constraints and translated MCP messages are not implemented.
Unsupported evaluation raises instead of reporting an unchecked model as clean.
"""
from copy import deepcopy
import math
import re

from .connection_checks import check_connection_groups
from .job_inputs import (_Scope, _fields, _convert, _expression, _number,
                         _FAIL, _js_truth, _json_numbers, evaluate_args)


class _DiagramScope(_Scope):
    def __init__(self, local, owner, document, global_values):
        super().__init__(local, owner, document)
        self.global_values = global_values

    def __getitem__(self, key):
        if key.startswith('$') and key not in ('$', '$$'):
            if key[1:] not in self.global_values:
                raise KeyError(key)
            return deepcopy(self.global_values[key[1:]])
        return super().__getitem__(key)


def _evaluate(scope, value):
    return scope.evaluate(value, None)


def _condition(scope, value):
    if value is None or value == '':
        return True
    if isinstance(value, str):
        value = {'source': value, 'ɵexp': ''}
    return _js_truth(_evaluate(scope, value))


def _js_entries(value):
    # JavaScript Object.entries visits canonical uint32 index keys first.
    indices = sorted((k for k in value if isinstance(k, str) and k.isascii()
                      and k.isdigit() and str(int(k)) == k and int(k) < 2**32-1), key=int)
    return [(key, value[key]) for key in indices] + [(k, v) for k, v in value.items() if k not in indices]


def _args(raw, parameters, owner, document, globals_):
    local = deepcopy(raw)
    fields = _fields(parameters)
    for field in fields:
        key = field['key']
        value = local.get(key)
        if value is None:
            value = deepcopy(field.get('value'))
            if _expression(value):
                value['ɵexp'] = ''
        if not _expression(value):
            value = _convert(value, field, value)
        local[key] = value
    scope = _DiagramScope(local, owner, document, globals_)
    return {f['key']: _convert(_evaluate(scope, local[f['key']]), f,
                              deepcopy(f.get('value'))) for f in fields}


def check_diagram_connections(model, *, definitions):
    """Return edge/connection problem records from an SDK Model or document.

    Does not run parameter constraints, cases/definition/graphic checks or the
    MCP translation stage. Channel/bus pins use evaluated arguments and stable
    row identities. Missing definitions or identities raise; no API calls occur.
    """
    document = deepcopy(model if isinstance(model, dict) else model.toJSON())
    revision = document['revision']
    diagram = revision.get('implements', {}).get('diagram')
    if diagram is None:
        return []
    configs = document.get('configs', [])
    index = document.get('context', {}).get('currentConfig', 0)
    if type(index) is not int or index < 0 or index >= len(configs):
        raise ValueError('No valid current parameter scheme')
    globals_ = evaluate_args(configs[index].get('args', {}), revision.get('parameters', []))
    for variable in diagram.get('variables', []):
        key = variable.get('key')
        if not isinstance(key, str) or not key.isidentifier() or key in globals_:
            raise NotImplementedError('Invalid or duplicate diagram variable')
        globals_[key] = variable.get('value')
    # Resolve diagram globals lazily with the same $key naming used by locals.
    variable_scope = _DiagramScope({}, None, document, globals_)
    resolving = set()
    def resolve_global(key):
        value = globals_[key]
        if _expression(value):
            if key in resolving:
                raise ValueError('Cyclic diagram variable expression')
            resolving.add(key)
            try:
                globals_[key] = _evaluate(variable_scope, value)
            finally:
                resolving.remove(key)
        return deepcopy(globals_[key])
    class GlobalScope(_DiagramScope):
        def __getitem__(self, key):
            if key.startswith('$') and key not in ('$', '$$'):
                return resolve_global(key[1:])
            return super().__getitem__(key)
    variable_scope = GlobalScope({}, None, document, globals_)
    for key in list(globals_):
        resolve_global(key)
    cells = diagram.get('cells', {})
    components, edges, scopes, loaded = {}, {}, {}, {}
    pinlike_keys = {}
    for key, cell in _js_entries(cells):
        if cell is None:
            continue
        shape = cell.get('shape', '')
        if shape in ('diagram-component', 'diagram-component-edge'):
            rid = cell['definition']
            definition = rid if isinstance(rid, dict) else definitions.get(rid)
            if not isinstance(definition, dict):
                raise NotImplementedError(f'Missing component definition: {rid}')
            defs = definition['revision']
            cell['args'] = _args(cell.get('args', {}), defs.get('parameters', []), cell, document, globals_)
            from .dynamic_pins import check_pin_definitions, pinlike_pins
            defs=deepcopy(defs)
            defs['pins']=check_pin_definitions(definition,cell['args'])
            # Named pinLike parameters are terminals stored in args, not in pins;
            # they keep the arg-keyed node path used by the parameter loop below.
            pinlike_keys[key]={p['key'] for p in pinlike_pins(defs,cell['args'])}
            scope = _DiagramScope(cell['args'], cell, {'revision': revision}, globals_)
            raw_enabled = (cell.get('props') or {}).get('enabled')
            enabled = True if raw_enabled is None else _evaluate(scope, raw_enabled)
            components[key] = {'definition': rid, 'enabled': _js_truth(enabled)}
            scopes[key], loaded[key] = scope, defs
            # defaultPins then expression evaluation. Undefined ordinary keys
            # are removed by the browser argument checker before topology.
            from mirascript import to_string
            raw_pins = cell.get('pins') or {}
            cell['pins'] = {p['key']: to_string(_evaluate(scope,
                            '' if raw_pins.get(p['key']) is None else raw_pins[p['key']]), '')
                            for p in defs.get('pins', [])}
        elif shape.endswith('-edge'):
            edges[key] = cell
    groups, port_group, pins, pin_info, dimensions, problems = {}, [], {}, {}, {}, []
    def terminal(value):
        return isinstance(value, dict) and isinstance(value.get('cell'), str)
    def edge_end(edge_id, group, end, value):
        nodes = groups.setdefault(group, [])
        target = value['cell']
        if target in edges:
            nodes.append(target)
        elif target in components:
            if any(p['key'] == value.get('port') for p in loaded[target].get('pins', [])):
                nodes.append(f"{target}.pins.{value.get('port')}")
            elif value.get('port') in pinlike_keys.get(target, ()):
                nodes.append(f"{target}.args.{value.get('port')}")
            else:
                edge_problem(edge_id, end, 'no such pin', 'error', component=target,
                             componentName=cells[target].get('label', target), pin=value.get('port'))
        elif not cells.get(target):
            edge_problem(edge_id, end, 'no such component', 'error', component=target)
    def edge_problem(key, end, code, level='warning', **data):
        problems.append({'message': f'edge terminal:{code}', 'level': level,
                         'data': {'path': f'revision.implements.diagram.cells.{key}.{end}',
                                  'key': key, 'terminal': end, **data}})
    for key, edge in edges.items():
        groups[key] = []
        for end in ('source', 'target'):
            value = edge.get(end)
            if terminal(value):
                edge_end(key, key, end, value)
            else:
                edge_problem(key, end, 'no link')
    def register(key, field, location, label, visible=None):
        path = f'{key}.{location}.{field["key"]}'
        port_group.append(path)
        if not components[key]['enabled']:
            return
        pins[path] = deepcopy(field)
        if visible is not None:
            pins[path]['visible'] = visible
        pin_info[path] = {'key': key, 'componentName': cells[key].get('label', key),
                          'pin': field['key'], 'pinName': field.get('name') or field['key'],
                          'path': f'revision.implements.diagram.cells.{path}'}
        if label:
            if not isinstance(label, str):
                from mirascript import to_string
                label = to_string(label)
            label = re.sub(r':[RIEA]$', '', label)
            groups.setdefault(label, []).append(path)
    for key, defs in loaded.items():
        cell, scope = cells[key], scopes[key]
        for group in defs.get('parameters', []):
            for field in group['items']:
                if field.get('type') != 'pinLike' or not cell['args'].get(field['key']):
                    continue
                if not _condition(scope, group.get('condition')):
                    break
                if _condition(scope, field.get('condition')):
                    register(key, field, 'args', cell['args'][field['key']], True)
        if cell['shape'] == 'diagram-component-edge':
            for i, end in enumerate(('source', 'target')):
                if i < len(defs.get('pins', [])) and terminal(cell.get(end)):
                    group = f'{key}::{end}'
                    groups[group] = [f'{key}.pins.{defs["pins"][i]["key"]}']
                    edge_end(key, group, end, cell[end])
        for field in defs.get('pins', []):
            if _condition(scope, field.get('condition')):
                register(key, field, 'pins', cell['pins'][field['key']])
    # Connected components of edge IDs and terminals. Preserve first occurrence
    # order in each group; exact cross-group ordering is tested against source.
    parent = {}
    def find(key):
        parent.setdefault(key, key)
        while parent[key] != key:
            parent[key] = parent[parent[key]]
            key = parent[key]
        return key
    for group, nodes in _js_entries(groups):
        for node in nodes:
            parent[find(node)] = find(group)
    merged = {}
    for group, nodes in _js_entries(groups):
        merged.setdefault(find(group), []).extend(nodes)
    # Dimensions are lazy: unconnected/invalid nets do not evaluate them in MCP.
    class Dimensions(dict):
        def __getitem__(self, path):
            field, info = pins[path], pin_info[path]
            result = []
            raw = field.get('dim') or []
            for value in [raw[i] if i < len(raw) else 0 for i in range(2)]:
                source = str(value or 0)
                number = _number(_evaluate(scopes[info['key']], {'source': source, 'ɵexp': ''}))
                if number is _FAIL or not math.isfinite(number):
                    raise NotImplementedError('Invalid pin dimension requires expression diagnostic support')
                result.append(number)
            return result
    problems.extend(check_connection_groups(dict(_js_entries(merged)), components=components, pins=pins,
                    pin_info=pin_info, port_group=port_group, dimensions=Dimensions()))
    return _json_numbers(problems)
