"""Definition-aware primitives used by official diagram edit handlers.

Definitions default to independent GraphQL reads; callers may inject a resolver
for cached/offline operation. Never saves, evaluates expressions or runs jobs.
"""
from copy import deepcopy
import re
import unicodedata
from .scheme_args import _kind
from .job_inputs import _expression


def resolve_definition(rid, resolver=None):
    if resolver is None:
        from .component_model import get_component_model
        resolver = get_component_model
    return resolver(rid)


def new_id(model, prefix, *, cell=False):
    if prefix.startswith('component_') and prefix.endswith('_'):
        # Public lodash words includes number boundaries and ordinal suffixes.
        # Splitting only camelCase incorrectly turns newBus3p into new_bus3p.
        prefix = ''.join(c for c in unicodedata.normalize('NFD', prefix)
                         if not unicodedata.combining(c))
        prefix = prefix.replace("'", '').replace('’', '')
        lower = r'(?:[a-z]|[^\W\d_a-zA-Z])'
        upper = r'(?:[A-Z]|[^\W\d_a-zA-Z])'
        words = re.findall(
            rf'[A-Z]?{lower}+(?=[A-Z0-9_]|$)|{upper}+(?=[A-Z]{lower}|[0-9_]|$)|'
            rf'[A-Z]?{lower}+|[A-Z]+|'
            r'[0-9]*(?:1ST|2ND|3RD|(?![123])[0-9]TH)(?=\b|[a-z_])|'
            r'[0-9]*(?:1st|2nd|3rd|(?![123])[0-9]th)(?=\b|[A-Z_])|'
            r'[0-9]+|[^\W\d_a-zA-Z]+', prefix)
        prefix = '_'.join(words).lower() + '_'
    if not hasattr(model, 'context'):
        model.context = {}
    counter = model.context.setdefault('counter', {})
    number = counter.get(prefix, 0)
    if type(number) is not int or number < 0:
        raise ValueError('Unsupported cell counter state')
    while True:
        number += 1
        counter[prefix] = number
        key = prefix + str(number)
        if not cell or key not in model.getAllComponents():
            return key


def default_pins(definitions, values):
    result = deepcopy(values)
    if not definitions:
        return result
    from mirascript import to_string
    keys = {pin['key'] for pin in definitions}
    for key in keys:
        value = result.get(key)
        result[key] = '' if value is None else (deepcopy(value) if
            isinstance(value, str) or _expression(value) else to_string(value))
    for key in list(result):
        if key not in keys and not key.startswith(('_', '$', '@', 'ɵ')):
            del result[key]
    return result


def fill_pins(original, updating, definitions):
    converted = default_pins(definitions, updating)
    result = deepcopy(original)
    for key, value in updating.items():
        if key not in converted:
            raise ValueError(f'Unknown pin: {key}')
        if not isinstance(value, str) and not _expression(value):
            raise ValueError(f'Pin {key} has invalid type: expected string or expression, got {_kind(value)}')
        result[key] = deepcopy(converted[key])
    return result


def terminal_input(value, name):
    prefix = f'Invalid input:\n  #/{name}'
    if not isinstance(value, dict):
        raise ValueError(prefix + ': must be object')
    for field in ('cell', 'port'):
        if field not in value:
            raise ValueError(prefix + f": must have required property '{field}'")
    if set(value) - {'cell', 'port'}:
        raise ValueError(prefix + ': must NOT have additional properties')
    for field in ('cell', 'port'):
        if not isinstance(value[field], str):
            raise ValueError(prefix + f'/{field}: must be string')


def check_terminal(model, terminal, side, resolver=None):
    key, port = terminal['cell'], terminal['port']
    cell = model.getAllComponents().get(key)
    raw = cell.toJSON() if cell is not None else None
    if raw is None:
        raise ValueError(f'panic: Edge {side} cell {key} not found')
    if raw.get('shape') != 'diagram-component':
        raise ValueError(f'panic: Edge {side} cell {key} is not a diagram component')
    definition = raw.get('definition')
    model_def = resolve_definition(definition, resolver)
    if model_def is None:
        raise ValueError(f'panic: Edge {side} cell {key} definition {definition} not found')
    if not any(pin.get('key') == port for pin in model_def['pins']):
        raise ValueError(f'panic: Edge {side} cell {key} port {port} not found')
    return raw.get('canvas')
