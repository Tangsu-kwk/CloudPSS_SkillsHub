"""Memory-only adapters for the observed public add-component/add-edge cases.

These functions reproduce diagram structure, not proven electrical validity.
Definitions are resolved independently through GraphQL or an injected resolver.
"""

from copy import deepcopy
import math


class DiagramCellNotFoundError(KeyError):
    """Observed missing-cell business failure; core API uses Python exceptions."""
    def __init__(self, key):
        self.key = key
        super().__init__(key)

    def __str__(self):
        return f"panic: Cell {self.key} not found"


def _selected_cells(model, ids):
    if not isinstance(ids, list) or any(not isinstance(key, str) for key in ids):
        raise TypeError("ids must be a list of strings")
    cells = model.getAllComponents()
    for key in ids:
        if key not in cells or cells[key] is None or cells[key].toJSON() is None:
            raise DiagramCellNotFoundError(key)
    return [cells[key] for key in ids]


def _point(value, fields, name):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise ValueError(f"{name} requires {fields}")
    if any(type(value[k]) not in (int, float) or not math.isfinite(value[k]) for k in fields):
        raise ValueError(f"{name} requires finite numbers")


def add_diagram_component(model, definition, position, canvas, args, pins, label=None, size=None,
                          *, definition_resolver=None):
    """Add a definition-validated component, including editor defaults.

    Omitted size stays absent. Counter allocation precedes parameter validation,
    as on the public handler; an invalid update may consume IDs. Expressions
    remain unevaluated. Definitions use GraphQL unless a resolver is supplied.
    """
    from .diagram_contract import resolve_definition, new_id, fill_pins, default_pins
    from .scheme_args import fill_args, default_args
    from .diagram_batch import _input_object
    from cloudpss.model.implements.diagram import Component
    if not isinstance(definition, str) or not definition:
        raise ValueError("definition must be a non-empty RID")
    if label is not None and not isinstance(label, str):
        raise TypeError("label must be a string or None")
    if not isinstance(args, dict) or not isinstance(pins, dict):
        raise TypeError("args and pins must be objects")
    if not any(c and c.get("key") == canvas for c in model.revision.implements.diagram.canvas):
        raise ValueError(f"panic: Canvas {canvas} not found")
    _input_object(position, {"x": "number", "y": "number"}, "position")
    if size is not None:
        _input_object(size, {"width": "number", "height": "number"}, "size")
    model_def = resolve_definition(definition, definition_resolver)
    if model_def is None:
        raise ValueError(f"panic: Model with rid {definition} not found")
    key = new_id(model, 'component_' + definition.rsplit('/', 1)[-1] + '_', cell=True)
    actual_label = label if label is not None else new_id(model, model_def['name'])
    updated_args = fill_args({}, args, model_def['parameters'])
    updated_pins = fill_pins({}, pins, model_def['pins'])
    raw = {"id": key, "canvas": canvas, "shape": "diagram-component", "definition": definition,
           "position": deepcopy(position), "label": actual_label,
           "args": default_args(model_def['parameters'], updated_args),
           "pins": default_pins(model_def['pins'], updated_pins), "context": {},
           "props": {"enabled": True, "outlineLevel": 0}, "style": {}}
    if size is not None:
        raw['size'] = deepcopy(size)
    model.getAllComponents()[key] = Component(raw)
    return key


def add_diagram_edge(model, source, target, vertices=None, *, definition_resolver=None):
    """Add an edge with definition-level ports; pin labels are unchanged."""
    from .diagram_contract import terminal_input, check_terminal, new_id
    from .diagram_batch import _input_object
    from cloudpss.model.implements.diagram import Component
    terminal_input(source, 'source')
    terminal_input(target, 'target')
    if source == target:
        raise ValueError('panic: Edge source and target cannot be the same')
    source_canvas = check_terminal(model, source, 'source', definition_resolver)
    target_canvas = check_terminal(model, target, 'target', definition_resolver)
    if source_canvas != target_canvas:
        raise ValueError('panic: Edge source and target must be on the same canvas')
    if vertices is not None and not isinstance(vertices, list):
        raise TypeError('vertices must be an array')
    key = new_id(model, 'edge_', cell=True)
    for point in vertices or []:
        _input_object(point, {'x': 'number', 'y': 'number'}, 'vertices')
    marker = {"args": {"cx": 0, "r": 0.5}, "fill": "var(--context-stroke)", "name": "circle"}
    attrs = {"line": {"sourceMarker": deepcopy(marker), "targetMarker": deepcopy(marker)},
             "root": {"style": {"--stroke": "var(--edge-stroke)", "--stroke-opacity": 1, "--stroke-width": 2}}}
    model.getAllComponents()[key] = Component({"id": key, "attrs": attrs,
        "source": deepcopy(source), "target": deepcopy(target), "shape": "diagram-edge",
        "vertices": deepcopy(vertices) if vertices is not None else [], "canvas": target_canvas})
    return key


def add_dynamic_diagram_edge(model, source, target, vertices=None, *, definition_resolver=None):
    """Add an edge whose terminal may be generated from component arguments.

    ``add_diagram_edge`` deliberately implements the public MCP contract and
    accepts definition-level pins only.  Some SDK models expose additional
    terminals (for example ``ɵid-*`` table rows) after their arguments are
    evaluated.  This explicit SDK extension validates those terminals from the
    component's own definition and arguments before creating the same detached
    edge object. Definitions use independent GraphQL by default. It never
    saves, runs, changes selection, or mutates component pins.

    The extension is intentionally separate from the MCP-named function: a
    caller cannot accidentally broaden MCP input semantics by using the SDK.
    """
    from .diagram_contract import terminal_input, resolve_definition, new_id
    from .dynamic_pins import instance_pin_definitions
    from .diagram_batch import _input_object
    from cloudpss.model.implements.diagram import Component

    terminal_input(source, 'source')
    terminal_input(target, 'target')
    if source == target:
        raise ValueError('panic: Edge source and target cannot be the same')

    cells = model.getAllComponents()
    canvases = {}
    for side, terminal in (('source', source), ('target', target)):
        cell = cells.get(terminal['cell'])
        raw = cell.toJSON() if cell is not None else None
        if raw is None:
            raise ValueError(f'panic: Edge {side} cell {terminal["cell"]} not found')
        if raw.get('shape') != 'diagram-component':
            raise ValueError(f'panic: Edge {side} cell {terminal["cell"]} is not a diagram component')
        definition = resolve_definition(raw.get('definition'), definition_resolver)
        if definition is None:
            raise ValueError(f'panic: Edge {side} cell {terminal["cell"]} definition {raw.get("definition")} not found')
        # Dynamic pin evaluation is pure.  The helper returns ordinary pins for
        # definitions without generated terminals.
        generated = instance_pin_definitions(model, raw, definition)
        if not any(pin.get('key') == terminal['port'] for pin in generated):
            raise ValueError(f'panic: Edge {side} cell {terminal["cell"]} port {terminal["port"]} not found')
        canvases[side] = raw.get('canvas')
    if canvases['source'] != canvases['target']:
        raise ValueError('panic: Edge source and target must be on the same canvas')
    if vertices is not None and not isinstance(vertices, list):
        raise TypeError('vertices must be an array')
    for point in vertices or []:
        _input_object(point, {'x': 'number', 'y': 'number'}, 'vertices')
    key = new_id(model, 'edge_', cell=True)
    marker = {"args": {"cx": 0, "r": 0.5}, "fill": "var(--context-stroke)", "name": "circle"}
    attrs = {"line": {"sourceMarker": deepcopy(marker), "targetMarker": deepcopy(marker)},
             "root": {"style": {"--stroke": "var(--edge-stroke)", "--stroke-opacity": 1, "--stroke-width": 2}}}
    model.getAllComponents()[key] = Component({"id": key, "attrs": attrs,
        "source": deepcopy(source), "target": deepcopy(target), "shape": "diagram-edge",
        "vertices": deepcopy(vertices) if vertices is not None else [], "canvas": canvases['target']})
    return key


def get_diagram_edges(model, ids):
    """Return detached edge projections; helper for structural verification."""
    result = []
    for edge in _selected_cells(model, ids):
        if not isinstance(edge.shape, str) or not edge.shape.endswith('edge'):
            raise ValueError(f"panic: Cell {edge.id} is not a diagram edge")
        raw = edge.toJSON()
        result.append({field: deepcopy(raw.get(field))
                       for field in ("id", "canvas", "source", "target", "vertices")})
    return result


def get_diagram_cells(model, ids):
    """Return the public cell projection; no geometry or inferred defaults."""
    result = []
    for cell in _selected_cells(model, ids):
        raw = cell.toJSON()
        item = {field: deepcopy(raw[field]) for field in ("id", "canvas", "shape")}
        # Saved editor cells store style under attrs.root.style; API-created
        # cells in the observed SDK representation expose it at the top level.
        style = raw.get('style')
        if style is None:
            style = raw.get('attrs', {}).get('root', {}).get('style')
        item["style"] = deepcopy(style)
        label = raw.get('attrs', {}).get('label', {}).get('text')
        if label is None:
            label = raw.get('label')
        if label is not None:
            item["label"] = deepcopy(label)
        result.append(item)
    return result


def delete_diagram_cells(model, ids):
    """Remove requested cells and incident edges from a caller-owned model.

    Validates all IDs before mutation and visits each requested cell's incident
    edges recursively, in insertion order. Receipts deduplicate and preserve
    text/link labels. Deleted keys remain null slots, matching the browser.
    Does not save, run, alter pin labels, or maintain browser history.
    """
    _selected_cells(model, ids)
    cells = model.getAllComponents()
    # Official handler recursively visits incident edges for EACH requested cell.
    # A global edge-first sort changes receipts for disjoint requested nodes.
    order, visited, active = [], set(), set()
    def remove(key):
        if key in visited:
            return
        if key in active:
            raise ValueError("Cyclic edge references cannot be deleted recursively")
        active.add(key)
        for other, cell in cells.items():
            if getattr(cell, "shape", None) in ("diagram-edge", "diagram-component-edge"):
                if any(isinstance(getattr(cell, end, None), dict) and
                       getattr(cell, end).get("cell") == key for end in ("source", "target")):
                    remove(other)
        active.remove(key)
        visited.add(key)
        order.append(key)
    for key in ids:
        remove(key)
    receipts = []
    for key in order:
        raw = cells[key].toJSON()
        item = {field: deepcopy(raw[field]) for field in ("id", "canvas", "shape")}
        label = raw.get("attrs", {}).get("label", {}).get("text")
        if label is None:
            label = raw.get("label")
        if label is not None:
            item["label"] = deepcopy(label)
        for field in ("definition", "source", "target"):
            if raw.get(field) is not None:
                item[field] = deepcopy(raw[field])
        receipts.append(item)
    for key in order:
        from .diagram_aux import _DeletedCell
        cells[key] = _DeletedCell()
    return receipts
