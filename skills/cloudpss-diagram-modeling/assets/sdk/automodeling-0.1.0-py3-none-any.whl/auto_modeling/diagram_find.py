"""Search entry points backed by captured-platform implementations.

Replaces earlier speculative projections and depth rules. Supported shapes and
case limits are documented in docs/diagram_batches_implementation.md.
"""
from .diagram_batch import (
    connected_diagram_components,
    find_diagram_components,
    find_diagram_edges,
    find_diagram_nodes,
    get_diagram_nodes,
)

__all__ = ["connected_diagram_components", "find_diagram_components",
           "find_diagram_edges", "find_diagram_nodes", "get_diagram_nodes"]
