"""Explicit SDK identity changes; no MCP contract, fetch, save or run.

Only declared identity references are rewritten. Labels, pin names, arbitrary
strings and expressions are never searched/replaced. Custom job references
outside the supported registry must be handled explicitly by their owner.
"""
from copy import deepcopy

# Official EMTP definition: these choices return cell.id. output_numeric and
# output_curve return VirtualOutput.args.portName and MUST NOT be rewritten.
_JOB_CELL_COLUMNS = {
    'function/CloudPSS/emtps': {'output_channels': ('4', '5'), 'XY_Output_channels': ('2', '3')},
}


def _mapping(mapping):
    if not isinstance(mapping, dict):
        raise TypeError('ID mapping must be an object from existing ID to new ID')
    if any(not isinstance(k, str) or not k or not isinstance(v, str) or not v
           for k, v in mapping.items()):
        raise ValueError('Cell IDs must be nonempty strings')
    if len(set(mapping.values())) != len(mapping):
        raise ValueError('New cell IDs must be unique')
    return dict(mapping)


def remap_job_cell_references(jobs, mapping):
    """Return detached jobs with declared literal cell selector lists remapped.

    Missing IDs are retained (partial maps are allowed). Only the official
    EMTP cell-ID columns are covered. Port-name selectors and unrelated/custom
    job fields remain unchanged. Expressions in declared reference tables or
    columns are refused, rather than rewritten as source text.
    """
    mapping = _mapping(mapping)
    result = deepcopy(jobs)
    if not mapping:
        return result
    for job in result:
        for table, columns in _JOB_CELL_COLUMNS.get(job.get('rid'), {}).items():
            args = job.get('args', {})
            if table not in args:
                continue
            rows = args[table]
            if not isinstance(rows, list):
                raise ValueError(f'Cell selector table {table} must be a literal array')
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError(f'Cell selector table {table} rows must be objects')
                for column in columns:
                    if column not in row:
                        continue
                    values = row[column]
                    if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
                        raise ValueError(f'Cell selector {table}.{column} must be a literal string array')
                    row[column] = [mapping.get(value, value) for value in values]
    return result


def rename_diagram_cell_ids(model, mapping):
    """Rename a subset of SDK cells and their declared references atomically.

    Mapping direction is existing ID -> new ID. Permutations/overlapping names
    are supported, collisions with unmapped cells are rejected. SDK Component
    instances, dictionary order, canvas IDs and unrelated data are retained.
    Cell endpoints (including edge-to-edge taps) and official EMTP cell selector
    lists are updated; coordinate endpoints have no cell identity to update.
    No counter is consumed. New factories already skip occupied IDs.

    Unknown endpoint cells, inconsistent object identities, malformed reference
    fields and nonliteral selector tables fail before any write. Custom context,
    expressions and custom job references are outside this explicit registry.
    """
    mapping = _mapping(mapping)
    cells = model.getAllComponents()
    if set(mapping) - set(cells):
        raise ValueError('ID mapping contains an unknown cell')
    destinations = [mapping.get(key, key) for key in cells]
    if len(set(destinations)) != len(destinations):
        raise ValueError('New cell ID collides with an unmapped cell')
    if not mapping:
        return {}
    objects = list(cells.items())
    if len({id(cell) for _, cell in objects}) != len(objects):
        raise ValueError('Multiple cell keys refer to the same SDK object')
    updates = []
    for key, cell in objects:
        raw = cell.toJSON()
        if raw.get('id') != key:
            raise ValueError('Cell key and object ID differ')
        fields = {'id': mapping.get(key, key)}
        for end in ('source', 'target'):
            terminal = raw.get(end)
            if terminal is None:
                continue
            if not isinstance(terminal, dict):
                raise ValueError('Endpoint must be an object')
            if 'cell' not in terminal:
                continue
            reference = terminal['cell']
            if not isinstance(reference, str) or reference not in cells:
                raise ValueError('Unknown endpoint in SDK cells')
            if reference in mapping:
                fields[end] = {**deepcopy(terminal), 'cell': mapping[reference]}
        updates.append((cell, fields))
    jobs = remap_job_cell_references(model.jobs, mapping)
    # Keep original object dictionaries for rollback on an unexpected SDK
    # setter exception. All nested values are staged before changing anything.
    originals = [(cell, cell.__dict__.copy()) for _, cell in objects]
    original_jobs = model.jobs
    try:
        for cell, fields in updates:
            for field, value in fields.items():
                setattr(cell, field, value)
        cells.clear()
        cells.update((mapping.get(key, key), cell) for key, cell in objects)
        if jobs != original_jobs:
            model.jobs = jobs
    except Exception:
        for cell, attributes in originals:
            cell.__dict__.clear()
            cell.__dict__.update(attributes)
        cells.clear()
        cells.update(objects)
        model.jobs = original_jobs
        raise
    return deepcopy(mapping)
