"""Read-only projections for diagram canvases, variables and auxiliary cells."""
from copy import deepcopy

# Auxiliary-cell entry points are kept here for compatibility with older
# imports; the implementation lives in diagram_aux and uses the real
# element/link shapes confirmed by the public client.
from .diagram_aux import (get_diagram_texts, get_diagram_links,
                          find_diagram_texts, find_diagram_links)


def list_diagram_canvases(model):
    canvases = getattr(model.revision.implements.diagram, "canvas", []) or []
    return [{key: deepcopy(canvas.get(key)) for key in ('key', 'name')} for canvas in canvases]


def list_diagram_variables(model):
    return deepcopy(_variable_items(model))


def _variable_items(model):
    diagram = model.revision.implements.diagram
    variables = getattr(diagram, "variables", None)
    if variables is None:
        return []
    if not isinstance(variables, list) or any(
        not isinstance(item, dict) or not isinstance(item.get("key"), str) or "value" not in item
        for item in variables
    ):
        raise ValueError("Unsupported variables state: expected an ordered key/value list")
    return variables


def get_diagram_variable(model, key):
    if not isinstance(key, str):
        raise TypeError("key must be a string")
    for item in _variable_items(model):
        if item.get("key") == key:
            return deepcopy(item["value"])
    raise ValueError(f"panic: Variable {key} not found")


def update_diagram_variable(model, key, value):
    if not isinstance(key, str):
        raise TypeError("key must be a string")
    variables = _variable_items(model)
    for index, item in enumerate(variables):
        if item.get("key") == key:
            item["value"] = deepcopy(value)
            return index
    variables.append({"key": key, "value": deepcopy(value)})
    model.revision.implements.diagram.variables = variables
    return len(variables) - 1


def delete_diagram_variable(model, key):
    if not isinstance(key, str):
        raise TypeError("key must be a string")
    variables = _variable_items(model)
    for index, item in enumerate(variables):
        if item.get("key") == key:
            variables.pop(index)
            return index
    raise ValueError(f"panic: Variable {key} not found")


def _cells(model, shape):
    cells = model.getAllComponents()
    return [cell for cell in cells.values() if getattr(cell, "shape", None) == shape]


