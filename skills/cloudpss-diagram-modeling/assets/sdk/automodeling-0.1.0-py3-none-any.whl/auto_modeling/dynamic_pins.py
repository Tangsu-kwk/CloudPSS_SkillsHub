"""Check-time pins from SimStudio 5.0.39 module 63690 (no graphic rendering)."""
from copy import deepcopy
import math
from .job_inputs import _js_truth, _expression, _json_numbers
from .parameter_checks import _number, _string

_TYPES={
    'model/CloudPSS/_ChannelMerge':('OutName','OutDimX','OutDimY','In','output','input'),
    'model/CloudPSS/_ChannelDeMerge':('InName','InDimX','InDimY','Out','input','output'),
    'model/CloudPSS/_BusConnector':('InName','InDimX','InDimY','Out','electrical','electrical'),
}


def evaluated_instance_args(document, component, definition):
    """Evaluate instance parameters against an isolated current scheme/variables.

    Accept the flat definition returned by get_component_model. No network,
    model edits, random row identities or fallback on failed expressions.
    """
    from .diagram_connections import _DiagramScope, _args
    from .job_inputs import evaluate_args, _expression
    document = deepcopy(document if isinstance(document, dict) else document.toJSON())
    revision = document['revision']
    configs = document.get('configs', [])
    index = document.get('context', {}).get('currentConfig', 0)
    if type(index) is not int or not 0 <= index < len(configs):
        raise ValueError('No valid current parameter scheme')
    globals_ = evaluate_args(configs[index].get('args', {}), revision.get('parameters', []))
    for variable in revision.get('implements', {}).get('diagram', {}).get('variables', []):
        name = variable.get('key')
        if not isinstance(name, str) or not name.isidentifier() or name in globals_:
            raise ValueError('Invalid or duplicate diagram variable')
        globals_[name] = deepcopy(variable.get('value'))
    pending = set()
    class Scope(_DiagramScope):
        def __getitem__(self, key):
            if key.startswith('$') and key not in ('$', '$$') and key[1:] in globals_:
                name = key[1:]
                value = globals_[name]
                if _expression(value):
                    if name in pending:
                        raise ValueError('Cyclic diagram variable expression')
                    pending.add(name)
                    try:
                        globals_[name] = self.evaluate(value, None)
                    finally:
                        pending.remove(name)
                return deepcopy(globals_[name])
            return super().__getitem__(key)
    scope = Scope({}, None, document, globals_)
    for name in list(globals_):
        scope['$' + name]
    return _args(component.get('args') or {}, definition.get('parameters', []),
                 component, document, globals_)


def pinlike_pins(definition, args):
    """Monitoring terminals created by pinLike parameters with a non-empty label.

    The browser turns a named ``pinLike`` parameter into a real terminal whose
    key is the parameter key; diagram connection grouping already registers them
    from ``args``. Accept either the flat definition or the raw revision form.
    """
    revision = definition.get('revision') if isinstance(definition.get('revision'), dict) else definition
    result = []
    for group in revision.get('parameters') or []:
        if not isinstance(group, dict):
            continue
        for item in group.get('items') or []:
            if not isinstance(item, dict) or item.get('type') != 'pinLike' or not item.get('key'):
                continue
            value = args.get(item['key'])
            if _expression(value) or not _js_truth(value):
                continue
            result.append({'key': item['key'], 'name': _string(value),
                           'description': item.get('description') or '',
                           'dim': deepcopy(item.get('dim')),
                           'visible': True, 'data': item.get('data') or 'real',
                           'connection': item.get('connection') or 'output'})
    return result


def instance_pin_definitions(model, component, definition):
    """Pure effective terminals for a flat definition and an actual SDK instance."""
    rid = component.get('definition')
    args = (evaluated_instance_args(model, component, definition)
            if rid in _TYPES else dict(component.get('args') or {}))
    base = (check_pin_definitions({'rid': rid, 'revision': {'pins': definition.get('pins', [])}}, args)
            if rid in _TYPES else deepcopy(definition.get('pins', [])))
    known = {pin.get('key') for pin in base}
    return base + [pin for pin in pinlike_pins(definition, args) if pin['key'] not in known]


def check_pin_definitions(definition, args):
    """Return original pins or derived pins from already evaluated arguments.

    Missing row identities require the browser's random-ID normalization. They
    are refused here rather than inventing terminal names or mutating inputs.
    This helper supplies check-time pins only, not dynamic display graphics.
    """
    config=_TYPES.get(definition.get('rid'))
    if config is None:return deepcopy(definition['revision'].get('pins',[]))
    primary,x,y,table,primary_connection,secondary_connection=config
    raw=[args.get(primary),args.get(x),args.get(y),args.get(table)]
    if any(_expression(value) for value in raw):
        raise NotImplementedError('Dynamic pins require evaluated arguments')
    def dimension(value):
        result=_number(value)
        return 1 if result==0 or math.isnan(result) else result
    pins=[{'key':primary,'name':_string(raw[0]) if _js_truth(raw[0]) else primary,
           'description':'','dim':[dimension(raw[1]),dimension(raw[2])],
           'visible':True,'data':'real','connection':primary_connection}]
    rows=raw[3] if isinstance(raw[3],list) else []
    for index,row in enumerate(rows):
        if not isinstance(row,dict) or row.get('ɵid') is None:
            raise NotImplementedError('Dynamic pin table rows require stable ɵid values')
        if '3' not in row or '4' not in row:
            raise NotImplementedError('Dynamic pin rows require explicit X and Y dimensions')
        name=row.get('0')
        pins.append({'key':'ɵid-'+_string(row['ɵid']),
                     'name':deepcopy(name) if _js_truth(name) else str(index+1),
                     'description':'','dim':[deepcopy(row.get('3')),deepcopy(row.get('4'))],
                     'visible':True,'data':'real','connection':secondary_connection})
    return _json_numbers(pins)
