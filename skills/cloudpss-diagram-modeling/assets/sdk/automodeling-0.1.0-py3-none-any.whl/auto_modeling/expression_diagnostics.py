"""Browser diagnostic forms verified against live MiraScript checks."""
import re
from .job_inputs import JobInputError


def expression_error(exc):
    if isinstance(exc,JobInputError) and str(exc)=='Calculation expression could not be compiled':
        return 'Failed to compile:'
    cause=exc.__cause__
    if cause is not None and re.fullmatch(r"Global variable '[^'\r\n]+' is not defined\.",str(cause)):
        return str(cause)
    raise exc
