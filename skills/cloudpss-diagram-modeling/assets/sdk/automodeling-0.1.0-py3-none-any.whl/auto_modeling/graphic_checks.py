"""Validate the revision graphic metadata used by the official checker.

This is the in-memory equivalent of SimStudio worker 54141.  It deliberately
does not render a browser graph: the official stage only inspects graphic
nodes, port labels, conditions, and SVG path syntax/bounds.
"""
from copy import deepcopy
from .diagram_connections import _DiagramScope, _evaluate, _js_entries
from .job_inputs import _js_truth


_COMMANDS = {
    "M": 2, "L": 2, "H": 1, "V": 1, "C": 6, "S": 4,
    "Q": 4, "T": 2, "A": 7, "Z": 0,
}


def _problem(message, path, level, **data):
    return {"message": message, "data": {"path": path, **data}, "level": level}


def _global_values(document):
    values = {}
    for group in document.get("revision", {}).get("parameters", []) or []:
        for field in group.get("items", []) or []:
            key = field.get("key")
            if isinstance(key, str) and key.strip() and key.strip() not in values:
                values[key.strip()] = deepcopy(field.get("value"))
    return values


def _condition_result(scope, expression):
    """Return (valid, value), matching evaluateCondition's boolean contract."""
    if expression is None or expression == "":
        return True, True
    if isinstance(expression, bool):
        return True, expression
    if isinstance(expression, str) and expression in ("true", "false"):
        return True, expression == "true"
    try:
        if callable(expression):
            raise NotImplementedError("Callback graphic conditions are unsupported")
        value = _evaluate(scope, {"source": expression, "ɵexp": ""}) if isinstance(expression, str) else expression
        if value is None:
            value = True
        if type(value) is bool:
            return True, value
        from mirascript import to_string
        display = "[object Object]" if isinstance(value, dict) else to_string(value)
        raise TypeError(f"Condition evaluates to `{display}`")
    except NotImplementedError:
        raise
    except Exception as exc:
        return False, str(exc)


def _check_path(path):
    """Port official 5796 streaming syntax parser; only bounds emptiness needed.

    The checker never exposes bounds numbers. Each drawing command contributes
    an endpoint to bounds; a move or close command alone does not.
    """
    import math
    number = ""
    command = None
    args = []
    can_command = True
    has_exp = exp_digits = has_decimal = False
    draws = False
    has_move = False
    # The official finish() flushes a final number with a separate parse(' ').
    for chunk in (path, " "):
        for index, char in enumerate(chunk):
            digit = char in "0123456789"
            arc_flag = command == "A" and len(args) in (3, 4) and number in ("0", "1")
            split_digit = digit and ((number == "0" and char == "0") or arc_flag)
            if digit and not split_digit:
                number += char
                exp_digits = has_exp
                continue
            if char in "eE":
                number += char
                has_exp = True
                continue
            if char in "+-" and has_exp and not exp_digits:
                number += char
                continue
            if char == "." and not has_exp and not has_decimal and not arc_flag:
                number += char
                has_decimal = True
                continue
            if number and command is not None:
                try:
                    value = float(number)
                    if math.isnan(value):
                        raise ValueError()
                except ValueError:
                    raise ValueError(f"Invalid number ending at {index}") from None
                if command == "A":
                    if len(args) in (0, 1) and value < 0:
                        from mirascript import to_string
                        raise ValueError(f'Expected positive number, got "{to_string(value)}" at index "{index}"')
                    if len(args) in (3, 4) and number not in ("0", "1"):
                        raise ValueError(f'Expected a flag, got "{number}" at index "{index}"')
                args.append(value)
                if len(args) == _COMMANDS[command]:
                    if not has_move:
                        raise ValueError("path must start with moveto")
                    if not all(math.isfinite(v) for v in args):
                        raise NotImplementedError("Non-finite SVG path bounds are unsupported")
                    draws |= command != "M"
                    args = []
                    if command == "M":
                        command = "L"
                    can_command = True
                number = ""
                exp_digits = has_exp = has_decimal = False
                can_command = True
            if char in " \t\r\n":
                continue
            if char == "," and can_command:
                can_command = False
                continue
            if char in "+-.":
                number = char
                has_decimal = char == "."
                continue
            if split_digit:
                number = char
                has_decimal = False
                continue
            if args:
                raise ValueError(f"Unterminated command at index {index}.")
            if not can_command:
                raise ValueError(f'Unexpected character "{char}" at index {index}. Command cannot follow comma')
            can_command = False
            if char in "zZ":
                if not has_move:
                    raise ValueError("path must start with moveto")
                can_command, command = True, None
            elif char.upper() in _COMMANDS:
                command = char.upper()
                has_move |= command == "M"
            else:
                raise ValueError(f'Unexpected character "{char}" at index {index}.')
    if args or not can_command:
        raise ValueError("Unterminated command at the path end.")
    return draws


def check_graphic(document):
    """Return official-style ``graphic`` problem records."""
    graphic = document.get("context", {}).get("graphic")
    if not graphic:
        return []
    nodes = graphic.get("nodes")
    if not isinstance(nodes, dict):
        return []
    values = _global_values(document)
    scope = _DiagramScope(dict(values), {"definition": document.get("rid"), "args": values}, document, values)
    pin_keys = {}
    revision_pins = document.get("revision", {}).get("pins")
    if not isinstance(revision_pins, list):
        return []
    for pin in revision_pins:
        if isinstance(pin, dict) and pin.get("key") and _js_truth(pin.get("visible")):
            pin_keys[pin["key"]] = ""
    problems = []
    any_node = False
    for node_id, node in _js_entries(nodes):
        if not isinstance(node, dict):
            continue
        any_node = True
        data = {"path": f"context.graphic.nodes.{node_id}", "node": node_id}
        if node.get("shape") == "port":
            label = ((node.get("attrs") or {}).get("label") or {}).get("textContent")
            if not isinstance(label, str) or not label or label not in pin_keys:
                extra = {"pin": label} if "textContent" in (((node.get("attrs") or {}).get("label")) or {}) else {}
                problems.append(_problem("port:invalid binding", data["path"], "error", node=node_id, **extra))
            elif pin_keys[label]:
                problems.append(_problem("port:duplicate binding", data["path"], "error",
                                         node=node_id, pin=label, otherNode=pin_keys[label]))
            else:
                pin_keys[label] = node_id
        else:
            valid, error = _condition_result(scope, node.get("condition"))
            if not valid:
                problems.append(_problem("shape condition:invalid", data["path"] + ".condition", "warning",
                                         node=node_id, error=error))
            if node.get("shape") == "path":
                path = (((node.get("attrs") or {}).get("body") or {}).get("d"))
                try:
                    from mirascript import to_string
                    if not _check_path(to_string(path, "")):
                        problems.append(_problem("path:empty", data["path"], "warning", node=node_id))
                except NotImplementedError:
                    raise
                except Exception as exc:
                    problems.append(_problem("path:invalid", data["path"], "error", node=node_id, error=str(exc)))
    for pin, node in pin_keys.items():
        if any_node and not node:
            problems.append({"message": "port:missing", "data": {"pin": pin}, "level": "error"})
    return problems
