"""GraphQL read queries and MCP-shaped response projections.

Queries are intentionally injectable so tests never need network access.
Field selection is explicit; unknown GraphQL fields are not invented.
"""
from copy import deepcopy
from .job_functions import JOB_FUNCTION_QUERY, get_graphql_job_function as _get_job_function

METADATA_QUERY="""query ProjectMetadata($rid: ResourceId!) { model(input: {rid: $rid}) { rid name description documentation } }"""

class GraphQLReadError(RuntimeError): pass

def _request(query, variables, requester=None):
    if requester is None:
        from cloudpss.utils import graphql_request
        requester=graphql_request
    response=requester(query, variables, timeout=30)
    if not isinstance(response,dict): raise GraphQLReadError("Invalid GraphQL response")
    if response.get("errors"): raise GraphQLReadError("GraphQL returned errors")
    return response.get("data")

def get_metadata(rid, requester=None):
    data=_request(METADATA_QUERY,{"rid":rid},requester)
    item=data.get("model") if isinstance(data,dict) else None
    return deepcopy(item) if isinstance(item,dict) else None

def get_job_function(rid, requester=None):
    """Use the real GraphQL adapter; runtime MCP enrichment remains unverified."""
    return _get_job_function(rid, requester)
