"""Check selected queue health from explicit policy data; worker 16451."""
from copy import deepcopy
from .parameter_checks import _strict_equal, _number


def check_job_system(model, *, policies):
    """policies is an explicit snapshot; [] means a known empty policy cache.

    Omitted/unknown data must not be disguised as an empty cache. This helper
    performs no network request and never creates or submits a task.
    """
    if not isinstance(policies, list):
        raise TypeError('policies must be an explicit list')
    document = model if isinstance(model, dict) else model.toJSON()
    index = document.get('context', {}).get('currentJob')
    jobs = document.get('jobs') or []
    if type(index) is not int or not 0 <= index < len(jobs):
        return []
    args = jobs[index].get('args') or {}
    if '@queue' not in args:
        return []
    for policy in policies:
        queue = policy.get('queue')
        if not isinstance(queue, dict) or not _strict_equal(queue.get('id'), args['@queue']):
            continue
        load = _number(queue.get('load', float('nan')))
        if load < 0:
            return [{'message': 'job system:no valid machine', 'data': {'queue': deepcopy(queue)}, 'level': 'warning'}]
        if load > 2:
            return [{'message': 'job system:overload', 'data': {'queue': deepcopy(queue)}, 'level': 'info'}]
        return []
    return []
