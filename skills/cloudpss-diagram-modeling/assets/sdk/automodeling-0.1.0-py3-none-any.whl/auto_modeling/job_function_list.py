"""Available SimStudio calculation functions from official GraphQL."""
from copy import deepcopy

from .job_functions import JobFunctionError
from .component_model import _error_diagnostics

FUNCTIONS_QUERY = """
query AvailableJobFunctions($input: FunctionsInput!) {
  functions(input: $input) {
    items { rid name description }
    cursor count total
  }
}
"""


def list_job_functions(*, requester=None, page_size=100):
    """Return MCP's three-field list, retaining server order across pages.

    Query filters were compared with the real MCP list. page_size/requester are
    Python transport controls, not public MCP arguments. Errors never become [].
    """
    if type(page_size) is not int or page_size < 1:
        raise ValueError("page_size must be a positive integer")
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    base = {"orderBy": ["updatedAt<"], "limit": page_size,
            "tags": "support:model", "access": {"permission": 65536}}
    result, seen_rids, seen_cursors, cursor = [], set(), set(), None
    for _ in range(1000):
        request_input = deepcopy(base)
        if cursor is not None:
            request_input["cursor"] = deepcopy(cursor)
        try:
            response = requester(FUNCTIONS_QUERY, {"input": request_input}, timeout=30)
        except Exception:
            raise JobFunctionError("Function list request failed; check SDK configuration and connectivity") from None
        if not isinstance(response, dict):
            raise JobFunctionError("Invalid function list response")
        if response.get("errors"):
            raise JobFunctionError("GraphQL returned errors", _error_diagnostics(response["errors"]))
        data = response.get("data")
        page = data.get("functions") if isinstance(data, dict) else None
        if not isinstance(page, dict) or not isinstance(page.get("items"), list):
            raise JobFunctionError("Missing function list page")
        total, count = page.get("total"), page.get("count")
        if type(total) is not int or total < 0 or type(count) is not int or count != len(page["items"]):
            raise JobFunctionError("Invalid function page counts")
        # Actual endpoint: total changes with cursor; page size may exceed the
        # requested limit and the last boundary item can repeat. Exhaust until
        # an empty page, preserving order and rejecting inconsistent duplicates.
        if not count:
            return result
        added = 0
        for position, item in enumerate(page["items"]):
            if not isinstance(item, dict) or any(type(item.get(k)) is not str for k in ("rid", "name", "description")):
                raise JobFunctionError("Invalid function list item")
            if item["rid"] in seen_rids:
                projected = {key: item[key] for key in ("rid", "name", "description")}
                if position == 0 and result and projected == result[-1]:
                    continue
                raise JobFunctionError("Duplicate function across pages")
            seen_rids.add(item["rid"])
            result.append({key: deepcopy(item[key]) for key in ("rid", "name", "description")})
            added += 1
        cursor = page.get("cursor")
        if not added or not isinstance(cursor, list) or not cursor or any(type(v) is not str for v in cursor):
            raise JobFunctionError("Incomplete function list without a usable cursor")
        marker = tuple(cursor)
        if marker in seen_cursors:
            raise JobFunctionError("Repeated function list cursor")
        seen_cursors.add(marker)
    raise JobFunctionError("Function list page limit exceeded")
