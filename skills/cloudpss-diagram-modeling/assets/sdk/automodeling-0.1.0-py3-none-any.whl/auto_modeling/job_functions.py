"""Read calculation function definitions via the SDK's official GraphQL route."""
from copy import deepcopy

from .component_model import _error_diagnostics

# Current GraphQL validates input and revision.parameters; the installed SDK's
# legacy function.fetch query is incompatible with the current endpoint.
JOB_FUNCTION_QUERY = """
query JobFunction($rid: ResourceId!) {
  function(input: {rid: $rid}) {
    rid name description tags keywords
    revision { parameters }
  }
}
"""


class JobFunctionError(RuntimeError):
    def __init__(self, message, graphql_errors=None):
        super().__init__(message)
        self.graphql_errors = graphql_errors


def get_graphql_job_function(rid, requester=None, *, runtime_definitions=None):
    """Project six definition fields; not the full frontend runtime definition.

    Real comparison found an extra scheduling group and runtime-only metadata
    in MCP, plus tag-order differences. Do not inject or normalize those here.
    """
    if not isinstance(rid, str) or not rid.strip():
        raise ValueError("rid must be a non-empty string")
    # Explicit official runtime snapshots can supply fields not exposed by the
    # GraphQL projection. No synthetic scheduling groups or metadata are added.
    if runtime_definitions is not None:
        if not rid.startswith("function/") or len(rid.split("/")) != 3 or any(not p for p in rid.split("/")):
            raise TypeError("rid must be a function resource ID")
        if not isinstance(runtime_definitions, dict):
            raise TypeError("runtime_definitions must be a RID-keyed mapping")
        item = runtime_definitions.get(rid)
        if item is None:
            return None
        if not isinstance(item, dict) or item.get("rid") != rid or not isinstance(item.get("parameters"), list):
            raise JobFunctionError("Invalid runtime function definition or identity")
        return deepcopy(item)
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    try:
        response = requester(JOB_FUNCTION_QUERY, {"rid": rid}, timeout=30)
    except Exception:
        raise JobFunctionError("GraphQL request failed; check connectivity and SDK configuration") from None
    if not isinstance(response, dict):
        raise JobFunctionError("Invalid GraphQL response")
    if response.get("errors"):
        raise JobFunctionError("GraphQL returned errors", _error_diagnostics(response["errors"]))
    data = response.get("data")
    item = data.get("function") if isinstance(data, dict) else None
    # Absence/permission failures have not been compared with MCP; don't invent
    # a compatibility mapping to None.
    expected = {"rid": str, "name": str, "description": str,
                "tags": list, "keywords": list, "parameters": list}
    if not isinstance(item, dict) or not isinstance(item.get("revision"), dict):
        raise JobFunctionError("Invalid or missing function revision")
    projected = {**item, "parameters": item["revision"].get("parameters")}
    if any(type(projected.get(k)) is not t for k, t in expected.items()):
        raise JobFunctionError("Invalid or missing function fields")
    if item["rid"] != rid:
        raise JobFunctionError("Returned function identity differs from requested RID")
    return {key: deepcopy(projected[key]) for key in expected}


FUNCTION_LOADING_QUERY = """
query RuntimeJobFunctions($input: FunctionsInput!) {
  functions(input: $input) {
    count total cursor
    items { rid name description tags keywords
      revision { version documentation parameters implementType }
    }
  }
}
"""


def _runtime_parameters(parameters):
    """JSON-visible part of official 5.0.39 modules 65628/73251/updateEnv.

    Function-valued choices, conditions, icons and callbacks are absent from
    MCP JSON serialization. These are metadata, not executable validators.
    """
    result = deepcopy(parameters)
    fields = [field for group in result for field in group.get("items", [])]
    cpu = next((f for f in fields if f.get("key") == "n_cpu"), None)
    if cpu and cpu.get("type") == "integer" and not cpu.get("constraints"):
        cpu["constraints"] = [{"message": "核心数应小于等于计算资源中配置的值"}]
    for key in ("load_snapshot_name", "load_compile_file"):
        field = next((f for f in fields if f.get("key") == key), None)
        if field and field.get("type") == "choice":
            field["itemActions"] = [{"name": "删除"}]
    result.append({"name": "运行设置", "description": "任务运行时的调度设置", "items": [
        {"key": "@queue", "name": "任务队列", "value": 1, "type": "choice",
         "description": "任务运行使用的队列", "constraints": [
             {"order": "pre", "message": "没有可用于此函数的队列，请联系管理员"}]},
        {"key": "@tres", "name": "计算资源", "value": "cpu=1", "type": "choice",
         "description": "任务运行使用的计算资源", "constraints": [
             {"order": "pre", "message": "没有可用于此函数的计算资源组合，请联系管理员"}]},
        {"key": "@priority", "name": "优先级", "value": 0, "type": "real",
         "description": "任务运行的优先级", "constraints": [{"message": "value not in range"}]},
        {"key": "@debug", "name": "调试参数", "value": "", "type": "text",
         "description": "任务运行使用的调试参数", "expandable": True}]})
    return result


def get_job_function(rid, requester=None):
    """Reproduce the browser's available-function registry JSON without MCP.

    Uses the official loadModelFunctions list route (single-resource tags can
    differ in order), then the public runtime metadata transforms. A valid RID
    absent from the executable support:model registry returns None as MCP does.
    Session-specific extra loaded functions and legacy revisions remain outside
    the verified scope. No supplied MCP snapshots are used as runtime answers.
    """
    import re
    if not isinstance(rid, str) or not re.fullmatch(r"function/[^/\s]+/[^/\s]+", rid):
        raise TypeError("参数 rid 必须是函数的资源 ID")
    return load_job_functions(requester=requester).get(rid)


def load_job_functions(*, requester=None):
    """Load the full runtime JSON registry once for independent checks/runs.

    Uses the same public query and transforms as get_job_function. Page totals
    are cursor-relative; compare each page with its own total. Contradictory
    duplicate identities and incomplete pages fail closed.
    """
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    inputs = {"orderBy": [], "limit": 1000000, "tags": "support:model", "access": {"permission": 65536}}
    seen_cursors, found, previous_last = set(), {}, None
    for _ in range(100):
        try:
            response = requester(FUNCTION_LOADING_QUERY, {"input": deepcopy(inputs)}, timeout=30)
        except Exception:
            raise JobFunctionError("Function registry request failed; check connectivity and SDK configuration") from None
        if not isinstance(response, dict):
            raise JobFunctionError("Invalid function registry response")
        if response.get("errors"):
            raise JobFunctionError("GraphQL returned errors", _error_diagnostics(response["errors"]))
        data = response.get("data")
        page = data.get("functions") if isinstance(data, dict) else None
        if (not isinstance(page, dict) or not isinstance(page.get("items"), list)
                or type(page.get("count")) is not int or type(page.get("total")) is not int
                or page["count"] != len(page["items"]) or page['count'] < 0
                or page['total'] < page['count']):
            raise JobFunctionError("Invalid function registry page")
        added = 0
        for position, item in enumerate(page["items"]):
            if not isinstance(item, dict) or not isinstance(item.get("rid"), str):
                raise JobFunctionError("Invalid function registry item")
            rid = item['rid']
            revision = item.get("revision")
            if (not isinstance(revision, dict) or not isinstance(revision.get("parameters"), list)
                    or any(type(item.get(k)) is not t for k, t in
                           {"name": str, "description": str, "tags": list, "keywords": list}.items())):
                raise JobFunctionError("Invalid function definition")
            if revision.get("version") != 5:
                raise NotImplementedError("Function revision migration is only supported for version 5")
            definition = {k: deepcopy(item[k]) for k in ("name", "description", "tags", "keywords", "rid")}
            definition["parameters"] = _runtime_parameters(revision["parameters"])
            if rid in found:
                if position == 0 and rid == previous_last and found[rid] == definition:
                    continue
                raise JobFunctionError('Duplicate function across registry pages')
            found[rid] = definition
            added += 1
        if page["count"] == 0:
            if page['total'] != 0:
                raise JobFunctionError('Empty function page with remaining records')
            return found
        cursor = page.get("cursor")
        if page['count'] == page['total']:
            return found
        if not isinstance(cursor, list) or not cursor:
            raise JobFunctionError("Incomplete function registry page")
        if not added:
            raise JobFunctionError('Function registry made no progress')
        marker = repr(cursor)
        if marker in seen_cursors:
            raise JobFunctionError("Repeated function registry cursor")
        seen_cursors.add(marker)
        previous_last = next(reversed(found))
        inputs["cursor"] = deepcopy(cursor)
    raise JobFunctionError("Function registry page limit exceeded")
