"""Prepare task arguments in memory; never check, save, submit or run a model.

Source: SimStudio 5.0.39 modules 52928/5341/14366/73251/2928/3325.
Definitions are explicit inputs so this layer performs no hidden network reads.
Python MiraScript handles expressions; unsupported browser callbacks/VM extensions
raise rather than silently producing an approximate submission.
"""
from collections.abc import Mapping
from copy import deepcopy
import math
import re

_FAIL = object()
_KINDS = {"real", "integer", "text", "code", "file", "pinLike", "cssColor",
          "cssBackground", "resourceId", "choice", "logical", "multiSelect",
          "table", "grouped", "record"}


class JobInputError(ValueError):
    """Argument preparation failed; no caller-owned model has been modified."""


def _expression(value):
    return isinstance(value, dict) and isinstance(value.get("ɵexp"), str)


def _number(value):
    # Use the official MiraScript conversion, not Python float(string), whose
    # accepted grammar differs (e.g. empty string, binary/octal, inf/nan).
    from mirascript import to_number
    return to_number(value, _FAIL)


def _js_truth(value):
    return value is not None and value is not False and value != "" and not (
        type(value) in (int, float) and (value == 0 or (type(value) is float and math.isnan(value))))


def _choice_type(field):
    kind = field.get("type")
    value, choices = field.get("value"), field.get("choices")
    selected, has_value = "", False
    primitive = lambda v: type(v) in (str, bool, int, float)
    typename = lambda v: "boolean" if type(v) is bool else "string" if isinstance(v, str) else "number"
    if kind == "multiSelect" and isinstance(value, list):
        if value and primitive(value[0]):
            selected, has_value = typename(value[0]), True
    elif primitive(value):
        selected, has_value = typename(value), _js_truth(value)
    if _expression(choices):
        return selected if has_value else ""
    if not choices:
        return selected or ("boolean" if kind == "logical" else "number")
    if not isinstance(choices, list):
        raise NotImplementedError("Callable or malformed choice definitions are unsupported")
    for item in choices:
        if item is None:
            continue
        key = item.get("key") if isinstance(item, dict) else item
        if primitive(key):
            return typename(key)
    return selected or ("boolean" if kind == "logical" else "number")


def _primitive(value, kind, fallback):
    from mirascript import to_string, to_boolean
    if kind in ("number", "f"):
        result = _number(value)
        return fallback if result is _FAIL else result
    if kind in ("string", "s"):
        return to_string(value, fallback)
    if kind in ("boolean", "b"):
        return to_boolean(value, fallback)
    return fallback if value is None else value


def _convert(value, field, fallback):
    kind = field.get("type")
    if kind is None:
        return fallback if value is None else deepcopy(value)
    if kind not in _KINDS:
        raise NotImplementedError(f"Unsupported calculation parameter type: {kind}")
    if kind in ("real", "integer"):
        return _primitive(value, "number", fallback)
    if kind in ("text", "code", "file", "pinLike", "cssColor", "cssBackground", "resourceId"):
        return _primitive(value, "string", fallback)
    if kind in ("choice", "logical"):
        return _primitive(value, _choice_type(field), fallback)
    if kind in ("record", "grouped"):
        if isinstance(value, dict):
            return deepcopy(value)
        if isinstance(value, list):
            return {str(i): deepcopy(v) for i, v in enumerate(value)}
        return fallback
    # Official array converter wraps any valid scalar/record in a singleton.
    values = [] if value is None else value if isinstance(value, list) else [value]
    result = []
    for item in values:
        if kind == "multiSelect":
            converted = _primitive(item, _choice_type(field), _FAIL)
        else:
            columns = field.get("columns")
            if not columns:
                converted = deepcopy(item)
            elif len(columns) == 1:
                converted = _convert(item, columns[0], _FAIL)
            elif isinstance(item, (dict, list)):
                converted = deepcopy(item) if isinstance(item, dict) else {str(i): deepcopy(v) for i, v in enumerate(item)}
                for i, column in enumerate(columns):
                    key = column.get("key") or str(i)
                    cell = _convert(converted.get(key), column, _FAIL)
                    if cell is _FAIL:
                        converted = _FAIL
                        break
                    converted[key] = cell
            else:
                converted = _FAIL
        if converted is _FAIL:
            return fallback
        result.append(converted)
    return result


def _fields(parameters):
    if not isinstance(parameters, list):
        raise TypeError("parameters must be a list of groups")
    fields = []
    for group in parameters:
        if not isinstance(group, dict) or not isinstance(group.get("items"), list):
            raise TypeError("Invalid parameter group")
        for field in group["items"]:
            if not isinstance(field, dict):
                raise TypeError("Invalid parameter definition")
            if field.get("key"):
                if not isinstance(field["key"], str):
                    raise TypeError("Parameter key must be a string")
                fields.append(field)
    return fields


class _Scope(Mapping):
    def __init__(self, local, owner, document):
        self.local, self.owner, self.document = local, owner, document
        self.active = set()

    def __iter__(self):
        return iter([*self.local, "$", "$$"])

    def __len__(self):
        return len(self.local) + 2

    def __getitem__(self, key):
        if key == "$":
            # Nested expression proxies are browser-specific; refuse rather
            # than hand unresolved expression records to the Python VM.
            if _contains_expression(self.owner):
                raise NotImplementedError("Nested $/$$ expression references are not yet supported")
            return self.owner
        if key == "$$":
            if _contains_expression(self.document):
                raise NotImplementedError("Nested $/$$ expression references are not yet supported")
            return self.document
        if key not in self.local or key.startswith("$"):
            raise KeyError(key)
        if key in self.active:
            raise JobInputError(f"Cyclic argument expression: {key}")
        self.active.add(key)
        try:
            value = self.local[key]
            if not _expression(value) and _contains_expression(value):
                raise NotImplementedError("Nested local expression proxies are not yet supported")
            return self.evaluate(value, None) if _expression(value) else deepcopy(value)
        finally:
            self.active.remove(key)

    def evaluate(self, value, fallback):
        if value is None:
            return fallback
        if not _expression(value):
            return deepcopy(value)
        source = value.get("source")
        if not isinstance(source, str):
            raise JobInputError("Expression source must be a string")
        from mirascript import compile, VmContext
        script, diagnostics = compile(source)
        if script is None:
            raise JobInputError("Calculation expression could not be compiled")
        try:
            result = script(VmContext(self))
        except (JobInputError, NotImplementedError):
            raise
        except Exception as exc:
            raise JobInputError("Calculation expression evaluation failed") from exc
        annotation = value["ɵexp"]
        if annotation:
            if annotation not in ("s", "string", "f", "number", "b", "boolean"):
                raise NotImplementedError("Unsupported expression conversion annotation")
            result = _primitive(result, annotation, _FAIL)
            if result is _FAIL:
                raise JobInputError("Expression annotation conversion failed")
        return fallback if result is None else result


def _contains_expression(value):
    if _expression(value):
        return True
    if isinstance(value, dict):
        return any(_contains_expression(v) for v in value.values())
    if isinstance(value, list):
        return any(_contains_expression(v) for v in value)
    return False


def _json_numbers(value):
    # MCP JSON has one number type: JS integral numbers serialize as integers;
    # non-finite numbers serialize as null. No strings or missing keys changed.
    if type(value) is float:
        return None if not math.isfinite(value) else int(value) if value.is_integer() else value
    if isinstance(value, dict):
        return {k: _json_numbers(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_numbers(v) for v in value]
    return value


def evaluate_args(args, parameters, *, owner=None, document=None):
    """Return defined evaluated fields, preserving caller inputs.

    Supports literal conversions and local MiraScript expressions. Browser-only
    imports, expression proxies through $/$$ and callbacks remain unsupported.
    No validation constraints are run: MCP's checker is a separate operation.
    """
    if not isinstance(args, dict):
        raise TypeError("args must be an object")
    local = deepcopy(args)
    if any(not isinstance(key, str) for key in local):
        raise TypeError("Argument keys must be strings")
    fields = _fields(parameters)
    for field in fields:
        key = field["key"]
        value = local.get(key)
        if value is None:
            value = deepcopy(field.get("value"))
            if _expression(value):
                value = {"source": value.get("source"), "ɵexp": ""}
            else:
                converted = _convert(value, field, None)
                if converted is not None:
                    value = converted
        elif not _expression(value):
            converted = _convert(value, field, None)
            if converted is not None:
                value = converted
        local[key] = value
    defined = {f["key"] for f in fields}
    for key in list(local):
        if key not in defined and not key.startswith(("_", "$", "@", "ɵ")):
            del local[key]
    owned = deepcopy(owner) if owner is not None else {"args": local}
    if isinstance(owned, dict):
        owned["args"] = local
    scope = _Scope(local, owned, deepcopy(document))
    output = {}
    for field in fields:
        value = scope.evaluate(local[field["key"]], field.get("value"))
        output[field["key"]] = _convert(value, field, value)
    return _json_numbers(output)


def _resource_policy(text):
    if not isinstance(text, str) or not text:
        raise JobInputError("Invalid calculation resource specification")
    result, found = {"cpu": 0, "ecpu": 0, "mem": 0}, False
    for part in text.split():
        key, _, value = part.partition("=")
        if key not in result:
            continue
        match = re.match(r"^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?", value)
        number = float(match[0]) if match else -1
        if math.isfinite(number) and number >= 0:
            result[key], found = number, True
    if not found or not float(result["cpu"]).is_integer():
        raise JobInputError("Invalid calculation resource specification")
    return _json_numbers(result)


def _debug_args(text):
    if not text:
        return None
    tokens, token, escaped = [], "", False
    for char in text:
        if escaped:
            token += "\\" + char
            escaped = False
        elif char == "\\":
            escaped = True
        elif char.isspace():
            if token:
                tokens.append(token)
                token = ""
        else:
            token += char
    if token:
        tokens.append(token)
    if not tokens:
        return None
    output = {}
    for token in tokens:
        key, value, split, escaped = "", "", False, False
        for char in token:
            if escaped:
                char = {"b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t", "v": "\v"}.get(char, char)
                if split:
                    value += "\\" + char if char in ("\\", "$") else char
                else:
                    key += char
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == "=" and not split:
                split = True
            elif split:
                value += char
            else:
                key += char
        output[key] = value
    return output


def prepare_job_inputs(model, configIndex, jobIndex, *, definition):
    """Prepare arguments/policy/debug for one model job; does not submit.

    This is a helper, not an implemented run_job MCP tool. Caller supplies the
    matching official get_job_function definition explicitly.
    """
    document = deepcopy(model.toJSON())
    def scheme(items, index):
        if type(index) not in (int, float) or not math.isfinite(index) or index < 0 or int(index) != index or index >= len(items):
            raise JobInputError("not selected config")
        return deepcopy(items[int(index)])
    job = scheme(document["jobs"], jobIndex)
    config = scheme(document["configs"], configIndex)
    if not isinstance(definition, dict) or definition.get("rid") != job.get("rid"):
        raise JobInputError("Calculation function identity mismatch")
    job_args = evaluate_args(job.get("args", {}), definition["parameters"], owner=job, document=document)
    config_args = evaluate_args(config.get("args", {}), document["revision"].get("parameters", []), owner=config, document=document)
    queue, priority = job_args.get("@queue"), job_args.get("@priority")
    if type(queue) not in (int, float) or queue < 0 or int(queue) != queue:
        raise JobInputError("Invalid task queue")
    if type(priority) not in (int, float) or not math.isfinite(priority):
        raise JobInputError("Invalid task priority")
    resources = _resource_policy(job_args.get("@tres"))
    debug = _debug_args(job_args.get("@debug"))
    return {"function": job["rid"],
            "args": {k: v for k, v in job_args.items() if k not in ("@queue", "@priority", "@tres", "@debug")},
            "config_args": config_args, "policy": {"queue": queue, "priority": priority, "tres": resources},
            "debug": debug, "job_name": job.get("name"), "config_name": config.get("name")}
