"""One SDK-owned background connection per task; no browser or task mutations."""
from copy import deepcopy
from datetime import datetime, timezone
import threading
import time

from .result_stream import read_stream, remaining, ResultStreamStopped
from .result_records import receiver_records


class JobReceiverError(RuntimeError):
    """Reception failed; the known task can be reattached, never resubmitted."""
    def __init__(self, job_id, reason):
        super().__init__(f'Task {job_id}: {reason}; reattach this task, do not resubmit')
        self.job_id = job_id


class JobReceiver:
    def __init__(self, session, job_id, *, timeout, startup_timeout, requester):
        self.session, self.job_id = session, job_id
        self.deadline = time.monotonic() + timeout
        self.requester = requester
        self.startup_timeout = startup_timeout
        self.stop_event = threading.Event()
        self.ready = threading.Event()
        self.done = threading.Event()
        self.socket = None
        self.error = None
        self.state = 'connecting'
        self.changed = {}
        self.initial = deepcopy(session.records[job_id])
        self.raw, self.stamps, self.records = [], [], []
        self.previous = iter(self.initial.get('receiver_messages', []))
        self.prefix = True
        self.thread = threading.Thread(target=self._run, name='CloudPSS-result-' + job_id, daemon=True)

    def _opened(self, socket):
        self.socket = socket
        if self.stop_event.is_set():
            raise ResultStreamStopped('SDK result receiver stopped')
        with self.session._condition:
            self.state = 'receiving'
            self.session._condition.notify_all()
        self.ready.set()

    def _message(self, message, stamp):
        with self.session._condition:
            if self.stop_event.is_set():
                raise ResultStreamStopped('SDK result receiver stopped')
            index = len(self.raw)
            old_raw = self.initial.get('messages', [])
            self.prefix = self.prefix and index < len(old_raw) and message == old_raw[index]
            self.raw.append(message)
            self.stamps.append(stamp)
            if message.get('version') == 1 and message.get('type') != 'progress':
                previous = next(self.previous, None) if self.prefix else None
                record = previous or receiver_records([message], [stamp])[0]
                record = deepcopy(record)
                record['id'] = len(self.records) + 1
                self.records.append(record)
            record = self.session.records[self.job_id]
            # Lists are owned by this receiver and only read under the session
            # condition. Publish incrementally, without copying O(n²) prefixes.
            record.update(messages=self.raw, receiver_messages=self.records,
                source='independent_websocket', stream_completeness='snapshot',
                receiver_identity_source='sdk_local_reception_not_browser_history')
            record.pop('status', None)
            self.changed[message.get('type')] = time.monotonic()
            self.session._condition.notify_all()

    def _run(self):
        from .job_results import fetch_job_record_info
        def request(query, variables, **_):
            if self.requester is None:
                from cloudpss.utils import graphql_request
                requester = graphql_request
            else:
                requester = self.requester
            return requester(query, variables, timeout=min(30, remaining(self.deadline)))
        try:
            snapshot = read_stream(self.initial['job']['output'], block=True, deadline=self.deadline,
                on_open=self._opened, on_message=self._message, stop_event=self.stop_event,
                connect_timeout=self.startup_timeout)
            info = fetch_job_record_info(self.job_id, requester=request)
            terminal = {'COMPLETED', 'FAILED', 'TIMED_OUT', 'CANCELED', 'ABORTING', 'ABORTED', 'KILLED'}
            while snapshot.termination is None and info.get('status') not in terminal:
                if self.stop_event.wait(min(.1, remaining(self.deadline))):
                    raise ResultStreamStopped('SDK result receiver stopped')
                info = fetch_job_record_info(self.job_id, requester=request)
            with self.session._condition:
                if self.stop_event.is_set():
                    raise ResultStreamStopped('SDK result receiver stopped')
                self.session._store_snapshot(self.job_id, info, snapshot)
                self.session.records[self.job_id]['finished'] = datetime.now(timezone.utc).isoformat(
                    timespec='milliseconds').replace('+00:00', 'Z')
                self.state = 'completed'
        except ResultStreamStopped:
            self.state = 'stopped'
        except Exception as exc:
            # Never store arbitrary transport exception text (may hold headers).
            if self.stop_event.is_set():
                self.state = 'stopped'
            else:
                self.error = JobReceiverError(self.job_id,
                    'result receiver deadline reached' if isinstance(exc, TimeoutError) else 'result reception failed')
                self.state = 'failed'
        finally:
            with self.session._condition:
                record = self.session.records[self.job_id]
                record['receiver_state'] = self.state
                if self.error is not None:
                    record['receiver_error'] = str(self.error)
                self.ready.set()
                self.done.set()
                self.session._condition.notify_all()
            self.socket = None

    def stop(self, timeout=2):
        self.stop_event.set()
        socket = self.socket
        if socket is not None:
            try:
                socket.shutdown()
            except Exception:
                pass
        if threading.current_thread() is not self.thread:
            self.thread.join(timeout)
        return self.done.is_set()
