"""Task record/result adapters independent of the browser.

MCP looks up IndexedDB records, NOT arbitrary server tasks (module 83832).
JobResults owns its records and can independently fetch metadata and read the
official binary output stream. Explicit cached records remain authoritative.
Remote messages do not contain browser-local IDs/random keys/receive times.
Independent reception creates and caches SDK-owned records; these are genuine
new observations, never replacements for the browser's historical records.
"""
from copy import deepcopy
from dataclasses import dataclass, field
import json
import math
import time
import re
import threading
from datetime import datetime, timezone

from .remote_reads import _request,RemoteReadError

JOB_QUERY = '''query($input:JobInput!){job(input:$input){
 id args createTime startTime endTime status context user priority input output debug position
 policy{name queue tres{cpu ecpu mem} priority maxDuration}
}}'''
# The browser record combines retained args/input/output with fetchJob's
# default metadata (which excludes debug/policy). Query that exact projection
# independently, rather than deleting extra fields from an arbitrary response.
JOB_RECORD_QUERY = '''query JobRecordMetadata($input:JobInput!){job(input:$input){
 id args createTime startTime endTime status context user priority input output position
}}'''
ABORT_MUTATION = '''mutation AbortSdkJob($input:AbortJobInput!){
 job:abortJob(input:$input){id status}
}'''


class JobAbortError(RuntimeError):
    """The remote mutation may have committed; never retry automatically."""
    def __init__(self, message, *, outcome='unknown', graphql_errors=None):
        super().__init__(message)
        self.outcome = outcome
        self.graphql_errors = graphql_errors


def _validate_plot_layout(value):
    """Validate the public MCP ``plot_layout`` shape before reading a stream.

    The MCP schema is deliberately narrow: each plot key maps to an object
    containing only ``xaxis.range`` and/or ``yaxis.range``; each range is a
    two-number array.  Keeping this validation here prevents an invalid
    request from opening a result subscription and mirrors JSON-schema's
    boolean-versus-number distinction.
    """
    if value is None:
        return
    if not isinstance(value, dict):
        raise TypeError("plot_layout must be an object or None")
    allowed = {"xaxis.range", "yaxis.range"}
    for plot_key, layout in value.items():
        if not isinstance(plot_key, str):
            raise TypeError("plot_layout keys must be strings")
        if not isinstance(layout, dict):
            raise TypeError("each plot layout must be an object")
        unknown = set(layout) - allowed
        if unknown:
            raise TypeError("unsupported plot layout field: " + sorted(unknown)[0])
        for field, bounds in layout.items():
            if not isinstance(bounds, list) or len(bounds) != 2:
                raise TypeError(field + " must be an array of two numbers")
            if any(isinstance(item, bool) or not isinstance(item, (int, float))
                   or not math.isfinite(item) for item in bounds):
                raise TypeError(field + " must contain finite numbers")


def request_abort_job(jobId, *, requester=None, timeout=3):
    """Explicit remote abort, without creating/fetching a browser task record.

    Timeout is the server abort grace period in seconds, not an HTTP timeout.
    No retry on transport, GraphQL or malformed-response errors.
    """
    _job_id(jobId)
    if type(timeout) not in (int,float) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError('timeout must be positive and finite')
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    try:
        raw = requester(ABORT_MUTATION, {'input': {'id':jobId, 'timeout':timeout}}, timeout=30)
    except Exception:
        raise JobAbortError('Abort request failed; remote outcome unknown') from None
    from .component_model import _error_diagnostics
    if not isinstance(raw,dict):
        raise JobAbortError('Invalid abort response; remote outcome unknown')
    if raw.get('errors'):
        raise JobAbortError('Abort returned GraphQL errors; remote outcome unknown',
                            graphql_errors=_error_diagnostics(raw['errors']))
    data = raw.get('data')
    job = data.get('job') if isinstance(data,dict) else None
    if not isinstance(job,dict) or job.get('id') != jobId or not isinstance(job.get('status'),str):
        raise JobAbortError('Missing or inconsistent abort result; remote outcome unknown')
    return deepcopy(job)


def _job_id(value):
    if not isinstance(value,str) or not re.fullmatch(
        r'(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)',value):
        raise TypeError('任务 ID 格式不正确')
    return value


def fetch_job_info(jobId, *, requester=None):
    """Server metadata, explicitly distinct from browser cached get_job_info."""
    _job_id(jobId)
    job = _request(JOB_QUERY, {"input": {"id": jobId}}, requester).get("job")
    if job is None: raise LookupError(f"任务 {jobId} 不存在")
    if not isinstance(job, dict) or job.get("id") != jobId:
        raise ValueError(f"任务 {jobId} 信息不一致")
    return deepcopy(job)


def fetch_job_record_info(jobId, *, requester=None):
    """Read the standard browser-record metadata projection from the service.

    This imports current server state, not a past browser snapshot. Existing
    session records remain authoritative until explicitly refreshed.
    """
    _job_id(jobId)
    try:
        job=_request(JOB_RECORD_QUERY,{'input':{'id':jobId}},requester).get('job')
    except RemoteReadError as exc:
        # Observed NIL/unknown-ID query returns this exact job-level 404.
        # Authentication/other paths/statuses retain their original failure.
        errors=exc.graphql_errors
        if errors and all(e.get('path')==['job'] and e.get('message')=='Not Found'
                          and e.get('status')=='404' for e in errors):
            raise LookupError(f'任务 {jobId} 不存在') from None
        raise
    if job is None:raise LookupError(f'任务 {jobId} 不存在')
    if not isinstance(job,dict) or job.get('id')!=jobId:
        raise ValueError(f'任务 {jobId} 信息不一致')
    return deepcopy(job)


def import_completed_job(jobId, *, session, requester=None, job_fetcher=None, timeout=30):
    """Fetch a terminal server job and its complete raw stream into a session.

    Explicit import does not register it with SimStudio IndexedDB. Stream
    availability/serialization differs from browser worker records and still
    needs online comparison. No jobs or revisions are created.
    """
    if type(timeout) not in (int,float) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("timeout must be positive and finite")
    started = time.monotonic()
    info = fetch_job_info(jobId, requester=requester)
    terminal = {'COMPLETED':'succeeded','FAILED':'failed','TIMED_OUT':'terminated',
                'CANCELED':'terminated','ABORTED':'terminated','KILLED':'terminated'}
    status = terminal.get(info.get('status'))
    if status is None: raise NotImplementedError("Use live transport for active jobs")
    if job_fetcher is None:
        from cloudpss.job.job import Job
        job_fetcher = Job.fetch
    job = job_fetcher(jobId)
    try:
        remaining = timeout - (time.monotonic()-started)
        if remaining <= 0: raise TimeoutError("Task import deadline reached")
        receiver = job.read(timeOut=remaining)
        remaining = timeout - (time.monotonic()-started)
        if remaining <= 0: raise TimeoutError("Task import deadline reached")
        receiver.waitFor(remaining)
        messages = deepcopy(receiver.messages)
        # SDK waitFor also returns after an unsuccessful connection closes.
        # Zero messages therefore do not establish an empty completed result.
        if not messages:
            raise RuntimeError("No result messages received; stream completeness is unverified")
        if any(isinstance(m,dict) and isinstance(m.get('data'),dict)
               and str(m['data'].get('content','')).startswith('消息解析错误:') for m in messages):
            raise RuntimeError("SDK result stream contains a decode error")
        record = {'key':jobId, 'job':info, 'status':status,
                  'messages':messages, 'source':'sdk_completed_stream',
                  'stream_completeness':'sdk_receiver_closed_not_independently_verified'}
    finally:
        job.close()
    session.register(record)
    return None


@dataclass
class JobResults:
    """SDK task-record storage, with built-in independent result transport.

    records: raw exported browser records or explicit SDK records with `job`.
    connect(id, callback, filters) returns a subscription exposing destroy().
    wait_complete(id, timeout) must update records and wait for record.status.
    Callbacks are optional testing/embedding hooks. Without callbacks, unknown
    tasks are fetched by jobId and read directly from the official WebSocket.
    Completed cached messages are returned without a network request.
    """
    records: dict = field(default_factory=dict)
    connect: object = None
    wait_complete: object = None
    renderer: object = None
    finalize_receiver: object = None
    abort_diagnostics: list = field(default_factory=list)
    _condition: object = field(default_factory=threading.Condition, init=False, repr=False, compare=False)
    _receivers: dict = field(default_factory=dict, init=False, repr=False, compare=False)

    def listen(self, jobId, *, timeout=86400, startup_timeout=30, requester=None):
        """Start one independent receiver and wait for its WebSocket handshake.

        Repeated calls reuse the existing receiver. A failed/stopped receiver
        requires explicit retry via stop_receiver followed by listen. The task
        itself is never recreated. timeout bounds reception, not cloud runtime.
        """
        from .job_receiver import JobReceiver
        for value in (timeout, startup_timeout):
            if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
                raise ValueError('Receiver timeouts must be positive and finite')
        with self._condition:
            record = self._record(jobId)
            if record.get('status') and record.get('stream_completeness') == 'normal_close':
                return None
            receiver = self._receivers.get(jobId)
            if receiver is None:
                from .result_stream import stream_url
                stream_url(record['job'].get('output'))
                receiver = JobReceiver(self, jobId, timeout=timeout, startup_timeout=startup_timeout,
                                       requester=requester)
                self._receivers[jobId] = receiver
                record.pop('receiver_error', None)
                record['receiver_state'] = 'connecting'
                try:
                    receiver.thread.start()
                except Exception:
                    del self._receivers[jobId]
                    raise
        if not receiver.ready.wait(startup_timeout):
            receiver.stop()
            from .job_receiver import JobReceiverError
            raise JobReceiverError(jobId, 'receiver startup deadline reached')
        if receiver.error is not None:
            raise receiver.error
        if receiver.state == 'stopped':
            from .job_receiver import JobReceiverError
            raise JobReceiverError(jobId, 'receiver stopped locally')
        return None

    def stop_receiver(self, jobId):
        """Stop SDK reception only; keep the record and do not abort the task."""
        _job_id(jobId)
        with self._condition:
            receiver = self._receivers.get(jobId)
        if receiver is not None:
            if not receiver.stop():
                raise TimeoutError('SDK receiver has not stopped; task ID retained')
            with self._condition:
                if self._receivers.get(jobId) is receiver:
                    del self._receivers[jobId]
        return None

    def close(self):
        """Release local receivers, without remote aborts or deleting records."""
        for jobId in list(self._receivers):
            self.stop_receiver(jobId)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _store_snapshot(self, jobId, info, snapshot):
        """Commit decoded stream state under the session condition."""
        cached = self.records.get(jobId, {})
        replacement = deepcopy(cached or {'key': jobId})
        # Official defaultsDeep preserves creation-only fields such as debug.
        replacement['job'] = {**deepcopy(cached.get('job', {})), **deepcopy(info)}
        replacement.update(messages=deepcopy(snapshot.messages), source='independent_websocket',
            stream_envelopes=deepcopy(snapshot.envelopes),
            stream_completeness='normal_close' if snapshot.complete else 'snapshot',
            stream_termination=deepcopy(snapshot.termination))
        from .result_records import receiver_records
        replacement['receiver_messages'] = receiver_records(snapshot.messages, snapshot.received_at,
            previous_raw=cached.get('messages'), previous_records=cached.get('receiver_messages'))
        replacement['receiver_identity_source'] = 'sdk_local_reception_not_browser_history'
        status = None
        if snapshot.complete:
            data = snapshot.termination or {}
            value = data.get('status')
            if value is None and data.get('succeeded') is not None:
                value = 'resolved' if data['succeeded'] else 'rejected'
            terminal = {'COMPLETED':'succeeded', 'FAILED':'failed', 'TIMED_OUT':'terminated',
                        'CANCELED':'terminated', 'ABORTING':'terminated', 'ABORTED':'terminated', 'KILLED':'terminated'}
            status = ({'resolved':'succeeded', 'rejected':'failed'}.get(value, 'terminated')
                      if snapshot.termination is not None else terminal.get(info.get('status')))
        if status:
            replacement['status'] = status
        else:
            replacement.pop('status', None)
        self.records[jobId] = replacement

    def _read_receiver(self, receiver, block, kind, keys, deadline):
        from .job_receiver import JobReceiverError
        quiet_since = time.monotonic()
        with self._condition:
            while not receiver.done.is_set():
                now = time.monotonic()
                if now >= deadline:
                    raise TimeoutError('Result collection deadline reached; receiver remains active')
                wait = deadline - now
                if not block:
                    quiet = .7 - (now - max(quiet_since, receiver.changed.get(kind, quiet_since)))
                    if quiet <= 0:
                        break
                    wait = min(wait, quiet)
                self._condition.wait(wait)
            if receiver.error is not None:
                raise receiver.error
            record = self._record(receiver.job_id)
            if receiver.state == 'stopped' and not record.get('status'):
                raise JobReceiverError(receiver.job_id, 'receiver stopped locally')
            return deepcopy([m for m in record.get('messages', []) if m.get('type') == kind
                             and (keys is None or m.get('key') in keys)])

    def register(self, record):
        if not isinstance(record,dict):raise TypeError('Record must be an object')
        record = deepcopy(record)
        job = record.get('job')
        if not isinstance(job, dict): raise TypeError("Record must contain job metadata")
        key = _job_id(record.get('key',job.get('id')))
        with self._condition:
            receiver = self._receivers.get(key)
            if receiver is not None and not receiver.done.is_set():
                raise RuntimeError('Stop the active receiver before replacing its record')
            self._receivers.pop(key, None)
            self.records[key] = record

    def import_job_info(self, jobId, *, requester=None, refresh=False):
        """Import only metadata; no results stream or browser access needed.

        Failed reads preserve all existing records. Refresh updates server
        metadata while retaining messages and caller-owned record fields.
        """
        _job_id(jobId)
        if jobId in self.records and not refresh:
            return self.get_job_info(jobId)
        info=fetch_job_record_info(jobId,requester=requester)
        with self._condition:
            replacement=deepcopy(self.records.get(jobId,{'key':jobId}))
            replacement['job']={**replacement.get('job',{}), **info}
            receiver = self._receivers.get(jobId)
            active_receiver = receiver is not None and not receiver.done.is_set()
            terminal={'COMPLETED':'succeeded','FAILED':'failed','TIMED_OUT':'terminated',
                      'CANCELED':'terminated','ABORTING':'terminated','ABORTED':'terminated','KILLED':'terminated'}
            status=terminal.get(info.get('status'))
            if not active_receiver:
                if status:replacement['status']=status
                else:replacement.pop('status',None)
            self.records[jobId]=replacement
        return deepcopy(info)

    def export_records(self):
        """Detached, lossless JSON-compatible session record snapshot."""
        with self._condition:
            return deepcopy(list(self.records.values()))

    def import_records(self, records):
        """Validate the entire batch before replacing/adding any records."""
        if not isinstance(records,list):raise TypeError('records must be a list')
        temporary=JobResults()
        for record in records:temporary.register(record)
        with self._condition:
            if any(k in self._receivers and not self._receivers[k].done.is_set() for k in temporary.records):
                raise RuntimeError('Stop active receivers before importing their records')
            for key in temporary.records:
                self._receivers.pop(key, None)
            self.records.update(temporary.records)
        return None

    def _record(self, jobId):
        _job_id(jobId)
        record = self.records.get(jobId)
        if not isinstance(record, dict) or not record.get('job'):
            raise LookupError(f"任务 {jobId} 不存在")
        if record['job'].get('id') != jobId:
            raise ValueError(f"任务 {jobId} 信息不一致")
        return record

    def get_job_info(self, jobId):
        with self._condition:
            return deepcopy(self._record(jobId)['job'])

    def abort_job(self, jobId, *, requester=None):
        """Mirror MCP's cached-record eligibility and explicit abort operation.

        Official browser behavior reports local termination even if the remote
        abort raises. Retain this distinction in abort_diagnostics: True means
        the local abort path ran, not confirmation of remote cancellation.
        Use request_abort_job for a strict remote-success-only API.
        """
        record = self._record(jobId)
        if record['job'].get('status') not in ('WAITING','RUNNING'):
            raise RuntimeError(f'任务 {jobId} 中止失败，任务可能已经完成或中止')
        returned = None
        try:
            returned = request_abort_job(jobId, requester=requester)
        except JobAbortError as exc:
            self.abort_diagnostics.append({'jobId':jobId, 'remote_outcome':exc.outcome,
                                           'message':str(exc), 'graphql_errors':exc.graphql_errors})
        self.stop_receiver(jobId)
        record = self._record(jobId)
        if self.finalize_receiver is not None:
            self.finalize_receiver(jobId)
        record['status'] = 'terminated'
        record['finished'] = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        if returned is not None:
            # Official update uses defaultsDeep: partial id/status response
            # retains the cached job's other metadata.
            record['job'].update(returned)
        return True

    def _read(self, jobId, block, kind, keys=None, *, timeout=30):
        if type(block) is not bool: raise TypeError("block must be a boolean")
        if type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be positive and finite")
        deadline = time.monotonic() + timeout
        _job_id(jobId)
        receiver = self._receivers.get(jobId)
        if receiver is not None:
            return self._read_receiver(receiver, block, kind, keys, deadline)
        cached = self.records.get(jobId)
        needs_remote = (cached is None or not isinstance(cached.get('messages'), list)
                        or not cached.get('status'))
        if self.connect is None and self.wait_complete is None and needs_remote:
            from .result_stream import read_job_results
            info, snapshot = read_job_results(jobId, block=block, deadline=deadline,
                                              kind=kind, keys=keys)
            # Commit only after transport/decode succeeded. A partial snapshot
            # never substitutes for completion on the next block=True call.
            with self._condition:
                self._store_snapshot(jobId, info, snapshot)
            return deepcopy([m for m in snapshot.messages if m.get('type') == kind
                             and (keys is None or m.get('key') in keys)])
        record = self._record(jobId)
        if block and not record.get('status'):
            if self.wait_complete is None:
                raise NotImplementedError("An active record requires a completion waiter for block=True")
            self.wait_complete(jobId, timeout)
            record = self._record(jobId)
            if not record.get('status'): raise TimeoutError("Task has not completed")
        if self.connect is None:
            if not record.get('status') or not isinstance(record.get('messages'), list):
                raise NotImplementedError("Live stream transport or completed message export is required")
            return deepcopy([m for m in record['messages'] if m.get('type') == kind
                             and (keys is None or m.get('key') in keys)])
        import threading
        condition = threading.Condition()
        messages, last = [], [time.monotonic()]
        def receive(*args):
            message = args[-1]
            with condition:
                messages.append(deepcopy(message))
                last[0] = time.monotonic()
                condition.notify_all()
        subscription = self.connect(jobId, receive, {"typeFilter": [kind], "keyFilter": keys})
        try:
            with condition:
                last[0] = time.monotonic()
                while True:
                    now = time.monotonic()
                    if now >= deadline: raise TimeoutError("Result collection deadline reached")
                    remaining = .7 - (now-last[0])
                    if remaining <= 0: break
                    condition.wait(min(remaining, deadline-now))
            return messages
        finally:
            if subscription is not None: subscription.destroy()

    def get_job_logs(self, jobId, block, *, timeout=30):
        """Read presented logs with stable SDK receiver identities when remote.

        SDK `when` is its actual receive time, not the old browser receive time.
        Source and raw messages remain inspectable in the owning session.
        """
        messages = self._read(jobId, block, 'log', timeout=timeout)
        record = self.records.get(jobId, {})
        if record.get('source') in ('independent_websocket', 'sdk_completed_stream'):
            from .log_results import log_messages
            # Merge before filtering: a later non-log with the same key
            # supersedes earlier logs in the official message store.
            with self._condition:
                presented = log_messages(deepcopy(record.get('receiver_messages', record['messages'])))
            for message in presented:
                message.setdefault('sender', 'remote')
            return presented
        return messages

    def get_job_plots(self, jobId, block, plot_layout=None, *, timeout=30):
        _validate_plot_layout(plot_layout)
        messages = self._read(jobId, block, 'plot',
                              list(plot_layout) if plot_layout is not None else None, timeout=timeout)
        from .plot_results import plot_response
        response = plot_response(messages, plot_layout, renderer=self.renderer)
        # MCP returns a CallToolResult envelope even when a valid filter
        # selects no plots. Keep the pure plot merger's historical [] result,
        # but expose the public SDK tool's envelope consistently.
        if response == []:
            import json
            structured = {'result': []}
            return {'content': [{'type': 'text',
                                 'text': json.dumps(structured, ensure_ascii=False,
                                                    separators=(',', ':'))}],
                    'structuredContent': structured,
                    'isError': False}
        return response


def get_job_info(jobId, *, session=None, requester=None):
    """Cached MCP semantics with session; current standard projection without.

    No implicit refresh of existing records. The stateless path queries the
    server explicitly and cannot recover metadata that exists only in a cache.
    """
    if session is not None:return session.get_job_info(jobId)
    return fetch_job_record_info(jobId,requester=requester)


def abort_job(jobId, *, session, requester=None):
    return session.abort_job(jobId, requester=requester)


def get_job_logs(jobId, block, *, session=None, timeout=30):
    return (session if session is not None else JobResults()).get_job_logs(jobId, block, timeout=timeout)


def get_job_plots(jobId, block, plot_layout=None, *, session=None, timeout=30):
    return (session if session is not None else JobResults()).get_job_plots(jobId, block, plot_layout, timeout=timeout)
