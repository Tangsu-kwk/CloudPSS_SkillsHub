"""Independent checked task submission; supported-scope parity is still partial.

Normal calls need only the SDK model/session and MCP's two business indices.
Definitions and scheduler inputs are discovered via GraphQL. Unknown checker
capabilities raise before mutations; there is no implicit unchecked fallback.
"""
from copy import deepcopy

from .check_environment import load_check_environment
from .diagram_aux import model_from_document
from .job_inputs import JobInputError
from .job_results import JobResults
from .job_submission import prepare_job_submission, submit_job_plan
from .project_check import run_check_mcp
from .remote_reads import _current_user_name


class JobPreflightError(RuntimeError):
    def __init__(self, problems):
        super().__init__('项目中存在错误')
        self.problems = deepcopy(problems)


def prepare_run_job(model, configIndex, jobIndex, *, requester=None):
    """Read independent check inputs, check, and build a detached task plan.

    No mutations or caller-state edits. The current SDK checker refuses known
    unsupported inputs; passing this path is not a blanket proof of full MCP
    checker parity. Explicit fractional/negative indices do not select schemes.
    """
    from math import isfinite
    document = deepcopy(model.toJSON())
    for key, index in (('configs', configIndex), ('jobs', jobIndex)):
        if (type(index) not in (int, float) or not isfinite(index) or index < 0
                or int(index) != index or index >= len(document.get(key, []))):
            raise JobInputError('not selected config')
    owned = model_from_document(document)
    environment = load_check_environment(owned, requester=requester)
    checked = run_check_mcp(owned, **environment)['result']
    if any(problem['level'] == 'error' for problem in checked):
        raise JobPreflightError(checked)
    rid = document['jobs'][int(jobIndex)].get('rid')
    definition = environment['functions'].get(rid)
    if definition is None:
        raise JobInputError('Calculation function is unavailable')
    plan = prepare_job_submission(owned, configIndex, jobIndex, definition=definition,
        author=_current_user_name(), revision_message='Submitted by CloudPSS SDK auto-modeling')
    plan['validation'] = 'sdk_supported_checks_performed'
    plan['preflight_problems'] = deepcopy(checked)
    plan['full_mcp_checker_parity'] = False
    return plan


def run_job(model, configIndex, jobIndex, *, session, requester=None):
    """Check, submit memory revision/task, start SDK receiver; return task ID.

    session is SDK-owned result context, not extra business input. Errors before
    submission never create a revision/task; after mutations known IDs survive
    in JobSubmissionError. No saved project is created or overwritten.
    """
    if not isinstance(session, JobResults):
        raise TypeError('session must be an SDK JobResults instance')
    plan = prepare_run_job(model, configIndex, jobIndex, requester=requester)
    return submit_job_plan(plan, session=session, requester=requester)
