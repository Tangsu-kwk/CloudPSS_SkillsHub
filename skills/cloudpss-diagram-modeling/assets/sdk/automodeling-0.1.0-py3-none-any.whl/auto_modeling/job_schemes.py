"""Calculation scheme editing backed by captured SimStudio cases.

Receives a caller-owned SDK Model; never saves or starts a simulation.
Function definitions use official GraphQL when no resolver is supplied.
Add/update accept the official JSON parameter types and available functions.
"""
from copy import deepcopy
from .scheme_args import fill_args, default_args
from .scheme_indices import numeric_index, read_index, write_index

from .job_functions import get_job_function

_OMITTED = object()
_EMTP = "function/CloudPSS/emtps"


def _name(name):
    if not isinstance(name, str):
        raise TypeError("name must be a string; omit name to leave it unchanged")


def _args(rid, args, definition_resolver, original=None):
    definition = (definition_resolver or get_job_function)(rid)
    if definition is None:
        raise ValueError(f"panic: job function {rid} not found")
    if not isinstance(definition, dict) or definition.get("rid") != rid:
        raise ValueError("Function definition identity mismatch")
    return fill_args(original or {}, args, definition["parameters"])


def _index(model, index):
    if type(index) is not int:
        raise TypeError("job index must be an integer")
    if not 0 <= index < len(model.jobs):
        raise IndexError(f"panic: job index {index} out of range")


def add_job(model, rid, name, args, *, definition_resolver=None):
    """Append converted supplied args and return its index; selection stays."""
    _name(name)
    prepared = _args(rid, args, definition_resolver)
    model.jobs.append({"rid": rid, "name": name, "args": prepared})
    return len(model.jobs) - 1


def update_job(model, index, args, name=_OMITTED, *, definition_resolver=None):
    """Resolve the function and validate the full update before writing.

    Negative list reads follow MiraScript; negative field-path writes are no-ops.
    Explicit None for name is rejected by the currently observed MCP transport.
    """
    if name is not _OMITTED:
        _name(name)
    position = read_index(model.jobs, index, "job")
    job = deepcopy(model.jobs[position])
    prepared = _args(job["rid"], args, definition_resolver, job["args"])
    job["args"] = prepared
    if name is not _OMITTED:
        job["name"] = name
    write_index(model.jobs, index, job)
    return None


def delete_job(model, index, *, definition_resolver=None):
    """Splice any calculation scheme while preserving the current index.

    When the selected slot now holds its successor, materialize editor defaults
    from the available function registry. Validate that definition before writes;
    a resolver/network failure here is a local atomicity policy. No save/run.
    """
    position = numeric_index(index)
    if not 0 <= index < len(model.jobs):
        raise IndexError(f"panic: job index {index} out of range")
    current = model.context.get('currentJob')
    current = 0 if current is None else numeric_index(current)
    prepared = None
    if position <= current < len(model.jobs) - 1:
        successor = model.jobs[current + 1]
        definition = (definition_resolver or get_job_function)(successor['rid'])
        if definition is None:
            raise ValueError(f"panic: job function {successor['rid']} not found")
        if not isinstance(definition, dict) or definition.get('rid') != successor['rid']:
            raise ValueError('Function definition identity mismatch')
        prepared = default_args(definition['parameters'], successor['args'])
    del model.jobs[position]
    if prepared is not None:
        model.jobs[current]['args'] = prepared
    return None
