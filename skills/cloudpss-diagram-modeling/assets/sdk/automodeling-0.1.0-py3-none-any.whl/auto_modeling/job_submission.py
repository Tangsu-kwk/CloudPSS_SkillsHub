"""Explicit task transport helpers; run_job/checker parity is not yet verified.

Preparation is memory-only. submit_job_plan creates a remote revision and task,
does not save the named project and never retries an uncertain mutation.
Caller must perform appropriate project validation before using that helper.
"""
from copy import deepcopy
from datetime import datetime, timezone
import re

from .job_inputs import prepare_job_inputs
from .component_model import _error_diagnostics

REVISION_MUTATION = """mutation PreparedModelRevision($input: CreateModelRevisionInput!) {
 data: createModelRevision(input: $input) { hash }
}"""
JOB_MUTATION = """mutation PreparedModelJob($input: CreateJobInput!) {
 job: createJob(input: $input) { id input output status position }
}"""


class JobSubmissionError(RuntimeError):
    """Expose recovery evidence without retrying or claiming remote rollback."""
    def __init__(self, message, *, stage, outcome, revision_hash=None, job_id=None, graphql_errors=None):
        super().__init__(message)
        self.stage = stage
        self.outcome = outcome
        self.revision_hash = revision_hash
        self.job_id = job_id
        self.graphql_errors = graphql_errors


def prepare_job_submission(model, configIndex, jobIndex, *, definition, author, revision_message):
    """Return a detached two-mutation plan, without checking or submitting.

    author must be the authenticated caller's name. revision_message is explicit
    provenance for this client, not a copied browser version claim. This initial
    helper supports named models; browser-only unsaved document IDs are excluded.
    """
    if not isinstance(author, str) or not author.strip():
        raise TypeError("author must be the authenticated account name")
    if not isinstance(revision_message, str) or not revision_message.strip():
        raise TypeError("revision_message must identify the submitting client")
    document = deepcopy(model.toJSON())
    rid = document.get("rid")
    if not isinstance(rid, str) or not re.fullmatch(r"model/[^/\s]+/[^/\s]+", rid):
        raise NotImplementedError("Task submission currently requires a named model RID")
    revision = document.get("revision")
    if not isinstance(revision, dict) or revision.get("version") != 5:
        raise NotImplementedError("Task submission only supports version 5 model revisions")
    prepared = prepare_job_inputs(model, configIndex, jobIndex, definition=definition)
    revision_input = {key: deepcopy(revision[key]) for key in
                      ("documentation", "graphic", "implements", "parameters", "pins") if key in revision}
    revision_input.update(author=author, message=revision_message, version=5)
    # Official createResourceRevision uses parent ?? revision.hash. Missing
    # parent is omitted in JSON; do not replace with an SDK default null.
    if revision.get("hash") is not None:
        revision_input["parent"] = revision["hash"]
    task = {"context": [prepared["function"], rid], "args": deepcopy(prepared["args"]),
            "policy": deepcopy(prepared["policy"])}
    task["args"]["_ModelArgs"] = deepcopy(prepared["config_args"])
    # undefined debug is omitted by the official JSON client.
    if prepared["debug"] is not None:
        task["debug"] = deepcopy(prepared["debug"])
    return {"revision_input": revision_input, "job_input_without_revision": task,
            "local_display": {"name": f"{prepared['job_name']}_{prepared['config_name']}",
                              "jobArgName": prepared["job_name"], "configArgName": prepared["config_name"]},
            "validation": "not_performed", "named_project_saved": False}


def job_input_with_revision(plan, revision_hash):
    """Bind the server-returned revision hash; never use a local fake hash."""
    if not isinstance(revision_hash, str) or not revision_hash:
        raise TypeError("revision_hash must be a non-empty server-returned hash")
    result = deepcopy(plan["job_input_without_revision"])
    result["args"]["_ModelRevision"] = revision_hash
    return result


def _register_submission(session, plan, job, revision_hash):
    """Retain the official createJob projection in SDK-owned result storage."""
    from .job_results import _job_id
    from .result_stream import stream_url
    job_id = job.get("id")
    try:
        _job_id(job_id)
        if any(key not in job for key in ("input", "output", "status", "position")):
            raise ValueError("Incomplete createJob projection")
        if not isinstance(job["status"], str):
            raise ValueError("Invalid task status")
        stream_url(job["output"])
        if job_id in session.records:
            raise ValueError("Task already registered")
        submitted = job_input_with_revision(plan, revision_hash)
        # Official API.createJob adds these fields to its mutation projection.
        # policy and display names belong to the containing runner record.
        metadata = deepcopy(job)
        metadata.update(context=submitted["context"], args=submitted["args"])
        if "debug" in submitted:
            metadata["debug"] = submitted["debug"]
        record = {**deepcopy(plan["local_display"]), "policy": submitted["policy"],
                  "key": job_id, "job": metadata,
                  "queued": datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                  "source": "sdk_submission"}
        session.register(record)
    except Exception:
        raise JobSubmissionError("Task created but result registration failed; recover the known task, do not resubmit",
            stage="registration", outcome="identifier_received",
            revision_hash=revision_hash, job_id=job_id) from None


def submit_job_plan(plan, *, requester=None, session=None, start_receiver=True):
    """Create revision and job explicitly; return only the job ID as MCP does.

    Low-level transport helper, not run_job: it does not run the MCP project
    checker, navigate UI, save a project or wait for the task. Do not substitute
    SDK Checker for the MCP checker. Optional JobResults session retains the
    actual creation response, args/context and local display metadata without
    a second query. With a session, the SDK starts its background receiver and
    waits for handshake by default; start_receiver=False explicitly defers
    reception. Errors retain known IDs for recovery.
    Transport/invalid-response outcomes are unknown and must not be retried
    automatically. Even a GraphQL error can accompany a committed mutation.
    """
    owned = deepcopy(plan)
    if type(start_receiver) is not bool:
        raise TypeError("start_receiver must be a boolean")
    if session is not None:
        from .job_results import JobResults
        if not isinstance(session, JobResults):
            raise TypeError("session must be an SDK JobResults instance")
        if (not isinstance(owned.get("local_display"), dict)
                or any(not isinstance(owned["local_display"].get(key), str)
                       for key in ("name", "jobArgName", "configArgName"))):
            raise TypeError("Invalid submission display metadata")
    # Validate local plan construction before sending any mutation.
    job_input_with_revision(owned, "local-validation-only")
    if not isinstance(owned.get("revision_input"), dict):
        raise TypeError("Invalid revision submission plan")
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    revision_hash, job_id = None, None
    for stage, query, variables in (
        ("revision", REVISION_MUTATION, {"input": owned["revision_input"]}),
        ("job", JOB_MUTATION, None),
    ):
        if stage == "job":
            variables = {"input": job_input_with_revision(owned, revision_hash)}
        try:
            response = requester(query, deepcopy(variables), timeout=30)
        except Exception:
            raise JobSubmissionError("Submission response unavailable; do not retry before resolving its outcome",
                stage=stage, outcome="unknown", revision_hash=revision_hash) from None
        data = response.get("data") if isinstance(response, dict) else None
        item = data.get("data" if stage == "revision" else "job") if isinstance(data, dict) else None
        identifier = item.get("hash" if stage == "revision" else "id") if isinstance(item, dict) else None
        if isinstance(identifier, str) and identifier:
            if stage == "revision":
                revision_hash = identifier
            else:
                job_id = identifier
        errors = response.get("errors") if isinstance(response, dict) else None
        if errors:
            raise JobSubmissionError("GraphQL reported submission errors; inspect known IDs before further action",
                stage=stage, outcome="identifier_received" if identifier else "unknown",
                revision_hash=revision_hash, job_id=job_id, graphql_errors=_error_diagnostics(errors))
        if not isinstance(identifier, str) or not identifier:
            raise JobSubmissionError("Invalid submission response; do not retry before resolving its outcome",
                stage=stage, outcome="unknown", revision_hash=revision_hash, job_id=job_id)
    if session is not None:
        _register_submission(session, owned, item, revision_hash)
        if start_receiver:
            try:
                session.listen(job_id, requester=requester)
            except Exception:
                raise JobSubmissionError("Task created but result receiver startup failed; reattach the known task, do not resubmit",
                    stage="receiver", outcome="identifier_received",
                    revision_hash=revision_hash, job_id=job_id) from None
    return job_id
