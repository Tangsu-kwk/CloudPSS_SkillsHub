"""Remote log presentation matching SimStudio 5.0.39 module 58871.

Transport messages stay raw in the session. Anonymous messages have distinct
identities in the browser receiver; keep them distinct without manufacturing
its random keys, local database IDs or historical receive timestamps.
"""
from copy import deepcopy
import re

_PATH = re.compile(r"(/(canvas_[0-9]+_[0-9]+|component_[a-zA-Z0-9_]+|comp_[a-zA-Z0-9_]+|edge_[a-zA-Z0-9_]+))+")
_ESCAPES = {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}
_MISSING = object()


def _string(value):
    # String(value ?? '') in the public formatter, including JSON values.
    if value is None: return ''
    if value is True: return 'true'
    if value is False: return 'false'
    if isinstance(value, dict): return '[object Object]'
    if isinstance(value, list):
        return ','.join('' if v is None else _string(v) for v in value)
    return str(value)


def _escape(value):
    return re.sub(r'''[&<>"']''', lambda m: _ESCAPES[m[0]], value)


def log_html(content, html=False):
    """Escape text, preserve indentation and link diagram-cell paths."""
    text = _string(content)
    if html: return text
    def ordinary(part):
        return re.sub(r'\r?\n( {2,})?',
                      lambda m: '<br>\n' + '&nbsp;' * len(m[1] or ''), _escape(part))
    output, start = [], 0
    for match in _PATH.finditer(text):
        output.extend((ordinary(text[start:match.start()]),
                       '<cwe-link type="design/diagram/cells" value="' +
                       _escape(match[0]) + '"></cwe-link>'))
        start = match.end()
    output.append(ordinary(text[start:]))
    return ''.join(output)


def log_messages(messages):
    """Merge log groups and return detached HTML messages, in key order.

    Browser-cached records already have this presentation. Call this only for
    raw remote streams, not on caller-supplied browser records.
    """
    groups = {}
    for index, original in enumerate(messages):
        message = deepcopy(original)
        key = message.get('key')
        identity = ('key', key) if key else ('anonymous', index)
        groups.setdefault(identity, []).append(message)
    result = []
    for group in groups.values():
        # Message merger drops the earlier types for a reused key.
        kind = group[-1].get('type')
        start = len(group) - 1
        while start > 0 and group[start - 1].get('type') == kind: start -= 1
        group = group[start:]
        if kind != 'log': continue
        resets = [i for i, m in enumerate(group)
                  if not m.get('verb') or m['verb'] in ('create', 'replace')]
        if resets:
            group, verb = group[resets[-1]:], 'replace'
        elif all(m.get('verb') == 'append' for m in group): verb = 'append'
        elif all(m.get('verb') == 'prepend' for m in group): verb = 'prepend'
        else: verb = None
        if verb:
            content, level = '', _MISSING
            for message in group:
                data = message['data']
                formatted = log_html(data.get('content'), data.get('html'))
                action = message.get('verb')
                if action not in ('append', 'prepend'):
                    level, content = data.get('level', _MISSING), formatted
                else:
                    if level is None or level is _MISSING: level = data.get('level', _MISSING)
                    content = content + formatted if action == 'append' else formatted + content
            merged = dict(group[0], verb=verb)
            merged['data'] = {'content': content, 'html': True}
            if level is not _MISSING: merged['data']['level'] = level
            result.append(merged)
        else:
            for message in group:
                data = message['data']
                data['content'] = log_html(data.get('content'), data.get('html'))
                data['html'] = True
                result.append(message)
    return result
