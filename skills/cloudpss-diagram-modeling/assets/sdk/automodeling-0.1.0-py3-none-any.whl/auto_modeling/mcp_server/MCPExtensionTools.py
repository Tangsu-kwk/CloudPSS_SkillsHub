from typing import Annotated, Dict

from pydantic import Field
from auto_modeling.core import ServiceResult
from auto_modeling.providers.manager import BaseProvider
from fastmcp.server.server import FastMCP
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent


class MCPExtensionTools():
    server = None

    def __init__(self, provider: BaseProvider, server: FastMCP):
        self.provider = provider
        self.server = server
        self._register_tools()

    # def _register_tools(self) -> None:
    #     """统一注册MCP工具"""
    #     self.server.tool(self.add_comp_output_measures, name="add_comp_output_measures")
    #     self.server.tool(self.undo, name="undo")
    #     self.server.tool(self.redo, name="redo")
    #     self.server.tool(self.update_all_mapping, name="update_all_mapping")

    def _to_tool_result(self, service_result: ServiceResult) -> ToolResult:

        structured_content = {"message":service_result.message or ""}
        if service_result.data is not None:
            structured_content["data"] = service_result.data
        if service_result.partial_details:
            structured_content["partial_details"] = service_result.partial_details

        return ToolResult(
            # content=[TextContent(type="text",text=service_result.message)],
            structured_content=structured_content,
        )

    def _register_tools(self) -> None:
        """
        动态注册：从extension对象获取其声明的工具列表
        逐个包装成MCP Tool并注册
        """
        
        extension_tools = self.provider.extension.get_tools()
        for tool in extension_tools:
            # 用闭包捕获当前的ext_tool.func，避免循环变量问题
            def _make_handler(tool_func):
                def handler(*args, **kwargs) -> ToolResult:
                    try:
                        return self._to_tool_result(tool_func(*args, **kwargs))
                    except Exception as e:
                        return ToolResult(
                            content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")] 
                        )

                # 保留原函数的“元信息”——把tool_func函数的名称、描述、参数等复制到handler函数上
                import functools
                functools.update_wrapper(handler, tool_func)
                # 覆盖返回值注解：handler 实际返回 ToolResult，不是 ServiceResult
                handler.__annotations__['return'] = ToolResult  
                return handler

            self.server.tool(
                _make_handler(tool.func), 
                name=tool.name
            )
