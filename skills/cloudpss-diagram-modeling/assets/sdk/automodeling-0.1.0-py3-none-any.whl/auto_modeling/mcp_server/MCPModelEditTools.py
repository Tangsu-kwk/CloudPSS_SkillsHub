from typing import Annotated, Dict, List, Optional, Tuple

from pydantic import Field
from auto_modeling.core import ServiceResult
from auto_modeling.providers.manager import BaseProvider
from fastmcp.server.server import FastMCP
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent

class MCPModelEditTools():
    server  = None
    
    def __init__(self, provider: BaseProvider,server: FastMCP):
        self.provider = provider
        self.server = server
        self._register_tools()

    def _register_tools(self) -> None:
        """统一注册MCP工具"""
        self.server.tool(self.add_component, name="add_component")
        self.server.tool(self.add_shunt_component, name="add_shunt_component")
        self.server.tool(self.insert_series_component, name="insert_series_component")
        self.server.tool(self.conn_components, name="conn_components")
        self.server.tool(self.create_canvas, name="create_canvas")
        self.server.tool(self.update_params, name="update_params")
        self.server.tool(self.del_component, name="del_component")

    def _to_tool_result(self, service_result: ServiceResult) -> ToolResult:

        structured_content = {"message":service_result.message or ""}
        if service_result.data is not None:
            structured_content["data"] = service_result.data
        if service_result.partial_details:
            structured_content["partial_details"] = service_result.partial_details

        return ToolResult(
            # content=[TextContent(type="text",text=service_result.message)],
            structured_content=structured_content,
        )

    def add_component(
        self, 
        comp_rid: Annotated[str, Field(description="需要添加的元件的RID")], 
        comp_label: Annotated[Optional[str], Field(description="元件的label")] = None,
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None, 
        pins: Annotated[Optional[Dict], Field(description="期望设置的引脚")] = None,
        position: Annotated[Optional[Tuple] , Field(description="元件的位置")] = None, 
        canvas: Annotated[Optional[str], Field(description="元件所属的图纸")] = None
    ) -> ToolResult:
        """
        添加元件到模型中
        """
        try:

            add_component_result = self.provider.model_edit.add_component(comp_rid, comp_label, args, pins, position, canvas)
            
            return self._to_tool_result(add_component_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def add_shunt_component(
        self,
        comp_rid: Annotated[str, Field(description="需要添加的元件的RID")],
        target_comp_label: Annotated[str, Field(description="目标元件标签/名称")],
        comp_label: Annotated[Optional[str], Field(description="新增元件的标签/名称")] = None,
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None,
        position: Annotated[Optional[Tuple], Field(description="元件的位置")] = None,
        canvas: Annotated[Optional[str], Field(description="元件所属的图纸")] = None,
    ) -> ToolResult:
        """
        向模型中添加元件, 并与指定的某个元件相连
        """
        try:
            add_shunt_component_result = self.provider.model_edit.add_shunt_component(
                comp_rid,
                target_comp_label,
                comp_label,
                args,
                position,
                canvas,
            )
            return self._to_tool_result(add_shunt_component_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def insert_series_component(
        self,
        comp_rid: Annotated[str, Field(description="需要添加的元件的RID")],
        target_comp_label_A: Annotated[str, Field(description="其中一个目标元件的标签/名称")],
        target_comp_label_B: Annotated[str, Field(description="另一个目标元件的标签/名称")],
        comp_label: Annotated[Optional[str], Field(description="新增元件标签/名称")] = None,
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None,
        position: Annotated[Optional[Tuple], Field(description="元件的位置")] = None,
        canvas: Annotated[Optional[str], Field(description="元件所属的图纸")] = None,
    ) -> ToolResult:
        """
        在两个元件之间插入一个元件，需确保两个元件之间是直连的。
        """
        try:
            insert_series_component_result = self.provider.model_edit.insert_series_component(
                comp_rid,
                target_comp_label_A,
                target_comp_label_B,
                comp_label,
                args,
                position,
                canvas,
            )
            return self._to_tool_result(insert_series_component_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def conn_components(
        self,
        source_comp_label: Annotated[str, Field(description="源元件标签/名称")],
        target_comp_label: Annotated[str, Field(description="目标元件标签/名称")],
        source_pin: Annotated[Optional[Dict], Field(description="源元件引脚信息")] = None,
        target_pin: Annotated[Optional[Dict], Field(description="目标元件引脚信息")] = None,
    ) -> ToolResult:
        """
        在两个指定的元件之间建立电气连接。
        """
        try:
            conn_components_result = self.provider.model_edit.conn_components(
                source_comp_label,
                target_comp_label,
                source_pin,
                target_pin,
            )
            return self._to_tool_result(conn_components_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def create_canvas(
        self,
        canvas: Annotated[str, Field(description="图纸的key")],
        name: Annotated[str, Field(description="图纸的名称")],
    ) -> ToolResult:
        """
        新增图纸。
        """
        try:
            create_canvas_result = self.provider.model_edit.create_canvas(canvas, name)
            return self._to_tool_result(create_canvas_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def update_params(
        self,
        comp_labels: Annotated[Optional[List], Field(description="元件标签/名称列表")] = None,
        comp_rid: Annotated[Optional[str], Field(description="元件的RID")] = None,
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None,
    ) -> ToolResult:
        """
        更新元件参数,支持按key批量更新和按rid批量更新两种方式
        """
        try:
            update_params_result = self.provider.model_edit.update_params(comp_labels, comp_rid, args)
            return self._to_tool_result(update_params_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def del_component(
        self,
        comp_labels: Annotated[Optional[List], Field(description="待删除元件标签/名称列表")] = None,
        comp_rid: Annotated[Optional[str], Field(description="待删除元件的RID")] = None,
    ) -> ToolResult:
        """
        删除模型中的元件,支持按key批量删除和按rid批量删除两种方式。
        """
        try:
            del_component_result = self.provider.model_edit.del_component(comp_labels, comp_rid)
            return self._to_tool_result(del_component_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )
