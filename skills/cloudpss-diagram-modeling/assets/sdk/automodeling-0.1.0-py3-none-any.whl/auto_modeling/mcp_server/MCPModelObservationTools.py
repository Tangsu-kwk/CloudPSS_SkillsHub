from typing import Annotated, List

from pydantic import Field
from auto_modeling.core import ServiceResult
from auto_modeling.providers.manager import BaseProvider
from fastmcp.server.server import FastMCP
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent


class MCPModelObservationTools():
    server = None

    def __init__(self, provider: BaseProvider, server: FastMCP):
        self.provider = provider
        self.server = server
        self._register_tools()

    def _register_tools(self) -> None:
        """统一注册MCP工具"""
        self.server.tool(self.get_topology_relation, name="get_topology_relation")
        self.server.tool(self.get_comp_params, name="get_comp_params")
        self.server.tool(self.get_comp_pins, name="get_comp_pins")

    def _to_tool_result(self, service_result: ServiceResult) -> ToolResult:

        structured_content = {"message":service_result.message or ""}
        if service_result.data is not None:
            structured_content["data"] = service_result.data
        if service_result.partial_details:
            structured_content["partial_details"] = service_result.partial_details

        return ToolResult(
            # content=[TextContent(type="text",text=service_result.message)],
            structured_content=structured_content,
        )

    def get_topology_relation(
        self,
        comp_label: Annotated[str, Field(description="目标元件的标签/名称")],
        max_depth: Annotated[int, Field(description="最大遍历深度（跳数）", gt=0)] = 1,
        # min_depth: Annotated[int, Field(description="最小遍历深度，默认0。设置为 >0 可仅返回新增层级的数据。", ge=0)] = 0,
    ) -> ToolResult:
        """
        基于BFS获取指定元件周围指定跳数内的拓扑连接关系。
        """
        min_depth = 0
        try:
            get_topology_relation_result = self.provider.model_observation.get_topology_relation(
                comp_label,
                max_depth,
                min_depth,
            )
            return self._to_tool_result(get_topology_relation_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def get_comp_params(
        self,
        comp_labels: Annotated[List[str], Field(description="目标元件标签/名称列表")],
    ) -> ToolResult:
        """
        获取指定元件的详细参数
        """
        try:
            get_comp_params_result = self.provider.model_observation.get_comp_params(comp_labels)
            return self._to_tool_result(get_comp_params_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def get_comp_pins(
        self,
        comp_labels: Annotated[List[str], Field(description="目标元件标签/名称列表")],
    ) -> ToolResult:
        """
        获取指定元件的引脚信息
        """
        try:
            get_comp_pins_result = self.provider.model_observation.get_comp_pins(comp_labels)
            return self._to_tool_result(get_comp_pins_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )
