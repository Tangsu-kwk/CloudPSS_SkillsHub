from typing import Annotated, Dict, List, Literal, Optional

from pydantic import Field
from auto_modeling.core import ServiceResult
from auto_modeling.providers.manager import BaseProvider
from fastmcp.server.server import FastMCP
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent


class MCPSimulationAnalysisTools():
    server = None

    def __init__(self, provider: BaseProvider, server: FastMCP):
        self.provider = provider
        self.server = server
        self._register_tools()

    def _register_tools(self) -> None:
        """统一注册MCP工具"""
        self.server.tool(self.create_or_update_job, name="create_or_update_job")
        self.server.tool(self.create_or_update_config, name="create_or_update_config")
        self.server.tool(self.get_current_job, name="get_current_job")
        self.server.tool(self.get_current_config, name="get_current_config")
        self.server.tool(self.run_simulation, name="run_simulation")
        self.server.tool(self.check_simulation_status, name="check_simulation_status")
        self.server.tool(self.save_simulation_results, name="save_simulation_results")
        # self.server.tool(self.check_voltage, name="check_voltage")
        # self.server.tool(self.check_power_angle_diff, name="check_power_angle_diff")
        # self.server.tool(self.check_frequency, name="check_frequency")

    def _to_tool_result(self, service_result: ServiceResult) -> ToolResult:

        structured_content = {"message":service_result.message or ""}
        if service_result.data is not None:
            structured_content["data"] = service_result.data
        if service_result.partial_details:
            structured_content["partial_details"] = service_result.partial_details

        return ToolResult(
            # content=[TextContent(type="text",text=service_result.message)],
            structured_content=structured_content,
        )

    def create_or_update_job(
        self,
        flag: Annotated[str, Literal["create", "update"], Field(description="操作标识，表示创建一个计算方案还是修改已有的计算方案。'create'表示创建，'update'表示修改")],
        stype: Annotated[str, Literal["emtps", "power-flow"], Field(description="计算方案的类型，'emtps'表示电磁暂态仿真，'power-flow'表示潮流计算")],
        name: Annotated[str, Field(description="计算方案的名称")],
        param: Annotated[Optional[Dict], Field(description="计算方案的参数")] = None,
    ) -> ToolResult:
        """
        创建或更新一个计算方案
        """
        try:
            create_or_update_job_result = self.provider.simulation_analysis.create_or_update_job(
                flag,
                stype,
                name,
                param,
            )
            return self._to_tool_result(create_or_update_job_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def create_or_update_config(
        self,
        flag: Annotated[str, Literal["create", "update"], Field(description="操作标识，表示创建一个参数方案还是修改已有的参数方案。'create'表示创建，'update'表示修改")],
        name: Annotated[str, Field(description="参数方案的名称")],
        param: Annotated[Optional[Dict], Field(description="参数方案的参数")] = None,
        pins: Annotated[Optional[Dict], Field(description="仿真配置引脚信息")] = None,
    ) -> ToolResult:
        """
        创建或更新一个参数方案
        """
        try:
            create_or_update_config_result = self.provider.simulation_analysis.create_or_update_config(
                flag,
                name,
                param,
                pins,
            )
            return self._to_tool_result(create_or_update_config_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def get_current_job(
        self,
        job_name: Annotated[Optional[str], Field(description="计算方案名称，不指定时查询所有")] = None,
        stype: Annotated[Optional[str], Literal["emtps", "power-flow"], Field(description="'emtps'或'power-flow'，表示电磁暂态仿真或潮流计算。")] = None,
    ) -> ToolResult:
        """
        获取模型中当前已有的计算方案
        """
        try:
            get_current_job_result = self.provider.simulation_analysis.get_current_job(job_name, stype)
            return self._to_tool_result(get_current_job_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def get_current_config(
        self,
        config_name: Annotated[Optional[str], Field(description="参数方案名称，不指定时查询所有")] = None,
    ) -> ToolResult:
        """
        获取模型中当前已有的参数方案
        """
        try:
            get_current_config_result = self.provider.simulation_analysis.get_current_config(config_name)
            return self._to_tool_result(get_current_config_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def run_simulation(
        self,
        job_name: Annotated[str, Field(description="计算方案名称")],
        config_name: Annotated[str, Field(description="参数方案名称")],
    ) -> ToolResult:
        """
        运行仿真。会一直运行，直到仿真结束
        """
        try:
            run_simulation_result = self.provider.simulation_analysis.run_simulation(job_name, config_name)
            return self._to_tool_result(run_simulation_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def check_simulation_status(self) -> ToolResult:
        """
        检查当前仿真状态。
        """
        try:
            check_simulation_status_result = self.provider.simulation_analysis.check_simulation_status()
            return self._to_tool_result(check_simulation_status_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def save_simulation_results(
        self,
        job_name: Annotated[str, Field(description="当前仿真使用的计算方案名称")],
    ) -> ToolResult:
        """
        保存当前仿真结果。
        """
        try:
            save_simulation_results_result = self.provider.simulation_analysis.save_simulation_results(job_name)
            return self._to_tool_result(save_simulation_results_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    '''
    def check_voltage(
        self,
        job_name: Annotated[str, Field(description="当前使用的计算方案名称")],
        bus_channel_idx: Annotated[int, Field(description="母线电压通道索引")],
    ) -> ToolResult:
        """
        检查电压稳定性，并返回最低电压值。
        """
        try:
            check_voltage_result = self.provider.simulation_analysis.check_voltage(job_name, bus_channel_idx)
            return self._to_tool_result(check_voltage_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def check_power_angle_diff(
        self,
        job_name: Annotated[str, Field(description="当前使用的计算方案名称")],
        bus_channel_idx: Annotated[int, Field(description="母线电压通道索引")],
    ) -> ToolResult:
        """
        检查功角差，并返回最大功角差 (deg)。
        """
        try:
            check_power_angle_diff_result = self.provider.simulation_analysis.check_power_angle_diff(job_name, bus_channel_idx)
            return self._to_tool_result(check_power_angle_diff_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )

    def check_frequency(
        self,
        job_name: Annotated[str, Field(description="当前使用的计算方案名称")],
        bus_channel_idx: Annotated[int, Field(description="母线电压通道索引")],
    ) -> ToolResult:
        """
        检查频率稳定性，并返回最大频率偏移值 (Hz)。
        """
        try:
            check_frequency_result = self.provider.simulation_analysis.check_frequency(job_name, bus_channel_idx)
            return self._to_tool_result(check_frequency_result)
        except Exception as e:
            return ToolResult(
                content=[TextContent(type="text",text=f"工具调用异常：{str(e)}")]
            )
    '''