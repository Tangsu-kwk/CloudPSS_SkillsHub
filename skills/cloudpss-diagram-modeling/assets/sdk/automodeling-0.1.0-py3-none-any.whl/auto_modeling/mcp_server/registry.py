from .MCPExtensionTools import MCPExtensionTools
from .MCPModelEditTools import MCPModelEditTools
from .MCPModelObservationTools import MCPModelObservationTools
from .MCPSimulationAnalysisTools import MCPSimulationAnalysisTools

_TOOL_CLASSES = [
    MCPExtensionTools,
    MCPModelEditTools,
    MCPModelObservationTools,
    MCPSimulationAnalysisTools,
]


def register_all_tools(provider, server):
    for tool_cls in _TOOL_CLASSES:
        tool_cls(provider, server)
