"""Official parameter constraint rules on explicit evaluated values.

Pure memory helper for run_check development. No model/definition fetching.
Unsupported regex/dynamic callback behavior raises, never reports success.
"""
from copy import deepcopy
import math
import re

from .job_inputs import _json_numbers, _expression
from .diagram_connections import _condition, _evaluate

_UNDEFINED = object()


def _number(value):
    # ECMAScript Number (constraints), distinct from MiraScript to_number.
    if value is None:
        return 0
    if type(value) is bool:
        return int(value)
    if type(value) in (int, float):
        return value
    if isinstance(value, list):
        value = ','.join('' if v is None else _string(v) for v in value)
    if not isinstance(value, str):
        return math.nan
    value = value.strip()
    if not value:
        return 0
    if re.fullmatch(r'0[xX][0-9a-fA-F]+|0[bB][01]+|0[oO][0-7]+', value):
        return int(value, 0)
    if not re.fullmatch(r'[+-]?(?:(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|Infinity)', value):
        return math.nan
    return float(value)


def _string(value):
    if value is _UNDEFINED:return 'undefined'
    if value is None:return 'null'
    if value is True:return 'true'
    if value is False:return 'false'
    if isinstance(value, dict):return '[object Object]'
    if isinstance(value, list):return '['+', '.join(_string(v) for v in value)+']'
    if type(value) in (int,float):
        if value == 0:return '0'
        if not math.isfinite(value):return 'NaN' if math.isnan(value) else 'Infinity' if value>0 else '-Infinity'
        # JS Number.toString uses fixed notation for [1e-6, 1e21). Python
        # switches much earlier and pads exponent zeroes; neither is MCP text.
        from decimal import Decimal
        text=repr(value)
        if 1e-6 <= abs(value) < 1e21:
            return format(Decimal(text),'f').rstrip('0').rstrip('.') if '.' in format(Decimal(text),'f') else format(Decimal(text),'f')
        if 'e' not in text.lower():text=format(Decimal(text).normalize(),'e')
        mantissa, exponent=text.lower().split('e')
        mantissa=mantissa.rstrip('0').rstrip('.') if '.' in mantissa else mantissa
        exponent=int(exponent)
        return mantissa+'e'+('+' if exponent>=0 else '-')+str(abs(exponent))
    return str(value)


def _strict_equal(a, b):
    if type(a) in (int,float) and type(b) in (int,float):return a == b
    return type(a) is type(b) and a == b


def check_parameter_constraints(value, field, *, scope, data, message='component arg:unsatisfied constraint'):
    """Return untranslated worker problem records in constraint order.

    scope is an explicit MiraScript scope. Scalar numeric/text, pinLike and
    static/expression choices plus expression conditions are supported. Other validators
    or callbacks refuse instead of silently skipping the rule.
    """
    if value is None:value=field.get('value',_UNDEFINED)
    rules=[]
    def add(text, valid, extra=None):
        rules.append({'message':text,'condition':valid,'messageData':extra})
    kind=field.get('type')
    if kind in ('integer','real'):
        number=_number(value)
        if kind=='integer':add('value must be integer',math.isfinite(number) and int(number)==number and abs(number)<=2**53-1)
        add('value must be number',math.isfinite(number))
        lo,hi=field.get('minimum'),field.get('maximum')
        interval=field.get('interval')
        if lo is not None:
            add('value less than minimum',not number<lo,{'minimum':lo})
            if interval in ('open','left-open'):add('value equal to minimum',not number<=lo,{'minimum':lo})
        if hi is not None:
            add('value greater than maximum',not number>hi,{'maximum':hi})
            if interval in ('open','right-open'):add('value equal to maximum',not number>=hi,{'maximum':hi})
    elif kind=='text':
        text='' if value is None or value is _UNDEFINED else _string(value)
        length=len(text.encode('utf-16-le',errors='surrogatepass'))//2
        lo,hi=field.get('minLength'),field.get('maxLength')
        if lo is not None:add('value shorter than minimum length',length>=lo,{'minLength':lo})
        if hi is not None:add('value longer than maximum length',length<=hi,{'maxLength':hi})
        pattern=field.get('pattern')
        if pattern:
            # Do not claim Python's regex semantics equal JavaScript RegExp.
            raise NotImplementedError('JavaScript pattern constraints require a compatible regex engine')
    elif kind=='pinLike':
        if field.get('connection')=='input':add('input value should be connected',bool('' if value is None or value is _UNDEFINED else _string(value)))
    elif kind in ('choice','multiSelect','logical'):
        choices=field.get('choices')
        if isinstance(choices,list) or _expression(choices) or callable(choices):
            from .choice_checks import evaluate_choices
            normalized=evaluate_choices(field,scope)
            selected=value if kind=='multiSelect' and isinstance(value,list) else [value]
            def match(item):
                return next((choice for choice in normalized if _strict_equal(choice['key'],item)),_UNDEFINED)
            valid=(kind!='multiSelect' or isinstance(value,list)) and all(match(item) is not _UNDEFINED for item in selected)
            detail={'choices':deepcopy(choices) if isinstance(choices,list) and not field.get('_runtime_dynamic_choice') else None}
            add('value is not a valid choice',valid,detail)
            enabled=kind!='multiSelect' or isinstance(value,list)
            for item in selected:
                choice=match(item)
                if choice is not _UNDEFINED and isinstance(choice,dict) and not _condition(scope,choice.get('condition')):enabled=False
            add('value is not an enabled choice',enabled,detail)
    elif kind=='resourceId':
        raise NotImplementedError('Resource identifier constraints are not yet supported')
    custom=field.get('constraints') or []
    insert=len(rules)
    for rule in custom:
        if not isinstance(rule,dict) or not rule.get('message') or (not rule.get('condition') and not rule.get('_runtime_resolved')) or rule.get('level') not in (None,'error','warning','info'):
            continue
        rule=deepcopy(rule)
        if callable(rule['condition']) or callable(rule.get('messageData')):
            raise NotImplementedError('Callback constraints are not yet supported')
        rule['_custom']=not rule.get('_runtime_resolved',False)
        if rule.get('order')=='pre':rules.insert(0,rule);insert+=1
        elif rule.get('order')=='post':rules.append(rule)
        else:rules.insert(insert,rule);insert+=1
    problems=[]
    for rule in rules:
        passed=_condition(scope,rule['condition']) if rule.get('_custom') else rule['condition']
        if passed:continue
        detail=rule.get('messageData')
        if isinstance(detail,str):detail=_evaluate(scope,{'source':detail,'ɵexp':''})
        level=rule.get('level') or 'error'
        problems.append({'message':message,'data':{'constraint':rule['message'],
                         'constraintData':deepcopy(detail),'value':_string(value),**deepcopy(data)},'level':level})
        if level=='error':break
    return _json_numbers(problems)
