"""Validate revision parameter definitions using the published checker rules.

This is a pure memory stage. It does not fetch definitions, evaluate browser
callbacks or mutate the caller document. Expression choices use an explicit
scope; unresolved callbacks and unverified VM diagnostics remain refusals.
"""
from copy import deepcopy
import math
import re

from .diagram_connections import _condition, _evaluate, _DiagramScope
from .job_inputs import _expression
from .job_inputs import _convert, _FAIL
from .expression_diagnostics import expression_error
from .graphic_checks import _condition_result
from .parameter_checks import check_parameter_constraints, _string

_TYPES={"real","integer","text","code","logical","choice","multiSelect","table","file","pinLike"}
_INTERVALS={"open","left-open","right-open","closed"}
_LEVELS={"error","warning","info"}


def _valid_key(value, ascii_only=False):
    if not isinstance(value,str) or not value:return False
    if ascii_only:return re.fullmatch(r"[_a-zA-Z][_a-zA-Z0-9]*",value) is not None
    return re.fullmatch(r"(?:_+|[^\W\d])[^\W]*",value,re.UNICODE) is not None


def _num(value):
    return type(value) in (int,float) and math.isfinite(value)


def _data(path, **extra):return {"path":path,**extra}


def _problem(message, path, level, **extra):
    return {"message":message,"data":_data(path,**extra),"level":level}


def _condition_problem(value, scope, message, path, level="warning", **extra):
    if callable(value):raise NotImplementedError("Callback parameter conditions are unsupported")
    if value in (None,""):return []
    try:
        valid,result=_condition_result(scope,value)
        if not valid:raise ValueError(result)
    except Exception as exc:
        return [_problem(message,path,level,error=str(exc),**extra)]
    return []


def _value_checks(field, scope, path, data):
    value=field.get("value")
    try:evaluated=_convert(_evaluate(scope,value),field,value)
    except ValueError as exc:
        return [_problem('parameter value:invalid expression',path+'.value','warning',error=expression_error(exc),**data)]
    problems=[]
    if not _expression(value):
        converted=_convert(value,field,_FAIL)
        def typename(v):
            if v is _FAIL:return 'uninitialized'
            if v is None:return 'nil'
            if type(v) is bool:return 'boolean'
            if type(v) in (int,float):return 'number'
            if isinstance(v,str):return 'string'
            if isinstance(v,list):return 'array'
            return 'record'
        if converted is _FAIL:
            raise NotImplementedError('Conversion failure diagnostic is not yet verified')
        original_type,converted_type=typename(value),typename(converted)
        if original_type!=converted_type:
            problems.append(_problem('parameter value:invalid value',path+'.value','error',
                error=f'expected {converted_type}, got {original_type}',**data))
    found=check_parameter_constraints(evaluated,field,scope=scope,message='parameter value:unsatisfied constraint',
        data={**data,'path':path+'.value'})
    problems.extend(dict(p,level='warning') for p in found if p['level']=='error')
    return problems


def check_parameter_definitions(document):
    """Return official-style `parameters` group problem records.

    Static and expression choices/defaults use the original default scope.
    Unknown callbacks and unverified diagnostic forms remain explicit refusals.
    """
    document=deepcopy(document)
    revision=document.get("revision",{})
    parameters=revision.get("parameters",[])
    if not isinstance(parameters,list):raise TypeError("revision.parameters must be a list")
    defaults={};problems=[];seen={}
    for group in parameters:
        for field in group.get('items',[]):
            key=field.get('key')
            if isinstance(key,str) and key.strip() and key.strip() not in defaults:
                defaults[key.strip()]=deepcopy(field.get('value'))
    scope=_DiagramScope(defaults,{'definition':document.get('rid',document),'args':defaults},document,defaults)
    for gi,group in enumerate(parameters):
        if not isinstance(group,dict):raise TypeError("parameter group must be an object")
        gname=group.get("name") or f"[{gi+1}]";gpath=f"revision.parameters.{gi}"
        if not isinstance(group.get("name"),str) or not group.get("name","").strip():
            problems.append(_problem("group name:empty",gpath+".name","warning",groupPointer=gname))
        if not isinstance(group.get("description"),str) or not group.get("description","").strip():
            problems.append(_problem("group description:empty",gpath+".description","info",groupPointer=gname))
        problems.extend(_condition_problem(group.get("condition"),scope,"group condition:invalid expression",gpath+".condition",groupPointer=gname))
        items=group.get("items",[])
        if not isinstance(items,list):raise TypeError("parameter items must be a list")
        for pi,field in enumerate(items):
            if not isinstance(field,dict):raise TypeError("parameter must be an object")
            key=field.get("key");label=field.get("name") or key or f"[{pi+1}]";path=f"{gpath}.items.{pi}"
            pointer=f"{gname}.{label}"
            if not _valid_key(key):
                problems.append(_problem("parameter key:invalid",path+".key","error",groupPointer=gname,paramPointer=pointer))
            elif key in seen:
                problems.append(_problem("parameter key:duplicate",path+".key","error",groupPointer=gname,paramPointer=pointer,otherPointer=seen[key]))
            else:seen[key]=pointer
            if not isinstance(field.get("name"),str) or not field.get("name","").strip():
                problems.append(_problem("parameter name:empty",path+".name","warning",groupPointer=gname,paramPointer=pointer))
            if not isinstance(field.get("description"),str) or not field.get("description","").strip():
                problems.append(_problem("parameter description:empty",path+".description","info",groupPointer=gname,paramPointer=pointer))
            kind=field.get("type")
            if kind not in _TYPES:
                problems.append(_problem("parameter type:invalid",path+".type","error",groupPointer=gname,paramPointer=pointer));continue
            problems.extend(_condition_problem(field.get("condition"),scope,"parameter condition:invalid expression",path+".condition",groupPointer=gname,paramPointer=pointer))
            problems.extend(_value_checks(field,scope,path,{'groupPointer':gname,'paramPointer':pointer}))
            if kind in ("real","integer"):
                for name in ("minimum","maximum"):
                    if name in field and field[name] is not None and (not _num(field[name]) or kind=='integer' and (int(field[name])!=field[name] or abs(field[name])>2**53-1)):
                        problems.append(_problem(f"parameter {name}:invalid",path+f".{name}","error",groupPointer=gname,paramPointer=pointer))
                if _num(field.get("minimum")) and _num(field.get("maximum")) and field["minimum"]>=field["maximum"]:
                    problems.append(_problem("parameter minimum maximum:range empty",path+".maximum","error",groupPointer=gname,paramPointer=pointer))
                if (field.get('minimum') is not None or field.get('maximum') is not None) and field.get("interval") not in _INTERVALS:
                    problems.append(_problem("parameter interval:empty",path+".interval","error",groupPointer=gname,paramPointer=pointer))
            if kind=="text":
                for name in ("pattern","patternErrorMessage"):
                    if name in field and field[name] is not None and not isinstance(field[name],str):
                        problems.append(_problem(f"parameter {name}:invalid",path+f".{name}","error",groupPointer=gname,paramPointer=pointer))
                for name in ("minLength","maxLength"):
                    if name in field and field[name] is not None and (not _num(field[name]) or field[name]<0 or int(field[name])!=field[name]):
                        problems.append(_problem(f"parameter {name}:invalid",path+f".{name}","error",groupPointer=gname,paramPointer=pointer))
            if kind in ("choice","multiSelect","logical"):
                choices=field.get("choices")
                if callable(choices):raise NotImplementedError("Callback parameter choices are unsupported")
                if _expression(choices):choices=_evaluate(scope,choices)
                if choices is None:
                    if kind!="logical":problems.append(_problem("parameter choices:empty",path+".choices","warning",groupPointer=gname,paramPointer=pointer))
                elif not isinstance(choices,list) or not choices:
                    problems.append(_problem("parameter choices:empty",path+".choices","warning",groupPointer=gname,paramPointer=pointer))
                else:
                    keys=[]
                    for ci,choice in enumerate(choices):
                        if not isinstance(choice,dict):
                            raise NotImplementedError('Invalid primitive choice definition aborts the official stage')
                        raw=choice.get('key');ckey=_string(ci if raw is None or raw=='' else raw)
                        if ckey in keys:
                            problems.append(_problem("parameter choices:key:duplicate",path+f".choices.{ci}.key","error",groupPointer=gname,paramPointer=pointer,choicePointer=ci,otherPointer=ckey));continue
                        keys.append(ckey)
                        if not isinstance(choice.get("name"),str) or not choice.get("name","").strip():problems.append(_problem("parameter choices:name:empty",path+f".choices.{ci}.name","warning",groupPointer=gname,paramPointer=pointer,choicePointer=ckey))
                        if not isinstance(choice.get("description"),str) or not choice.get("description","").strip():problems.append(_problem("parameter choices:description:empty",path+f".choices.{ci}.description","info",groupPointer=gname,paramPointer=pointer,choicePointer=ckey))
                        problems.extend(_condition_problem(choice.get("condition"),scope,"parameter choices:condition:invalid expression",path+f".choices.{ci}.condition","warning",groupPointer=gname,paramPointer=pointer,choicePointer=ckey))
                    if kind=="logical" and len(choices)!=2:problems.append(_problem("parameter choices:length mismatch",path+".choices","error",groupPointer=gname,paramPointer=pointer,expectedSize=2))
            for ci,constraint in enumerate(field.get('constraints') or []):
                if not constraint:continue
                if not isinstance(constraint,dict):raise TypeError('constraint must be an object')
                if callable(constraint.get('condition')):raise NotImplementedError('Callback parameter constraints are unsupported')
                extra={'groupPointer':gname,'paramPointer':pointer,'constraintPointer':ci}
                if not isinstance(constraint.get('message'),str) or not constraint['message'].strip():
                    problems.append(_problem('parameter constraints:message:empty',path+f'.constraints.{ci}.name','warning',**extra))
                problems.extend(_condition_problem(constraint.get('condition'),scope,'parameter constraints:condition:invalid expression',
                    path+f'.constraints.{ci}.condition',**extra))
    return problems
