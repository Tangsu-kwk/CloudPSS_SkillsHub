"""Memory-only implementations of parameter-definition MCP operations.

These functions edit the caller-owned SDK Model. They never fetch, save or run
the project. The accepted defaults and validation follow the published
MiraScript helpers used by the corresponding MCP tools.
"""
from copy import deepcopy
import math
import numbers
import json
from importlib.resources import files

_OMITTED = object()
_TYPES = {"real", "integer", "text", "code", "logical", "choice",
          "multiSelect", "table", "file"}
_INTERVALS = {"open", "left-open", "right-open", "closed"}
_PREFERENCES = {"embed", "link", "storage"}


def _groups(model):
    parameters = getattr(model.revision, "parameters", None)
    if parameters is None:
        raise ValueError("panic: No parameters found in current document")
    if not isinstance(parameters, list):
        raise TypeError("revision.parameters must be a list")
    return parameters


def _number(value, name):
    if isinstance(value, bool) or not isinstance(value, numbers.Real) or not math.isfinite(value):
        raise TypeError(f"{name} must be a finite number")
    return value


def _index(value, length, name):
    if isinstance(value, bool) or not isinstance(value, numbers.Real) or not math.isfinite(value):
        raise TypeError(f"{name} must be a finite number")
    index = math.trunc(value)
    if index < 0 or index >= length:
        raise IndexError(f"panic: Parameter group index {index} out of range")
    return index


def _group_ref(model, group):
    groups = _groups(model)
    if group is None:
        raise ValueError("panic: Parameter group is required")
    if isinstance(group, bool):
        raise TypeError("Parameter group must be a number or string")
    if isinstance(group, numbers.Real):
        index = _index(group, len(groups), "group")
        return index, groups[index]
    if isinstance(group, str):
        for index, item in enumerate(groups):
            if item.get("name") == group:
                return index, item
        raise ValueError(f"panic: Parameter group {group} not found")
    raise TypeError("Parameter group must be a number or string")


def _valid_key(key):
    return isinstance(key, str) and bool(key) and ("a" + key if key.startswith("_") else key).isidentifier()


def _default_value(kind, options):
    if kind in ("real", "integer"):
        return 0
    if kind in ("text", "code", "file"):
        return ""
    if kind == "logical":
        return False
    if kind == "choice":
        choices = options.get("choices")
        return deepcopy(choices[0].get("key")) if isinstance(choices, list) and choices else None
    if kind in ("multiSelect", "table"):
        return []
    raise ValueError(f"Unsupported parameter type {kind}")


def _expression(value):
    return (isinstance(value, dict)
            and isinstance(value.get("source"), str) and value.get("ɵexp") == "")


def _validate_parameter(parameter):
    key, name, description, kind = (parameter.get(k) for k in ("key", "name", "description", "type"))
    if not _valid_key(key):
        raise ValueError(f"panic: Invalid parameter key {key}")
    if not all(isinstance(value, str) for value in (name, description)):
        raise ValueError("panic: Parameter name and description must be strings")
    if not isinstance(kind, str) or kind not in _TYPES:
        raise ValueError(f"panic: Unsupported parameter type {kind}")
    if "condition" in parameter and parameter["condition"] is not None and not isinstance(parameter["condition"], str):
        raise ValueError("panic: Parameter condition must be a string")
    value = parameter.get("value")
    if not _expression(value):
        if kind in ("real", "integer"):
            if isinstance(value, bool) or not isinstance(value, numbers.Real) or not math.isfinite(value):
                raise ValueError("panic: Numeric parameter value must be a number of the specified type")
            if kind == "integer" and int(value) != value:
                raise ValueError("panic: Numeric parameter value must be a number of the specified type")
        elif kind in ("text", "code", "file") and not isinstance(value, str):
            raise ValueError("panic: Parameter value must be a string")
        elif kind == "logical" and not isinstance(value, bool):
            raise ValueError("panic: Logical parameter value must be a boolean")
        elif kind in ("multiSelect", "table") and not isinstance(value, list):
            raise ValueError("panic: Parameter value must be an array")
    if kind in ("real", "integer"):
        for field in ("minimum", "maximum"):
            if field in parameter and parameter[field] is not None:
                if not _is_number(parameter[field]):
                    raise ValueError(f"panic: {field} must be a number")
        if parameter.get("minimum") is not None and parameter.get("maximum") is not None and parameter["minimum"] > parameter["maximum"]:
            raise ValueError("panic: minimum must not exceed maximum")
        if parameter.get("interval") is not None and parameter["interval"] not in _INTERVALS:
            raise ValueError("panic: Invalid interval")
        if parameter.get("unit") is not None and not isinstance(parameter["unit"], str):
            raise ValueError("panic: unit must be a string")
    if kind == "text":
        for field in ("pattern", "patternErrorMessage"):
            if field in parameter and parameter[field] is not None and not isinstance(parameter[field], str):
                raise ValueError(f"panic: {field} must be a string")
        for field in ("minLength", "maxLength"):
            if field in parameter and parameter[field] is not None:
                value = parameter[field]
                if not _is_number(value) or value < 0 or value % 1:
                    raise ValueError(f"panic: {field} must be a non-negative integer")
        if parameter.get("minLength") is not None and parameter.get("maxLength") is not None and parameter["minLength"] > parameter["maxLength"]:
            raise ValueError("panic: minLength must not exceed maxLength")
    if kind == "code" and parameter.get("language") is not None and not isinstance(parameter["language"], str):
        raise ValueError("panic: language must be a string")
    if kind in ("choice", "multiSelect"):
        choices = parameter.get("choices")
        dynamic = _expression(choices)
        if not dynamic and (not isinstance(choices, list) or not choices):
            raise ValueError("panic: choices must be a non-empty array or an expression")
        if not dynamic:
            for choice in choices:
                if not isinstance(choice, dict) or not _choice_key(choice.get("key")):
                    raise ValueError("panic: Each choice needs a string, number or boolean key")
        if not _expression(parameter.get("value")):
            value = parameter.get("value")
            if kind == "choice" and value is not None:
                if not _choice_key(value):
                    raise ValueError("panic: Choice value must be a choice key")
                if not dynamic and not any(_same_key(c["key"], value) for c in choices):
                    raise ValueError("panic: Choice value must match a choice key")
            if kind == "multiSelect":
                for selected in value:
                    if not _choice_key(selected):
                        raise ValueError("panic: Selected values must be choice keys")
                    if not dynamic and not any(_same_key(c["key"], selected) for c in choices):
                        raise ValueError("panic: Selected value must match a choice key")
    if kind == "table":
        if not isinstance(parameter.get("columns"), list) or not parameter["columns"]:
            raise ValueError("panic: Table columns and record items must be non-empty arrays")
        for field in ("minRowCount", "maxRowCount"):
            value = parameter.get(field)
            if value is not None and (not _is_number(value) or value < 0 or value % 1):
                raise ValueError(f"panic: {field} must be a non-negative integer")
        if parameter.get("minRowCount") is not None and parameter.get("maxRowCount") is not None and parameter["minRowCount"] > parameter["maxRowCount"]:
            raise ValueError("panic: minRowCount must not exceed maxRowCount")
        if parameter.get("trackTag") is not None and not isinstance(parameter["trackTag"], str):
            raise ValueError("panic: trackTag must be a string")
    if kind == "file":
        accept = parameter.get("accept")
        if accept is not None and not isinstance(accept, (str, list)):
            raise ValueError("panic: accept must be a string or an array of strings")
        if isinstance(accept, list) and any(not isinstance(a, str) for a in accept):
            raise ValueError("panic: accept entries must be strings")
    if kind == "file" and parameter.get("preference") is not None and parameter["preference"] not in _PREFERENCES:
        raise ValueError("panic: Invalid file preference")
    return parameter


def _is_number(value):
    return not isinstance(value, bool) and isinstance(value, numbers.Real) and math.isfinite(value)


def _choice_key(value):
    return isinstance(value, (str, bool)) or _is_number(value)


def _same_key(a, b):
    return (isinstance(a, bool) == isinstance(b, bool)) and a == b


def add_parameter_group(model, name, description=None, position=None):
    if not isinstance(name, str):
        raise TypeError("name must be a string")
    groups = _groups(model)
    if description is not None and not isinstance(description, str):
        raise TypeError("description must be a string")
    if position is None:
        index = len(groups)
    else:
        _number(position, "position")
        index = math.trunc(position)
        if index < 0 or index > len(groups):
            raise IndexError("panic: position out of range")
    groups.insert(index, {"name": name, "description": description or "", "items": []})
    return index


def update_parameter_group(model, group, name=None, description=None, condition=None):
    index, original = _group_ref(model, group)
    for field, value in (("name", name), ("description", description), ("condition", condition)):
        if value is not None and not isinstance(value, str):
            raise TypeError(f"{field} must be a string")
    updated = deepcopy(original)
    for field, value in (("name", name), ("description", description), ("condition", condition)):
        if value is not None:
            updated[field] = value
    model.revision.parameters[index] = updated
    return None


def delete_parameter_group(model, group):
    index, _ = _group_ref(model, group)
    del model.revision.parameters[index]
    return index


def add_parameter(model, group, key, position=None, type=None, options=None):
    index, parameter_group = _group_ref(model, group)
    if not _valid_key(key):
        raise ValueError(f"panic: Invalid parameter key {key}")
    groups = _groups(model)
    if any(item.get("key") == key for current in groups for item in current.get("items", [])):
        raise ValueError(f"panic: Parameter key {key} already exists")
    if position is None:
        item_index = len(parameter_group.get("items", []))
    else:
        _number(position, "position")
        item_index = math.trunc(position)
        if item_index < 0 or item_index > len(parameter_group.get("items", [])):
            raise IndexError("panic: position out of range")
    kind = "real" if type is None else type
    if kind not in _TYPES:
        raise ValueError(f"panic: Unsupported parameter type {kind}")
    if options is None:
        options = {}
    if not isinstance(options, dict):
        raise TypeError("Parameter options must be a record")
    parameter = deepcopy(options)
    parameter.update(key=key, name=parameter.get("name", key),
                    description=parameter.get("description", ""), type=kind)
    if parameter.get("value") is None:
        parameter["value"] = _default_value(kind, parameter)
    _validate_parameter(parameter)
    parameter_group.setdefault("items", []).insert(item_index, parameter)
    return item_index


def _parameter_ref(model, param):
    if isinstance(param, str):
        for gi, group in enumerate(_groups(model)):
            for pi, item in enumerate(group["items"]):
                if item["key"] == param:
                    return gi, pi, item
        raise ValueError(f"panic: Parameter {param} not found")
    if not isinstance(param, dict) or set(param) != {"0", "1"}:
        raise TypeError('param must be a key or {"0": group, "1": index}')
    _number(param["0"], "group index")
    gi, group = _group_ref(model, param["0"])
    pi = math.trunc(_number(param["1"], "parameter index"))
    if pi < 0 or pi >= len(group["items"]):
        raise IndexError(f"panic: Parameter item index {pi} out of range")
    return gi, pi, group["items"][pi]


def update_parameter(model, param, options):
    """Merge definition fields atomically; value=None restores its type default.

    Renaming a definition does not rewrite expressions or existing config args.
    A parameter's type cannot be changed by this operation.
    """
    gi, pi, original = _parameter_ref(model, param)
    if not isinstance(options, dict):
        raise TypeError("Parameter updates must be a record")
    for key in ("key", "name", "description", "condition"):
        if key in options and not isinstance(options[key], str):
            raise TypeError(f"{key} must be a string")
    if options.get("key") is not None and options["key"] != original["key"]:
        key = options["key"]
        if not _valid_key(key):
            raise ValueError(f"panic: Invalid parameter key {key}")
        if any(p["key"] == key for g in _groups(model) for p in g["items"]):
            raise ValueError(f"panic: Parameter key {key} already exists")
    if options.get("type") is not None:
        raise ValueError("panic: Parameter type cannot be updated; use delete_parameter and add_parameter to change type")
    updated = {**deepcopy(original), **deepcopy(options)}
    if updated.get("value") is None:
        updated["value"] = _default_value(updated.get("type"), updated)
    _validate_parameter(updated)
    _groups(model)[gi]["items"][pi] = updated


def delete_parameter(model, param):
    """Delete the definition and return {"0": group index, "1": item index}.

    Existing config args are preserved, including values under the deleted key.
    """
    gi, pi, _ = _parameter_ref(model, param)
    del _groups(model)[gi]["items"][pi]
    return {"0": gi, "1": pi}


def get_parameter_options(type):
    """Return detached type metadata; no Model or remote connection is needed."""
    if not isinstance(type, str):
        raise TypeError("type must be a string")
    if type in ("record", "grouped"):
        raise ValueError("panic: Record and grouped parameter types are not supported yet")
    if type not in _TYPES:
        raise ValueError(f"panic: Unknown parameter type {type}")
    # Read a fresh object so nested mutations by callers cannot leak.
    return json.loads(files(__package__).joinpath("parameter_options.json").read_text(encoding="utf-8"))[type]
