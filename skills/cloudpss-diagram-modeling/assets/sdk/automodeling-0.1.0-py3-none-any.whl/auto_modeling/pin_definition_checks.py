"""Validate the revision-level pin definitions used by run_check.

Rules are from SimStudio 5.0.39 worker 76437. This stage is pure memory and
does not load component models or alter the input document.
"""
from copy import deepcopy
import math
import re

from .diagram_connections import _DiagramScope, _evaluate
from .graphic_checks import _condition_result
from .job_inputs import _js_truth


def _identifier(value):
    if not isinstance(value, str) or not value.strip():
        return False
    value = value.strip()
    # Worker Uu is called with unicode=False for pin keys.
    return re.fullmatch(r"[_a-zA-Z][a-zA-Z0-9_]*", value) is not None


def _numeric_js(value):
    """Small Number(value) subset needed by checkDim."""
    if value is None:
        return 0.0
    if type(value) is bool:
        return 1.0 if value else 0.0
    if type(value) in (int, float):
        return float(value)
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return 0.0
        try:
            if re.fullmatch(r"0[xX][0-9a-fA-F]+|0[bB][01]+|0[oO][0-7]+", text):
                return float(int(text, 0))
            return float(text)
        except ValueError:
            return math.nan
    if isinstance(value, list):
        from mirascript import to_string
        return _numeric_js(",".join("" if item is None else to_string(item) for item in value))
    return math.nan


def _problem(message, path, level, **data):
    return {"message": message, "data": {"path": path, **data}, "level": level}


def check_pin_definitions(document):
    """Return official-style ``pinDefinitions`` problems.

    Expression dimensions and conditions use the local MiraScript VM. If an
    expression needs a browser-only value, the function raises instead of
    treating it as valid.
    """
    revision = document.get("revision", {})
    pins = revision.get("pins")
    if pins is None:
        return []
    if not isinstance(pins, list):
        raise TypeError("revision.pins must be a list")
    global_values = {}
    for group in revision.get("parameters", []) or []:
        for field in group.get("items", []) or []:
            key = field.get("key")
            if isinstance(key, str) and key.strip() and key.strip() not in global_values:
                global_values[key.strip()] = deepcopy(field.get("value"))
    # Pin conditions and dimensions resolve revision parameter keys directly.
    scope = _DiagramScope(dict(global_values), {"definition": document.get("rid"), "args": global_values}, document, global_values)
    problems, seen = [], {}
    for index, pin in enumerate(pins):
        if not isinstance(pin, dict):
            raise TypeError("pin definition must be an object")
        pointer = pin.get("name") or pin.get("key") or f"[{index + 1}]"
        base = f"revision.pins.{index}"
        key = pin.get("key")
        normalized = key.strip() if isinstance(key, str) else None
        if not _identifier(key):
            # Official helper treats a numeric string as deprecated but valid.
            from mirascript import to_string
            numeric = isinstance(key, str) and to_string(_numeric_js(key)) == key
            if numeric:
                problems.append(_problem("pin key:deprecated numeric", base + ".key", "warning", pinPointer=pointer))
                normalized = key.strip()
            else:
                code = "pin key:empty" if not normalized else "pin key:invalid"
                problems.append(_problem(code, base + ".key", "error", pinPointer=pointer))
                normalized = None
        if normalized is not None and normalized in seen:
            problems.append(_problem("pin key:duplicate", base + ".key", "error", pinPointer=pointer,
                                     otherPointer=seen[normalized]))
        elif normalized is not None:
            seen[normalized] = pointer
        name = pin.get("name")
        if not isinstance(name, str) or not name.strip():
            problems.append(_problem("pin name:empty", base + ".name", "warning", pinPointer=pointer))
        description = pin.get("description")
        if not isinstance(description, str) or not description.strip():
            problems.append(_problem("pin description:empty", base + ".description", "info", pinPointer=pointer))
        condition = pin.get("condition")
        if callable(condition):
            raise NotImplementedError("Callback pin conditions are unsupported")
        valid, error = _condition_result(scope, condition)
        if not valid:
            problems.append(_problem("pin condition:invalid", base + ".condition", "warning",
                                     pinPointer=pointer, error=error))
        dimensions = pin.get("dim")
        if isinstance(dimensions, list):
            for dim_index, raw in enumerate(dimensions[:2]):
                if not _js_truth(raw):
                    continue
                numeric = _numeric_js(raw)
                if not math.isnan(numeric):
                    if not math.isfinite(numeric) or not numeric.is_integer() or numeric < 0 or abs(numeric) > 2**53 - 1:
                        problems.append(_problem("dim:invalid range", f"{base}.dim.{dim_index}", "error",
                                                 pinPointer=pointer, dimIndex=dim_index))
                    continue
                try:
                    if not isinstance(raw, str):
                        raise NotImplementedError("Non-string expression pin dimensions are unsupported")
                    value = _evaluate(scope, {"source": raw, "ɵexp": "f"})
                    converted = _numeric_js(value)
                except NotImplementedError:
                    raise
                except Exception as exc:
                    problems.append(_problem("dim:invalid exp", f"{base}.dim.{dim_index}", "error",
                                             pinPointer=pointer, dimIndex=dim_index, error=str(exc)))
                    continue
                if not math.isfinite(converted) or not converted.is_integer() or converted < 0 or abs(converted) > 2**53 - 1:
                    problems.append(_problem("dim:invalid range", f"{base}.dim.{dim_index}", "warning",
                                             pinPointer=pointer, dimIndex=dim_index))
    return problems
