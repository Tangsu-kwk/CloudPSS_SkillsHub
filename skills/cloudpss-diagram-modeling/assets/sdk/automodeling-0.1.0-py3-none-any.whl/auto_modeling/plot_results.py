"""Plot message merging from official 92684/62490 (sampling disabled).

JSON trace arrays and object-valued properties follow PlotMerger's chunk rules;
binary typed arrays must be decoded before calling. Rendering uses an isolated
local Kaleido image engine and returns Plotly's actual mutated layout. It never
attaches to the user's browser. An explicit renderer(figure) remains a test hook.
Pixel parity across environments is not guaranteed. Empty plots return [].
"""
import base64
from copy import deepcopy
import json
import re


def _render_response(figure):
    """Run Plotly.toImage and retain its actual input-layout mutations.

    Kaleido supplies an isolated local image engine, never the user's browser
    or CloudPSS page. Its regular Python image API discards these mutations.
    Use its public browser transport to return both products of the same render.
    """
    import asyncio
    from concurrent.futures import ThreadPoolExecutor
    try:
        import kaleido
    except ImportError as exc:
        raise NotImplementedError('Plot rendering requires Plotly and Kaleido') from exc

    async def render():
        async with kaleido.Kaleido(n=1, mathjax=False) as engine:
            tab = next(iter(engine.tabs.values()))
            # Set the object separately so the function is fixed code. JSON
            # serialization also rejects nonfinite input instead of JS tokens.
            assigned = await tab.send_command('Runtime.evaluate', {
                'expression': 'globalThis.__sdkFigure=' + json.dumps(figure, ensure_ascii=True, allow_nan=False),
            })
            if assigned.get('result', {}).get('exceptionDetails'):
                raise ValueError('Plot figure could not be loaded by the image engine')
            reply = await tab.send_command('Runtime.evaluate', {
                'expression': '''(async()=>{
                    const figure=globalThis.__sdkFigure;
                    try {
                        const url=await Plotly.toImage(figure,{format:'webp',width:1600,height:900,scale:1});
                        return {image:url.split(',')[1],layout:figure.layout};
                    } finally {delete globalThis.__sdkFigure;}
                })()''',
                'awaitPromise': True, 'returnByValue': True,
            })
            result = reply.get('result', {})
            if result.get('exceptionDetails'):
                details = result['exceptionDetails']
                raise ValueError('Plotly rendering failed: ' +
                                 details.get('exception', {}).get('description', details.get('text', 'unknown error')))
            value = result.get('result', {}).get('value')
            if not isinstance(value, dict) or not isinstance(value.get('layout'), dict):
                raise ValueError('Image engine returned no rendered layout')
            return base64.b64decode(value['image'], validate=True), value['layout']

    # A synchronous SDK method can also be used from a running event loop.
    with ThreadPoolExecutor(max_workers=1) as executor:
        return executor.submit(lambda: asyncio.run(asyncio.wait_for(render(), timeout=90))).result()

TEMPLATE = {"layout": {"margin": {"l":80,"b":50,"r":30,"t":50},
    "legend":{"x":1,"y":1,"xanchor":"auto","yanchor":"auto"},
    "showlegend":True,"hovermode":"x"}}


def _set(target, path, value):
    parts = re.findall(r'[^.\[\]]+', path)
    if not parts or any(p in ('__proto__','constructor','prototype') for p in parts):
        raise NotImplementedError("Unsupported plot property path")
    current = target
    for index, part in enumerate(parts[:-1]):
        key = int(part) if isinstance(current, list) else part
        if isinstance(current, list):
            while len(current) <= key: current.append(None)
            item = current[key]
        else: item = current.get(key)
        if not isinstance(item, (list, dict)):
            item = [] if parts[index+1].isdigit() else {}
            current[key] = item
        current = item
    key = int(parts[-1]) if isinstance(current, list) else parts[-1]
    if isinstance(current, list):
        while len(current) <= key: current.append(None)
    current[key] = deepcopy(value)


def _combine(old, new, verb):
    if not isinstance(old, list) or not isinstance(new, list): return deepcopy(new)
    if verb.endswith('_rotate'):
        append = verb.startswith('append')
        if len(old) <= len(new): return deepcopy(new[-len(old):] if append and old else new[:len(old)])
        return deepcopy(old[len(new):]+new if append else new+old[:len(old)-len(new)])
    return deepcopy(new+old if verb == 'prepend' else old+new if verb == 'append' else new)


def _merged_messages(messages):
    start = 0
    for i, message in enumerate(messages):
        if message.get('verb') in (None, '', 'replace', 'create'): start = i
    group, verb = [], None
    def merge(batch, action):
        data, traces = {}, []
        for message in batch:
            raw = message['data']
            if raw.get('title'): data['title'] = raw['title']
            for name in ('xAxis','yAxis','layout'):
                if raw.get(name) is not None: data.setdefault(name, {}).update(deepcopy(raw[name]))
            for index, trace in enumerate(raw.get('traces') or []):
                while len(traces) <= index: traces.append(None)
                if trace is None: continue
                if traces[index] is None: traces[index] = {}
                for key, value in trace.items():
                    if isinstance(value, (list, dict)):
                        # prepareTraces wraps every JS object (including arrays)
                        # in chunks. createTrace later flattens exactly one level;
                        # an object property therefore becomes [object], even on
                        # replace/update. It is not a recursive dictionary merge.
                        old = traces[index].get(key)
                        chunk = deepcopy(value)
                        if not isinstance(old, list):
                            traces[index][key] = [chunk]
                        elif action.startswith('prepend'):
                            old.insert(0, chunk)
                        elif action.startswith('append'):
                            old.append(chunk)
                        else:
                            traces[index][key] = [chunk]
                    else: traces[index][key] = deepcopy(value)
        for trace in traces:
            if trace is None: continue
            for key, chunks in list(trace.items()):
                if not isinstance(chunks, list): continue
                flattened = []
                for chunk in chunks:
                    flattened.extend(chunk if isinstance(chunk, list) else [chunk])
                trace[key] = flattened
        data['traces'] = traces
        return {'verb':action, 'data':data}
    for message in messages[start:]:
        action = message.get('verb') or 'replace'
        if verb is not None and verb != action:
            yield merge(group, verb)
            group = []
        verb = action
        group.append(message)
    if group: yield merge(group, verb)


def _layout(message, target):
    data = message['data']
    for key, value in (data.get('layout') or {}).items(): _set(target, key, value)
    for key, name in [('xaxis','xAxis'),('yaxis','yAxis')]:
        axis = data.get(name)
        if not axis: continue
        dest = target.setdefault(key, {})
        for field, value in axis.items():
            if field == 'title' and value:
                if isinstance(value, str):
                    if not isinstance(dest.get('title'), dict): dest['title'] = {}
                    dest['title']['text'] = value
                else: dest['title'] = deepcopy(value)
            elif field == 'range':
                if value == 'auto': dest['autorange'] = True
                elif isinstance(value, list): dest.update(range=deepcopy(value), autorange=False)
            elif field != 'type' or value: _set(dest, field, value)
    if data.get('title'): target.setdefault('title', {})['text'] = data['title']


def plot_figure(messages):
    """Pure figure construction, independently testable against official JS."""
    figure = {'data':[], 'layout':{'template':deepcopy(TEMPLATE)}, 'config':{}}
    for message in _merged_messages(messages):
        verb, raw = message['verb'], message['data']['traces']
        replace = verb in ('replace','create') or not figure['data']
        if replace:
            figure['layout'] = {}
            figure['data'] = []
        _layout(message, figure['layout'])
        count = len(raw) if replace else max(len(raw), len(figure['data']))
        for i in range(count):
            old = figure['data'][i] if i < len(figure['data']) else None
            new = raw[i] if i < len(raw) else None
            if replace and new is None:
                figure['data'].append(None)
                continue
            if old is None or replace:
                trace = {}
                for key, value in (new or {}).items():
                    if value is not None: _set(trace, key, value)
            elif new is None: trace = old
            else:
                trace = old
                for key, value in new.items():
                    previous = trace
                    for part in key.split('.'):
                        previous = previous.get(part) if isinstance(previous, dict) else None
                    _set(trace, key, value if verb=='update' else _combine(previous,value,verb))
            if i < len(figure['data']): figure['data'][i] = trace
            else: figure['data'].append(trace)
    return figure


def _render(figure):
    try:
        import plotly.io as pio
    except ImportError as exc:
        raise NotImplementedError("WebP rendering requires Plotly, or renderer=") from exc
    # MCP hands its figure directly to Plotly.js.toImage. Python's graph-object
    # validation rejects some figures the official merger produces (e.g. line
    # object chunks). Preserve that raw figure, including JS defaults/coercion,
    # and isolate it because the rendering backend may mutate its argument.
    # Do not misreport data/backend errors as missing optional dependencies.
    return pio.to_image(deepcopy(figure), format='webp', width=1600, height=900,
                        scale=1, validate=False)


def plot_response(messages, plot_layout=None, *, renderer=None):
    grouped = {}
    for message in messages:
        if message.get('sender') == 'local': continue
        key = message['key']
        if plot_layout is not None and key not in plot_layout: continue
        grouped.setdefault(key, []).append(deepcopy(message))
    if not grouped: return []
    summaries, images = [], []
    for key, batch in grouped.items():
        override = (plot_layout or {}).get(key)
        if override is not None:
            if not isinstance(override, dict): raise TypeError("Plot layout must be an object")
            batch.append({'verb':'update', 'data':{'layout':override,'traces':[]}})
        figure = plot_figure(batch)
        # PlotComponent.layout's setter reinstates this template after each
        # replacement. Keep the pure PlotMerger oracle independent of it.
        figure['layout'].setdefault('template', deepcopy(TEMPLATE))
        # MCP exposes the text content as JSON as well as structuredContent;
        # preserve its stable template-first insertion order.
        layout = figure['layout']
        if list(layout) != ['template'] + [key for key in layout if key != 'template']:
            figure['layout'] = {'template': layout['template'],
                                **{key: value for key, value in layout.items()
                                   if key != 'template'}}
        if renderer is None:
            image, figure['layout'] = _render_response(deepcopy(figure))
        else:
            image = renderer(deepcopy(figure))
        if not isinstance(image, bytes) or not (image.startswith(b'RIFF') and image[8:12] == b'WEBP'):
            raise ValueError("Renderer must return WebP image bytes")
        images.append({'type':'image','mimeType':'image/webp','data':base64.b64encode(image).decode('ascii')})
        summaries.append({'key':key,'layout':figure['layout'],'data':[
            {k:v for k,v in trace.items() if not k.startswith('_') and v is not None
             and not isinstance(v,(list,dict))} for trace in figure['data']]})
    structured = {'result':summaries}
    return {'content':[{'type':'text','text':json.dumps(structured,ensure_ascii=False,separators=(',',':'))},*images],
            'structuredContent':structured}
