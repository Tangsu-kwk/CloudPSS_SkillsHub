"""Explicit staged project checking and an MCP-shaped adapter.

check_project_stages returns raw stage records and evaluated model, allowing
callers to use args/diagram diagnostics without mistaking them for full checks.
"""
from copy import deepcopy
from .component_checks import prepare_component_checks
from .diagram_connections import check_diagram_connections
from .parameter_definition_checks import check_parameter_definitions
from .pin_definition_checks import check_pin_definitions
from .graphic_checks import check_graphic
from .case_checks import prepare_case_checks
from .job_checks import check_job_system
from .check_messages import check_message


class IncompleteCheckError(RuntimeError):
    """The MCP-shaped result cannot represent missing checker inputs."""


def check_project_stages(model, *, definitions, functions=None, policies=None, runtime=None):
    """Run parameter then topology stages; no implicit network/save/job.

    Pending groups describe missing inputs. A model with no jobs does not need
    a scheduler snapshot, and a model with no jobs/functions does not need a
    function registry. The rich report's ``complete`` flag remains a
    conservative full-equivalence flag; the MCP adapter intentionally omits
    it. Exceptions preserve caller state and never become success.
    """
    original=deepcopy(model if isinstance(model,dict) else model.toJSON())
    definition_problems=check_parameter_definitions(original)
    pin_problems=check_pin_definitions(original)
    graphic_problems=check_graphic(original)
    cases=prepare_case_checks(original,functions=functions,runtime=runtime)
    prepared=prepare_component_checks(cases['document'],definitions=definitions)
    diagram=check_diagram_connections(prepared['document'],definitions=definitions)
    problems={'parameters':definition_problems,'pinDefinitions':pin_problems,'graphic':graphic_problems,
              'cases':cases['problems'],'args':prepared['problems'],'diagram':diagram}
    if policies is not None:
        problems['job']=check_job_system(prepared['document'],policies=policies)
    rank={'error':0,'warning':1,'info':2}
    for group in problems.values():group.sort(key=lambda problem:rank[problem['level']])
    checked=list(problems)
    if not cases['complete']:
        checked.remove('cases')
    jobs=original.get('jobs') or []
    pending=([] if cases['complete'] else ['cases'])
    if jobs and policies is None:
        pending.append('job')
    if not jobs and 'job' in problems:
        # The job stage is vacuously complete when there is no active queued
        # job. This is the normal blank-project MCP case.
        checked.remove('job')
    pending_details = list(cases['pending'])
    if jobs and policies is None:
        pending_details.append('queue policy snapshot')
    # The rich SDK report deliberately keeps ``complete`` conservative: it
    # means full browser/MCP equivalence, which is broader than the supplied
    # checker inputs. The wire adapter below does not expose this flag.
    return {'complete':False,'checked_groups':checked,
            'pending_groups':pending,
            'pending_details':pending_details,
            'limitations':['Browser expression diagnostics, dynamic definitions and MCP message translation are not fully equivalent'],
            'problems':deepcopy(problems),'document':prepared['document']}


def run_check(model, *, definitions, functions=None, policies=None, runtime=None, groups=None, levels=None):
    """Return rich local diagnostics with MCP-like group/level filtering.

    ``complete`` remains conservative about full browser equivalence. The helper
    never fetches, saves, submits or mutates the caller's model.
    """
    if groups is not None and (not isinstance(groups,list) or any(not isinstance(x,str) for x in groups)):
        raise TypeError('groups must be a list of strings or None')
    if levels is not None and (not isinstance(levels,list) or any(x not in ('error','warning','info') for x in levels)):
        raise TypeError('levels must contain error, warning or info')
    result=check_project_stages(model,definitions=definitions,functions=functions,policies=policies,runtime=runtime)
    selected=result['problems'] if groups is None else {key:value for key,value in result['problems'].items() if key in groups}
    output=[]
    for group,problems in selected.items():
        for problem in problems:
            if levels is None or problem['level'] in levels:
                output.append({'group':group,'code':problem['message'],'message':check_message(group,problem),'level':problem['level'],'data':problem['data']})
    return {'complete':result['complete'],'checked_groups':result['checked_groups'],'pending_groups':result['pending_groups'],'pending_details':result['pending_details'],'limitations':result['limitations'],'problems':output,'document':result['document']}


def run_check_mcp(model, *, definitions, functions=None, policies=None,
                  runtime=None, groups=None, levels=None):
    """Return the business payload of the CloudPSS ``run_check`` tool.

    The public MCP tool returns ``{"result": [...]}``; it does not expose the
    SDK's coverage metadata or normalized document.  Keeping this adapter
    separate prevents callers from accidentally treating internal diagnostics
    as the wire contract while retaining the richer :func:`run_check` API for
    local analysis.
    """
    result = run_check(model, definitions=definitions, functions=functions,
                       policies=policies, runtime=runtime, groups=groups,
                       levels=levels)
    selected_pending=[g for g in result['pending_groups']
                      if groups is None or g in groups]
    if selected_pending:
        raise IncompleteCheckError('Missing checker inputs for: '+', '.join(selected_pending))
    untranslated=[p['code'] for p in result['problems'] if p['message']==p['code']]
    if untranslated:
        raise IncompleteCheckError('Unverified MCP messages: '+', '.join(dict.fromkeys(untranslated)))
    return {'result': deepcopy(result['problems'])}
