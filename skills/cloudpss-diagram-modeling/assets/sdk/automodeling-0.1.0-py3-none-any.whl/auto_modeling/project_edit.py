"""Edit caller-owned SDK project metadata without fetching, saving or running."""

_OMITTED = object()


def update_metadata(model, name=_OMITTED, description=_OMITTED, documentation=_OMITTED):
    """Omission preserves values; empty strings work; null fails before writes.

    Documentation belongs to model.revision. Python input failures use native
    TypeError instead of reproducing MCP protocol validation envelopes.
    """
    values = {"name": name, "description": description, "documentation": documentation}
    for field, value in values.items():
        if value is not _OMITTED and not isinstance(value, str):
            raise TypeError(f"{field} must be a string; omit it to keep its value")
    # Resolve nested destination before changing any top-level fields.
    revision = model.revision if documentation is not _OMITTED else None
    if name is not _OMITTED:
        model.name = name
    if description is not _OMITTED:
        model.description = description
    if documentation is not _OMITTED:
        revision.documentation = documentation
    return None
