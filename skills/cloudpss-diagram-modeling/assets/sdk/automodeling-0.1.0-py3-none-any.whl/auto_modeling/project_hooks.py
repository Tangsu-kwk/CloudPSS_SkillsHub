"""Deterministic SimStudio 5.0.39 open/save hooks (22341/55166/66715/84555).

Operates on detached JSON. Custom graphics use the local packaged engine;
known legacy models use the archived migration chain and compiler.
"""
from copy import deepcopy
import math
import re

OFFICIAL = {'cloudpss','open-cloudpss','cloudpssiessimulation','ieslabplan','dslab','ieslabopt'}
ERROR_MARKER = {'name':'cross','args':{'offset':.5},
                'stroke':'var(--spectrum-semantic-negative-color-default)'}


def clean_diagram(document):
    diagram = document.get('revision',{}).get('implements',{}).get('diagram')
    if not isinstance(diagram,dict): return
    cells = diagram.setdefault('cells',{})
    if not isinstance(cells,dict): raise TypeError('diagram.cells must be an object')
    for key, cell in list(cells.items()):
        if cell is None or not isinstance(cell,dict) or cell.get('id') != key or not cell.get('shape'):
            del cells[key]
    for cell in cells.values():
        if not cell['shape'].endswith('-edge'): continue
        for side in ('source','target'):
            endpoint = cell.get(side)
            missing = endpoint is None or (isinstance(endpoint,dict)
                and isinstance(endpoint.get('cell'),str) and endpoint['cell'] not in cells)
            if missing:
                cell[side] = {'x':0,'y':0}
                cell.setdefault('attrs',{}).setdefault('line',{})[side+'Marker'] = deepcopy(ERROR_MARKER)


def open_document(document):
    """Default, migrate and clean a detached model before SDK construction."""
    from .project_migration import migrate_project_document
    result = deepcopy(document)
    for key,default in [('tags',[]),('keywords',[]),('storage',[]),
                         ('permissions',{'moderator':98367,'member':65551,'everyone':0})]:
        if result.get(key) is None:result[key]=deepcopy(default)
    result = migrate_project_document(result)
    revision = result.get('revision')
    if not isinstance(revision,dict): raise TypeError('Invalid revision')
    context = result.setdefault('context',{})
    if not isinstance(context,dict): raise TypeError('Invalid context')
    for key, default in [('tags',[]),('keywords',[]),('storage',[]),('configs',[]),('jobs',[]),
                         ('permissions',{'moderator':98367,'member':65551,'everyone':0})]:
        if result.get(key) is None: result[key] = deepcopy(default)
    for key in ('author','message','documentation'):
        if revision.get(key) is None: revision[key] = ''
    for key, value in [('parameters',[]),('pins',[]),('implements',{})]:
        if revision.get(key) is None: revision[key] = deepcopy(value)
    for key, value in [('category','normal'),('graphic',{}),('currentConfig',0),('currentJob',0),('diagram',{})]:
        if context.get(key) is None: context[key] = deepcopy(value)
    tags = result['tags']
    tag = next((t for t in tags if t.startswith('project-group:')),None)
    if tag is None: context.pop('tag',None)
    else: context['tag'] = tag.rsplit('/',1)[-1] if '/' in tag else tag[len('project-group:'):]
    category = next((t[len('project-category:'):] for t in tags if t.startswith('project-category:')),None)
    if category in ('simple','normal','component'): context['category'] = category
    jobs = []
    for job in result['jobs']:
        if not isinstance(job,dict) or not isinstance(job.get('rid'),str): continue
        rid = job['rid']
        for pattern,replacement in [(r'^job-definition/cloudpss/','function/CloudPSS/'),
                (r'^job-definition/ies/ies-','function/CloudPSS/ieslab-'),
                (r'^job-definition/ies/','function/CloudPSS/'),(r'^job-definition/','function/')]:
            rid = re.sub(pattern,replacement,rid,flags=re.I)
        if job.get('args') is None: job['args'] = {}
        if rid == 'function/CloudPSS/emtp':
            rid = 'function/CloudPSS/emtps'
            from .job_inputs import _js_truth
            if _js_truth(job['args'].get('initial_type')): job['args']['init_cfg'] = 1
        job['rid'] = rid
        jobs.append(job)
    result['jobs'] = jobs
    if (revision.get('graphic') or {}).get('generator') != 'x6': context['graphic'] = {}
    clean_diagram(result)
    return result


def _round(value, digits=0):
    scale = 10**digits
    return math.floor(value*scale+.5)/scale


def default_graphic(document):
    """Exact default rectangular builder from module 84555, including ports."""
    groups = [[],[],[]]
    for index,pin in enumerate(document['revision'].get('pins',[])):
        if pin.get('visible'):
            groups[0 if pin.get('connection')=='input' else 1 if pin.get('connection')=='output' else 2].append((f"{index}-{pin.get('key','undefined')}",pin))
    left,right,bottom = groups
    body_w = max((len(bottom)-1)*25+20,50)
    body_h = max((len(left)-1)*25+20,(len(right)-1)*25+20,50)
    padding_l,padding_r,padding_b = 20 if left else 0,20 if right else 0,20 if bottom else 0
    width,height = body_w+padding_l+padding_r,body_h+padding_b
    graphic = {'pins':{},'markup':[],'attrs':{},'width':width,'height':height,
               'preserveAspectRatio':True,'generator':'default'}
    def ports(pins,x,y,dx,dy,length):
        step = math.floor((length+30)/(len(pins)+1)/5)*5
        offset = step-15
        for identity,pin in pins:
            px,py = x+abs(dy)*offset,y+abs(dx)*offset
            selector = 'pin-line-'+identity
            graphic['markup'].append({'tagName':'path','selector':selector,'groupSelector':'pin-line'})
            graphic['attrs'][selector] = {'refPath':{'w':width,'h':height,
                'd':f'M{px} {py}l{dx*20} {dy*20}'}}
            if pin.get('key'):
                values = [(px+dx*20)/width,(py+dy*20)/height]
                normalized = [0 if v<=0 else .9999999 if v>=.9999999 else _round(v,6) for v in values]
                graphic['pins'][pin['key']] = {'position':dict(zip(('x','y'),normalized))}
            offset += step
    if left: ports(left,padding_l,0,-1,0,body_h)
    if right: ports(right,padding_l+body_w,0,1,0,body_h)
    if bottom: ports(bottom,padding_l,body_h,0,1,body_w)
    graphic['markup'].append({'tagName':'rect','selector':'body'})
    def ratio(a,b):
        value=a/b
        return int(value) if value.is_integer() else value
    graphic['attrs']['body'] = {'refWidth':ratio(body_w,width),'refHeight':ratio(body_h,height),'refX':ratio(padding_l,width),'refY':0}
    if any(groups): graphic['attrs']['pin-line'] = {'stroke':'var(--stroke)','strokeWidth':'calc(1px*var(--stroke-width))'}
    return graphic


def save_document(document, *, author, graphic_builder=None):
    """Return detached wire JSON; default/local x6 generation or explicit builder."""
    result = deepcopy(document)
    tags = result.setdefault('tags',[])
    owner = (result.get('rid') or ('model/'+author+'/unused')).split('/')[1]
    context = result.get('context') or {}
    if owner.lower() not in OFFICIAL:
        indexes = [i for i,t in enumerate(tags) if t.startswith('project-group:')]
        if indexes: tags.pop(indexes[-1])
        if context.get('tag'): tags.append('project-group:'+owner+'/'+str(context['tag']))
    indexes = [i for i,t in enumerate(tags) if t.startswith('project-category:')]
    if indexes: tags.pop(indexes[-1])
    category = context.get('category')
    tags.append('project-category:'+str('normal' if category is None else category))
    clean_diagram(result)
    revision = result['revision']
    graphic = revision.get('graphic') or {}
    generator,name = graphic.get('generator'),graphic.get('name')
    generated = (generator in ('default','x6') or (isinstance(generator,str) and generator.startswith('__GENERATED_DEFAULT__'))
        or (generator is not None and not isinstance(generator,str))
        or (generator is None and isinstance(name,str) and name.startswith('__GENERATED_DEFAULT__')))
    needs = not graphic or not isinstance(graphic.get('markup'),list) or not graphic['markup'] or graphic.get('width') is None or graphic.get('height') is None or generated
    if needs:
        if graphic_builder is not None:
            revision['graphic'] = deepcopy(graphic_builder(deepcopy(result)))
        else:
            from .custom_graphic import custom_graphic
            revision['graphic'] = custom_graphic(result)
        if 'edge' in graphic: revision['graphic']['edge'] = deepcopy(graphic['edge'])
    # pages is UI-only and absent from the official model wire fields.
    result.pop('pages',None)
    return result
