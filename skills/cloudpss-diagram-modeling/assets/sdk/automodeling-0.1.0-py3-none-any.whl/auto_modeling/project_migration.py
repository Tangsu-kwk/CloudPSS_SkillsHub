"""Detached model migration through archived official local translator/compiler."""
from copy import deepcopy
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET


class ProjectMigrationError(ValueError):
    """Migration failed without changing caller data or session state."""


def _xml_document(source):
    # Reject declarations that ElementTree could expand; browser DOMParser does
    # not load external entities. Plain predefined/numeric XML entities work.
    if '<!DOCTYPE' in source.upper() or '<!ENTITY' in source.upper():
        raise ProjectMigrationError('Legacy graphic XML declarations are unsupported')
    try:
        root=ET.fromstring(source)
    except ET.ParseError:
        return None  # Official XML graphic conversion discards malformed XML.
    def node(element):
        return {'tag':element.tag,'attrs':dict(element.attrib),
                'children':[node(child) for child in element]}
    return node(root)


def migrate_project_document(document):
    """Return normalized/migrated detached document for known versions 1..5.

    Missing revision version follows official version 1; missing context version
    follows 4. Future/nonintegral versions are refused as a local compatibility
    policy, never silently downgraded. Version5 normalization needs no Node.
    """
    if not isinstance(document,dict) or not isinstance(document.get('revision'),dict):
        raise TypeError('Invalid model revision object')
    result=deepcopy(document)
    revision=result['revision']
    context=result.get('context')
    if context is None:context=result['context']={'version':4}
    if not isinstance(context,dict):raise TypeError('Invalid model context object')
    version=revision.get('version',1)
    if version is None:version=1
    context_version=context.get('version',4)
    if context_version is None:context_version=4
    for label,value in [('revision',version),('context',context_version)]:
        if type(value) not in (int,float) or not math.isfinite(value) or int(value)!=value or not 1<=value<=5:
            raise ProjectMigrationError(f'Unsupported {label} version: {value!r}')
    revision['version']=version;context['version']=context_version
    for key,default in [('name',''),('description',''),('tags',[]),('keywords',[]),
                         ('permissions',{'moderator':0,'member':0,'everyone':0}),('configs',[]),('jobs',[])]:
        if result.get(key) is None:result[key]=deepcopy(default)
    for key,default in [('author',''),('message',''),('documentation',''),('parameters',[]),
                         ('pins',[]),('implements',{}),('graphic',{'pins':{},'markup':[],
                          'attrs':{},'width':0,'height':0,'preserveAspectRatio':True})]:
        if revision.get(key) is None:revision[key]=deepcopy(default)
    if min(version,context_version)>=5:return result
    executable=os.environ.get('AUTOMODELING_NODE') or shutil.which('node')
    if not executable:raise ProjectMigrationError('Legacy projects require local Node.js >=18 (or AUTOMODELING_NODE)')
    xml={}
    graphic=revision.get('graphic')
    if isinstance(graphic,str):xml[graphic]=_xml_document(graphic)
    payload=json.dumps({'document':result,'xml':xml},ensure_ascii=False,allow_nan=False)
    try:
        process=subprocess.run([executable,str(Path(__file__).with_name('project_migration_runtime.cjs'))],
            input=payload,capture_output=True,text=True,encoding='utf8',timeout=45,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),check=False)
    except (OSError,subprocess.TimeoutExpired) as exc:
        raise ProjectMigrationError('Local project migration runtime unavailable') from exc
    try:
        response=json.loads(process.stdout)
    except (ValueError,TypeError) as exc:
        raise ProjectMigrationError('Invalid local project migration response') from exc
    if process.returncode or 'error' in response:
        error=response.get('error',{})
        raise ProjectMigrationError('Official project migration failed: '+str(error.get('message','runtime error')))
    migrated=response.get('document')
    if not isinstance(migrated,dict) or migrated.get('revision',{}).get('version')!=5 or migrated.get('context',{}).get('version')!=5:
        raise ProjectMigrationError('Project migration did not produce version5')
    return migrated
