"""Explicit model persistence through official GraphQL; never retries mutations.

Source: SimStudio 5.0.39 FileService/SaveDialog/API modules 32332/21321/69470.
Deterministic pre-save hooks include default graphic generation, tags, invalid
cell cleanup and storage references. Custom x6 drawings use the packaged local
Node.js engine; callers can supply an explicit graphic_builder instead.
"""
from copy import deepcopy
import re

from .project_session import ProjectError, _rid, _PRIVATE
from .remote_reads import _request, _current_user_name

EXISTS_QUERY = 'query($rid:ResourceId!){resource(input:{rid:$rid}){rid}}'
REVISION_MUTATION = '''mutation($input:CreateModelRevisionInput!){
  revision:createModelRevision(input:$input){hash}
}'''


def project_exists(rid, *, requester=None):
    """Only the exact resource-lookup 406 observed on this deployment means absent."""
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    try:
        response = requester(EXISTS_QUERY, {"rid": _rid(rid)}, timeout=30)
    except Exception:
        raise ProjectError("Resource lookup failed") from None
    errors = response.get('errors') if isinstance(response, dict) else None
    if errors:
        absent = all(isinstance(e,dict) and e.get('path') == ['resource']
            and e.get('message') == '未查询到resource'
            and e.get('extensions',{}).get('status') == 406
            and e.get('extensions',{}).get('serviceName') == 'account' for e in errors)
        if absent and response.get('data') is None: return False
        raise ProjectError("Resource lookup returned errors")
    data = response.get('data') if isinstance(response,dict) else None
    if not isinstance(data,dict) or 'resource' not in data:
        raise ProjectError("Invalid resource existence response")
    item = data['resource']
    if item is None: return False
    if not isinstance(item,dict) or item.get('rid') != rid:
        raise ProjectError("Invalid resource existence response")
    return True


class ProjectSaveError(ProjectError):
    """A failed save may leave a revision, or have an unknown mutation outcome."""
    def __init__(self, message, *, revision_hash=None, outcome_unknown=False):
        super().__init__(message)
        self.revision_hash = revision_hash
        self.outcome_unknown = outcome_unknown


def _storage(document):
    found = []
    pattern = re.compile(r'/api/storage/([a-zA-Z0-9_-]{64})(?=$|[^a-zA-Z0-9_-])')
    def visit(value):
        if isinstance(value, dict):
            for item in value.values(): visit(item)
        elif isinstance(value, list):
            for item in value: visit(item)
        elif isinstance(value, str):
            for match in pattern.finditer(value):
                if match[1] not in found: found.append(match[1])
    source = deepcopy(document)
    source.pop("storage", None)
    visit(source)
    return found


def save_project(model, rid=None, *, requester=None, graphic_builder=None):
    """Save current in-memory contents; return RID and commit identity on success.

    No update-to-create fallback. A transport failure during a mutation is an
    unknown outcome: inspect the destination before deciding to retry. Local
    model stays unchanged until both mutations return validated identities.
    """
    document = deepcopy(model.toJSON())
    target = _rid(document.get("rid") if rid is None else rid)
    if target.split('/')[1].startswith('@'):
        raise ValueError("An ordinary account or organization owner is required")
    if not re.fullmatch(r'[a-z][-_a-z0-9]*', target.split('/')[-1], re.I):
        raise ValueError("Invalid resource key: " + target.split('/')[-1])
    if not isinstance(document.get('name'), str) or not document['name'].strip():
        raise ValueError("A nonempty project name is required")
    revision = document.get("revision", {})
    if revision.get("version") != 5:
        raise NotImplementedError("Only version 5 projects are supported")
    author = _current_user_name()
    from .project_hooks import save_document
    document['rid'] = target
    document = save_document(document,author=author,graphic_builder=graphic_builder)
    revision = document['revision']
    operation = "update" if project_exists(target,requester=requester) else "create"
    rev_input = {k: deepcopy(revision[k]) for k in
                 ("documentation", "graphic", "implements", "parameters", "pins") if k in revision}
    rev_input.update(author=author, message="Saved by CloudPSS SDK auto-modeling", version=5)
    if revision.get("hash"): rev_input["parent"] = revision["hash"]
    new_hash = None
    try:
        created = _request(REVISION_MUTATION, {"input": rev_input}, requester).get("revision")
        new_hash = created.get("hash") if isinstance(created, dict) else None
        if not isinstance(new_hash, str) or not re.fullmatch(r'[A-Za-z0-9_-]{64}', new_hash):
            raise ProjectSaveError("Invalid revision response", outcome_unknown=True)
        payload = {k: deepcopy(document[k]) for k in
                   ("configs", "jobs", "name", "description", "context") if k in document}
        permissions = deepcopy(_PRIVATE)
        permissions.update({k: v for k, v in document.get("permissions", {}).items() if v is not None})
        payload.update(rid=target, revision=new_hash, permissions=permissions, storage=_storage(document))
        for key in ("tags", "keywords"):
            if key in document:
                payload[key] = deepcopy(document[key]) if operation == 'create' else {"replace": deepcopy(document[key])}
        mutation = ('mutation($input:' + operation.title() + 'ModelInput!){resource:'
                    + operation + 'Model(input:$input){rid}}')
        saved = _request(mutation, {"input": payload}, requester).get("resource")
        if not isinstance(saved, dict) or saved.get("rid") != target:
            raise ProjectSaveError("Save returned a different resource identity", revision_hash=new_hash,
                                   outcome_unknown=True)
    except ProjectSaveError:
        raise
    except Exception:
        raise ProjectSaveError("Save did not finish; inspect destination before retrying",
                               revision_hash=new_hash, outcome_unknown=True) from None
    model.rid = target
    model.revision.hash = new_hash
    return target
