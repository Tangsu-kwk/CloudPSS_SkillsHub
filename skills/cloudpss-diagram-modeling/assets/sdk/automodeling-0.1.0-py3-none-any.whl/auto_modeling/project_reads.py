"""Pure projections for read-only project and definition MCP tools."""
from copy import deepcopy


def get_metadata(model):
    """Project metadata projection; does not mutate the SDK model."""
    return {"rid": model.rid, "name": model.name, "description": model.description,
            "documentation": deepcopy(model.revision.documentation)}


def list_jobs(model):
    return [{"index": i, "name": deepcopy(job["name"]), "rid": deepcopy(job.get("rid"))}
            for i, job in enumerate(model.jobs)]


def get_job(model, index=None):
    if index is None:
        index = getattr(model, 'context', {}).get('currentJob')
        index = 0 if index is None else index
    from .scheme_indices import numeric_index
    index = numeric_index(index)
    try:
        return deepcopy(model.jobs[index])
    except IndexError:
        return None


def list_parameter_groups(model):
    """Historical schema projection; populated live group still needs comparison."""
    return [{"name": deepcopy(group.get("name")), "description": deepcopy(group.get("description")),
             "items": [item["key"] for item in group["items"]]}
            for group in (model.revision.parameters or [])]


def _group(model, group):
    from .parameter_defs import _group_ref
    return _group_ref(model, group)[1]


def get_parameter_group(model, group):
    item = _group(model, group)
    return deepcopy(item) if item is not None else None


def list_parameters(model, group):
    item = _group(model, group)
    return [{key: deepcopy(parameter.get(key)) for key in ("key", "name", "description", "type")}
            for parameter in item["items"]] if item is not None else None


def get_parameter(model, param):
    from .parameter_defs import _parameter_ref
    if isinstance(param, (list, tuple)) and len(param) == 2:
        param = {"0":param[0], "1":param[1]}
    return deepcopy(_parameter_ref(model, param)[2])
