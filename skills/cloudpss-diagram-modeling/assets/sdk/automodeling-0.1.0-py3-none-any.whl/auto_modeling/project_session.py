"""Python-owned project construction; no browser replacement, save or run.

Blank defaults and template detachment follow public SimStudio 5.0.39 modules
89955/53222/93059/8434. Deterministic diagram selection follows module 4843;
pixel viewport layout and template dialogs are excluded.
"""
from copy import deepcopy
from dataclasses import dataclass, field
import re

from .component_model import _error_diagnostics
from .diagram_aux import model_from_document

# Same model fields as SDK 5.0.9 Model.fetch, plus official metadata keywords.
MODEL_QUERY = """
query ProjectTemplate($rid: ResourceId!) {
  model(input: {rid: $rid}) {
    configs context description jobs name rid tags keywords storage
    permissions { moderator member everyone }
    revision { author documentation graphic hash implements message parameters pins version }
  }
}
"""
_PRIVATE = {"moderator": 98367, "member": 65551, "everyone": 0}


class ProjectError(RuntimeError):
    def __init__(self, message, graphql_errors=None):
        super().__init__(message)
        self.graphql_errors = graphql_errors


def _rid(value):
    if not isinstance(value, str) or not re.fullmatch(r"model/[^/\s]+/[^/\s]+", value):
        raise TypeError("rid must be a model resource ID")
    return value


def _fetch(rid, requester):
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    try:
        response = requester(MODEL_QUERY, {"rid": rid}, timeout=30)
    except Exception:
        raise ProjectError("Project query failed; check connectivity and SDK configuration") from None
    if not isinstance(response, dict):
        raise ProjectError("Invalid project query response")
    if response.get("errors"):
        raise ProjectError("Project query returned errors", _error_diagnostics(response["errors"]))
    data = response.get("data")
    item = data.get("model") if isinstance(data, dict) else None
    if not isinstance(item, dict) or item.get("rid") != rid:
        raise ProjectError("Missing project or returned identity differs from requested RID")
    return deepcopy(item)


def _strip_template_documentation(text):
    if not isinstance(text, str):
        return text
    match = re.search(r"^(`{3,})\s*template(\s+|$)", text, re.MULTILINE)
    if match is None:
        return text
    closing = "\n" + match[1]
    end = text.find(closing, match.end())
    return text if end < 0 else text[:match.start()] + text[end + len(closing):]


def build_project_model(rid=None, *, requester=None):
    """Return a fresh SDK Model: empty document or detached template copy.

    Blank names use Chinese fallback labels; the default function's runtime
    defaults/translated name, browser subscriptions and viewport initialization
    are not hydrated. This is the source-level document, not a browser snapshot.
    Unlike MCP's None return, Python returns the model for explicit ownership.
    """
    if rid is None:
        document = {
            "rid": "", "name": "", "description": "", "tags": [], "keywords": [],
            "permissions": deepcopy(_PRIVATE), "pages": [],
            "configs": [{"name": "默认参数方案", "args": {}, "pins": {}}],
            "jobs": [{"name": "默认方案", "rid": "function/CloudPSS/emtps", "args": {}}],
            "revision": {"version": 5, "documentation": "", "parameters": [], "pins": [],
                "graphic": {"pins": {}, "markup": [{"tagName": "rect", "selector": "body"}],
                    "attrs": {"body": {"refWidth": 1, "refHeight": 1, "refX": 0, "refY": 0}},
                    "width": 50, "height": 50, "generator": "default", "preserveAspectRatio": True},
                "implements": {"diagram": {"type": "diagram", "canvas": [{"key": "canvas_0", "name": "图纸 1"}],
                    "cells": {}, "variables": [], "geoInfoMaps": []}}},
            "context": {"version": 5, "counter": {}, "diagram": {"openedCanvas": [], "currentCanvas": -1},
                "currentJob": 0, "currentConfig": 0, "category": "normal"}}
    else:
        document = _fetch(_rid(rid), requester)
        document.pop("rid", None)
        document["tags"] = [t for t in document.get("tags", []) if not (
            t == "is:template" or t.startswith(("component:", "project-group:", "template:", "order:")))]
        document["keywords"] = []
        document["permissions"] = deepcopy(_PRIVATE)
        revision = document.get("revision")
        if not isinstance(revision, dict):
            raise ProjectError("Invalid template revision")
        if "documentation" in revision:
            revision["documentation"] = _strip_template_documentation(revision["documentation"])
    try:
        return model_from_document(document)
    except Exception:
        raise ProjectError("Project document is incompatible with the installed SDK") from None


_OMITTED = object()


def new_project(rid=_OMITTED, *, requester=None):
    """Construct a model with observed Chinese standard SimStudio open defaults.

    Session.new_project returns MCP's None; this factory returns its Model.
    Browser pixel viewport and deployment/account-specific subscriptions are not
    universally reproducible. No coordinates are guessed or copied from MCP.
    """
    if rid is None:
        raise TypeError("rid must be a string; omit it to create an empty project")
    from .job_functions import get_job_function
    from .parameter_defs import _default_value
    model = build_project_model(None if rid is _OMITTED else rid, requester=requester)
    return _hydrate_project(model, blank=rid is _OMITTED, requester=requester)


def _hydrate_project(model, *, blank=False, requester=None, refresh_subscriptions=False):
    from .job_functions import get_job_function
    from .parameter_defs import _default_value
    model.revision.author = getattr(model.revision, "author", "")
    model.revision.message = getattr(model.revision, "message", "")
    model.storage = getattr(model, "storage", [])
    definitions = {}
    # Actual MCP open_project hydrates function defaults; direct URL loading
    # can leave stored args untouched. Keep the MCP operation as the baseline.
    for job in model.jobs:
        function_rid = job.get("rid")
        if function_rid not in definitions:
            definitions[function_rid] = get_job_function(function_rid, requester=requester)
        definition = definitions[function_rid]
        if definition is None:
            raise ProjectError("Calculation function is unavailable")
        if blank:
            job["name"] = definition["name"] + "方案 1"
        values = job.setdefault("args", {})
        if not isinstance(values, dict):
            raise ProjectError("Invalid calculation scheme arguments")
        # Source defaulting fills missing/null keys, without replacing caller
        # overrides. Complex values are detached directly from the definition.
        for group in definition["parameters"]:
            for field in group.get("items", []):
                key = field["key"]
                if values.get(key) is None:
                    value = field.get("value")
                    values[key] = deepcopy(value if value is not None else _default_value(field.get("type"), field))
    model.context.setdefault("graphic", {})
    # Module 4843 connectedCallback selects the first canvas when the stored
    # selection is missing or invalid. This requires no browser dimensions.
    # Module 21111 savePos writes pixel coordinates later; do not invent them.
    canvases = model.revision.implements.diagram.canvas
    diagram_context = model.context.setdefault("diagram", {})
    opened = diagram_context.get("openedCanvas", [])
    selected = diagram_context.get("currentCanvas", 0)
    active = opened[selected] if isinstance(selected, int) and 0 <= selected < len(opened) else None
    if canvases and not (isinstance(active, dict) and any(c["key"] == active.get("key") for c in canvases)):
        diagram_context.update(openedCanvas=[{"key": canvases[0]["key"]}], currentCanvas=0)
    if refresh_subscriptions:
        from .component_subscriptions import load_component_subscriptions
        model.context['groupSubscriptions']=load_component_subscriptions(
            model.context.get('groupSubscriptions'),requester=requester)
    elif "groupSubscriptions" not in model.context:
        model.context["groupSubscriptions"] = [
            {"key": "project-support:job-definition/cloudpss/" + key, "name": name,
             "visible": visible, "type": "official"}
            for key, name, visible in [("emtp", "EMTP 元件", True), ("sfemt", "SFEMT 元件", True),
                                      ("power-flow", "潮流元件", True), ("ies-simulation", "综合能源系统元件", False)]]
    return model


def open_project(rid, *, requester=None):
    """Fetch into a detached SDK Model, retaining resource identity/metadata.

    Applies observed MCP function defaults and deterministic canvas selection.
    Applies version-5 cleanup, tags and legacy function RID normalization.
    Known legacy documents are migrated with the local official chain. Pixel
    viewport coordinates are retained if present, never invented. ProjectSession
    exposes MCP's None return contract. Standard SimStudio component groups are
    discovered through GraphQL on each open, retaining stored visibility.
    """
    document = _fetch(_rid(rid), requester)
    from .project_hooks import open_document
    document = open_document(document)
    defaults = build_project_model().toJSON()
    for key in ('jobs','configs'):
        if not document[key]: document[key] = deepcopy(defaults[key])
    try:
        model = model_from_document(document)
    except Exception:
        raise ProjectError("Project document is incompatible with the installed SDK") from None
    return _hydrate_project(model, requester=requester, refresh_subscriptions=True)


@dataclass
class ProjectSession:
    """Explicit Python session; construction failure preserves the old model."""
    model: object = None
    results: object = field(default=None, repr=False)

    def run_job(self, configIndex, jobIndex, *, requester=None):
        """Independent SDK run_job path; does not save the current project."""
        from .job_results import JobResults
        from .job_runner import run_job
        if self.model is None:
            raise ProjectError('No current project')
        if self.results is None:
            self.results = JobResults()
        return run_job(self.model, configIndex, jobIndex, session=self.results, requester=requester)

    def close(self):
        if self.results is not None:
            self.results.close()

    def new_project(self, rid=_OMITTED, *, requester=None):
        replacement = new_project(rid, requester=requester)
        self.model = replacement
        return None

    def open_project(self, rid, *, requester=None):
        replacement = open_project(rid, requester=requester)
        self.model = replacement
        return None

    def save_project(self, rid=None, *, requester=None, graphic_builder=None):
        from .project_persistence import save_project
        if self.model is None:
            raise ProjectError("No current project")
        return save_project(self.model, rid, requester=requester, graphic_builder=graphic_builder)
