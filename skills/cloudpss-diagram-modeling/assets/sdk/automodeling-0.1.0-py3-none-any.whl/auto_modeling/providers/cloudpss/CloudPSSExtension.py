import logging
from typing import Annotated, Dict, Tuple
from pydantic import Field
from auto_modeling.contracts import BaseExtension, ExtensionTool
from auto_modeling.providers.cloudpss import CloudPSSModelEdit
from auto_modeling.core import ServiceResult
from auto_modeling.core.cloudpss import HistoryManager, MappingManager

# 日志配置

logger = logging.getLogger(__name__)

# 默认频率常量
DEFAULT_SAMPLE_FREQ = 200

class CloudPSSExtension(BaseExtension):
    """
    CloudPSS 平台专属扩展功能。

    通过组合模式持有 CloudPSSModelEdit 的引用，
    复用其辅助方法来实现平台特定功能。
    同时提供历史记录管理的便捷接口。
    """

    def __init__(self, model_edit: CloudPSSModelEdit):
        """
        初始化扩展。

        Parameters
        ----------
        model_edit : CloudPSSModelEdit
            核心模型编辑器实例，提供基础辅助方法
        """
        super().__init__()
        self.model_edit = model_edit  # 组合：持有核心编辑器引用
        self.history: HistoryManager = model_edit.history  # 快捷访问历史记录管理器
        self.mapping_manager: MappingManager = model_edit.mapping_manager  # 快捷访问映射管理器
    
    # ========== 模型操作补充方法 ==========

    def add_comp_output_measures(
        self,
        job_name: Annotated[str, Field(description="仿真任务名称")],
        comp_rid: Annotated[str, Field(description="组件类型RID，如'model/CloudPSS/_newBus_3p'")],
        measured_key: Annotated[str, Field(description="【component.args的键】如'Vrms'/'P'/'Freq'等组件内部计算参数(非pins)，批量筛选组件添加量测")],
        conditions: Annotated[list, Field(description="筛选条件列表")] = [],
        comp_list: Annotated[list, Field(description="预筛选组件Key列表")] = None,
        dim: Annotated[int, Field(description="输出通道的维度,默认都是1")] = 1,
        curve_name: Annotated[str, Field(description="曲线名")] = None,
        plot_name: Annotated[str, Field(description="绘图名")] = None,
        freq: Annotated[int, Field(description="采样频率Hz")] = 200
    ) -> ServiceResult:
        """
        根据组件的参数条件，增加对特定组件输出的量测配置。

        Returns
        -------
        ServiceResult
            包含输出配置索引的结果对象
        """
        # TODO:撤销操作
        logger.info(f"[add_comp_output_measures] 添加组件输出测量 - job_name={job_name}, comp_rid={comp_rid}, measured_key={measured_key}")
        logger.debug(f"[add_comp_output_measures] conditions={conditions}, dim={dim}, freq={freq}, plot_name={plot_name}")

        try:
            # 复用 model_edit 的辅助方法
            screenedComps = self.model_edit._screen_comp_by_arg(comp_rid, conditions, comp_list=comp_list)
            logger.info(f"[add_comp_output_measures] 筛选到 {len(screenedComps)} 个组件")

            outputChannels = []
            if curve_name is None:
                curve_name = measured_key

            for k in screenedComps.keys():
                p = screenedComps[k].args[measured_key]
                if p == '':
                    p = '#' + screenedComps[k].label + '.' + curve_name
                    screenedComps[k].args[measured_key] = p

                id1, label = self.model_edit._add_channel(p, dim)
                logger.debug(f"[add_comp_output_measures] 添加通道 - id={id1}, label={label}, 组件={screenedComps[k].label}")
                outputChannels.append(id1)

            if freq is None:
                freq = DEFAULT_SAMPLE_FREQ

            a = self.model_edit._add_outputs(job_name, {'0': plot_name, '1': freq, '2': 'compressed', '3': 1, '4': outputChannels})
            logger.info(f"[add_comp_output_measures] 输出配置完成 - 共{len(outputChannels)}个通道, output_index={a}")
            logger.debug(f"[add_comp_output_measures] plot_name={plot_name}, freq={freq}")

            return ServiceResult.success(data={"output_index": {measured_key: a}}, message=f"成功为 {len(screenedComps)} 个组件添加输出测量")
        except Exception as e:
            logger.error(f"[add_comp_output_measures] 添加组件输出测量失败: {str(e)}", exc_info=True)
            return ServiceResult.failed(message=f"添加组件输出测量失败: {str(e)}")

    # ========== 历史记录管理方法 ==========

    def undo(self) -> ServiceResult:
        """
        撤销上一步操作。
        """
        
        success, message = self.history.undo()
        if success:
            logger.info(f"[undo] {message}")
            return ServiceResult.success(message=message)
        else:
            logger.error(f"[undo] {message}")
            return ServiceResult.failed(message=message)

    def redo(self) -> ServiceResult:
        """
        重做上一步撤销的操作。
        """
        success, message = self.history.redo()
        if success:
            logger.info(f"[redo] {message}")
            return ServiceResult.success(message=message)
        else:
            logger.error(f"[redo] {message}")
            return ServiceResult.failed(message=message)

    def _clear_history(self) -> None:
        """
        清空所有历史记录（撤销栈和重做栈）。

        警告
        ----
        此操作不可逆，将丢失所有历史记录。
        """
        self.history.undo_stack.clear()
        self.history.redo_stack.clear()
        logger.warning("[clear_history] 已清空所有历史记录")

    # ========== 映射管理方法 ==========

    def update_all_mapping(self) -> ServiceResult:
        """
        更新所有映射。
        """
        success, message = self.mapping_manager.update_all_mapping()
        if success:
            logger.info(f"[update_all_mapping] {message}")
            return ServiceResult.success(message=message)
        else:
            logger.error(f"[update_all_mapping] {message}")
            return ServiceResult.failed(message=message)


    # ========== 工具暴露 ==========
    def get_tools(self):
        """声明需要暴露的工具"""
        return [
            ExtensionTool(
                name="add_comp_output_measures",
                description="根据组件参数条件，增加对特定组件输出的量测配置。",
                func=self.add_comp_output_measures,
            ),
            ExtensionTool(
                name="undo",
                description="撤销上一步操作。",
                func=self.undo,
            ),
            ExtensionTool(
                name="redo",
                description="重做上一步撤销的操作。",
                func=self.redo,
            ),
            ExtensionTool(
                name="update_all_mapping",
                description="更新所有映射。",
                func=self.update_all_mapping,
            ),
        ]

