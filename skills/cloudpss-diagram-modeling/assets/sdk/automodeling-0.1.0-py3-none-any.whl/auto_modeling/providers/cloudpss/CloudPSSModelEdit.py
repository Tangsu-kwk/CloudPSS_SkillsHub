from collections import defaultdict
import logging
import re
from typing import Dict, List, Optional, Tuple, Annotated
import uuid
from pydantic import Field
from auto_modeling.contracts import BaseModelEdit
from auto_modeling.core import ServiceResult
from auto_modeling.core import safe_get_env
from auto_modeling.core.cloudpss import MappingManager
from auto_modeling.core.cloudpss import HistoryManager
from cloudpss.model.model import Model
import time
import copy

logger = logging.getLogger(__name__)

DEFAULT_POSITION_VALUE = int(safe_get_env('CET_DEFAULT_POSITION_VALUE', '20'))         # 默认位置值
# 输出通道最大宽度
OUTPUT_CANVAS_MAX_X = int(safe_get_env('PSAT_OUTPUT_CANVAS_MAX_X', '500'))  # 输出画布最大X坐标
# 默认频率常量
DEFAULT_SAMPLE_FREQ = int(safe_get_env('PSAT_DEFAULT_SAMPLE_FREQ', '200'))  # 默认采样频率(Hz)

BUS_RID = 'model/CloudPSS/_newBus_3p'
TRANSMISSION_LINE_RID = 'model/CloudPSS/TransmissionLine'
CHANNEL_RID = "model/CloudPSS/_newChannel"


class CloudPSSModelEdit(BaseModelEdit):
    
    def __init__(self,model: Model,mapping_manager: MappingManager,history: HistoryManager):
        super().__init__()
        self.model = model # 当前加载的cloudpss算例模型对象
        self.history = history # 历史记录管理器
        self.mapping_manager = mapping_manager # 映射表管理器（用于调用工具方法）
        self.comp_canvas = "canvsa_comp" # 用于添加除输出通道外其他所有元件的图纸
        self.output_canvas = "canvas_output" # 用于添加输出通道元件的图纸
        self.comp_count = {} # 记录每种元件添加的数量，用于生成唯一label
        self.pos = {} # 记录每个图纸当前可用的位置坐标，用于新添加元件的位置计算
        self.channel_pin_mapping = self.mapping_manager.channel_pin_mapping # 通道引脚字典
        self.node_to_edges = self.mapping_manager.node_to_edges  # { 'node1': {'edge1', 'edge2'} }
        self.edge_to_nodes = self.mapping_manager.edge_to_nodes  # { 'edge1': ('node1', 'node2') }
        self.comp_label_mapping = self.mapping_manager.comp_label_mapping # 从元件label指向元件的字典
        self.bus_pin_mapping = self.mapping_manager.bus_pin_mapping  # 专门存储母线的引脚，格式：{bus_comp_key: pin_value}
        self.comp_pin_mapping = self.mapping_manager.comp_pin_mapping  # 存储所有元件的引脚映射表，格式：{comp_key: {pin_idx: pin_value}}
        self.comp_library = self.mapping_manager.comp_library # 元件库

        self._initialize_canvases()

    def _initialize_canvases(self):
        """初始化默认画布"""
        self.create_canvas(self.comp_canvas, self.comp_canvas)
        self.create_canvas(self.output_canvas, self.output_canvas)

    def add_component(
        self, 
        comp_rid: Annotated[str, Field(description="需要添加的元件的RID")], 
        comp_label: Annotated[Optional[str], Field(description="元件的label")] = None,
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None, 
        pins: Annotated[Optional[Dict], Field(description="期望设置的引脚")] = None,
        position: Annotated[Optional[Tuple] , Field(description="元件的位置")] = None, 
        canvas: Annotated[Optional[str], Field(description="元件所属的图纸")] = None
    ) -> ServiceResult:
        """
        向模型中添加元件,设计为支持单个元件添加。
        """

        logger.info(f"[add_component] 开始添加元件 - rid={comp_rid}, label={comp_label}, canvas={canvas}, position={position}")
        logger.debug(f"[add_component] args={args}, pins={pins}")

        pins = pins if pins is not None else {}
        args = args if args is not None else {}
        # 1. rid 格式验证
        rid_validation = self._validate_rid(comp_rid)
        if rid_validation is not True:
            logger.warning(f"[add_component] RID验证失败: {rid_validation}")
            return ServiceResult.failed(message=f"RID验证失败: {rid_validation}")
        
        if comp_label in self.comp_label_mapping:
            return ServiceResult.failed(message=f"元件标签重复，请检查：{comp_label}")
        key = None
        new_pins_name = pins['0'] if '0' in pins else None
        try:


            # 如果新增元件是母线，
            if comp_rid == BUS_RID:
                # 如果用户未提供引脚，则自动分配一个母线引脚
                if pins is None or pins == {}:
                    new_pins_name = self._get_new_pin()
                    pins = {"0":new_pins_name}

            if position is not None:
                # 明确提供了位置的情况，直接按照位置添加元件
                # 添加常用元件时，默认不设置引脚，由元件连工具进行统一设置管理
                key,label = self._add_comp_in_canvas(comp_rid, canvas = canvas, args = args, pins = pins, label = comp_label, pos = position)
            else:
                # 未提供位置的情况，按照默认规则添加元件——忽略用户指定的图纸，在默认图纸上进行添加，避免元件位置混乱;引脚同样不设置
                key,label = self._add_comp_in_canvas(comp_rid, canvas = self.comp_canvas, args = args, pins = pins, label = comp_label)

            # 元件添加成功后，在更新comp_pin_mapping和comp_label_mapping，新增元件
            standard_pins = copy.deepcopy(self.mapping_manager.search_comp_detail_in_library(comp_rid).get('pins', {}))
            standard_pins.update(pins)
            self.comp_pin_mapping[key] = standard_pins
            
            self.comp_label_mapping[label] = key
                

            if comp_rid == BUS_RID:
                # 同步更新母线引脚状态表
                self.bus_pin_mapping[key] = new_pins_name

            logger.info(f"[add_component] 元件添加成功 - key={key}, label={label}")

            # --- 历史记录 start --- 
            # 记录撤销操作：删除该元件
            # 放在最后，确保前面其他操作都进行成功了，再进行这一步
            # 撤销时调用 del_component 必须在paused上下文中放置递归记录

            # 定义撤销和重做的辅助函数
            def _undo_logic(saved_label = label):
                with self.history.paused():
                    self.del_component(comp_labels=[saved_label])

            def _redo_logic(saved_rid = comp_rid, saved_args = copy.deepcopy(args), saved_pins = copy.deepcopy(pins), saved_label = label, saved_pos = position, saved_canvas = canvas):
                with self.history.paused():
                    self.add_component(
                        saved_rid,
                        comp_label=saved_label,
                        args=saved_args,
                        pins=saved_pins,
                        position=saved_pos,
                        canvas=saved_canvas
                    )

            self.history.push(
                undo_func = _undo_logic,
                redo_func = _redo_logic,
                name  = f"添加元件[{label}]"
            )

            # --- 历史记录 end --- 

            return ServiceResult.success(data={"key":key,"label":label},message="元件添加成功")
        except Exception as e:
            logger.exception("[add_component] 添加元件失败")
            # 如果是母线，操作失败需要从bus_pin_mapping中删除
            if comp_rid == BUS_RID:
                self.bus_pin_mapping.pop(key,None)
            return ServiceResult.failed(message="添加元件失败: " + str(e))


    def add_shunt_component(
        self,
        comp_rid: Annotated[str, Field(description="需要添加的元件的RID")], 
        target_comp_label: Annotated[str, Field(description="目标元件标签/名称")], 
        comp_label: Annotated[Optional[str], Field(description="新增元件的标签/名称")] = None,
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None,
        position: Annotated[Optional[Tuple], Field(description="元件的位置")] = None, 
        canvas: Annotated[Optional[str], Field(description="元件所属的图纸")] = None
    ) -> ServiceResult:
        """向模型中添加元件, 并与指定的某个元件相连"""
        
        logger.info(f"[add_shunt_component] 开始添加元件 - rid={comp_rid}, target={target_comp_label}, label={comp_label}")
        logger.debug(f"[add_shunt_component] args={args}, position={position}, canvas={canvas}")
        
        # 前提——将元件标签转换为cloudpss内部唯一的key（自动识别label或key）
        target_comp_key = self.mapping_manager.get_comp_key(target_comp_label)
        if target_comp_key is None:
            logger.warning(f"[add_shunt_component] 未找到元件: {target_comp_label}")
            return ServiceResult.failed(message=f"未找到元件: {target_comp_label}")


        with self.history.transaction(f"添加元件{comp_label or comp_rid}"):
            # 1. 校验 RID
            rid_validation = self._validate_rid(comp_rid)
            if rid_validation is not True:
                logger.warning(f"[add_shunt_component] RID验证失败: {rid_validation}")
                return ServiceResult.failed(message=f"RID验证失败: {rid_validation}")

            try:
                target_comp = self.model.getComponentByKey(target_comp_key)
                is_target_bus = target_comp.definition == BUS_RID
                is_new_bus = comp_rid == BUS_RID
                
                target_pin_idx = None
                new_pin = None

                # 情况 A: 目标是母线，且新增不是母线 (直接连母线)
                if is_target_bus and not is_new_bus:
                    new_pin = target_comp.pins['0']
                    
                # 情况 B: 目标是母线，新增也是母线 (不能直连，需加传输线)
                elif is_target_bus and is_new_bus:
                    new_pin = self._get_new_pin()
                    old_pin = target_comp.pins['0']
                    # 特殊处理：先添加母线，再添加中间传输线
                    rs_bus = self.add_component(comp_rid, comp_label, args, pins={'0': new_pin}, position=position, canvas=canvas)
                    if rs_bus.status == "failed":
                        return rs_bus
                    rs_line = self.add_component(TRANSMISSION_LINE_RID, pins={'0': old_pin, '1': new_pin})
                    if rs_line.status == "failed":
                        return ServiceResult.failed(message=f"母线直连自动添加传输线失败：{rs_line.message}")
                    logger.info(f"[add_shunt_component] 母线直连传输线添加成功 - bus_result={rs_bus}, line_result={rs_line}")
                    return ServiceResult.success(data={"bus_key":rs_bus.data['key'],"bus_label":rs_bus.data['label'],"line_key":rs_line.data['key'],"line_label":rs_line.data['label']},message="母线直连自动插入传输线成功")
                # 情况 C: 目标不是母线 (需要寻找目标元件的空闲引脚)
                else:
                    # 找到目标元件第一个空引脚
                    target_pin_idx = self._find_empty_pin(target_comp_key,target_comp.definition)
                    if target_pin_idx is None:
                        logger.warning(f"[add_shunt_component] 元件[{target_comp.label}]无可用电气引脚")
                        return ServiceResult.failed(message=f"元件[{target_comp.label}]无可用电气引脚")
                    
                    new_pin = self._get_new_pin()
                    # 更新目标元件的引脚引用
                    target_comp.pins[target_pin_idx] = new_pin
                    self.comp_pin_mapping[target_comp_key][target_pin_idx] = new_pin

                # 统一执行元件添加更新 (适用于情况 A 和 C)
                rs_add = self.add_component(comp_rid, comp_label, args, pins={'0': new_pin}, position=position, canvas=canvas)
                if rs_add.status == "success":
                    logger.info(f"[add_shunt_component] 并联元件添加成功 - result={rs_add.data}")
                    # 确保所有操作都成功后，再去记录引脚的修改历史
                    if target_pin_idx is not None:
                        # 记录引脚的修改历史
                        # 此处直接修改目标元件的引脚，也是状态的变更，需要手动push一个针对引脚修改的撤销操作(恢复为空)
                        def _undo_pin_change(comp_label=target_comp_label, pin_idx=target_pin_idx):
                            comp_key = self.mapping_manager.get_comp_key(comp_label)
                            comp = self.model.getComponentByKey(comp_key)
                            if comp:
                                comp.pins[pin_idx] = ''
                            self.comp_pin_mapping[comp_key][pin_idx] = ''

                        def _redo_pin_change(comp_label=target_comp_label, pin_idx=target_pin_idx, pin_val=new_pin):
                            comp_key = self.mapping_manager.get_comp_key(comp_label)
                            comp = self.model.getComponentByKey(comp_key)
                            if comp:
                                comp.pins[pin_idx] = pin_val
                            self.comp_pin_mapping[comp_key][pin_idx] = pin_val

                        self.history.push(
                            undo_func=_undo_pin_change,
                            redo_func=_redo_pin_change,
                            name=f"更新元件[{target_comp.label}]的引脚"
                        )
                else :
                    logger.info(f"[add_shunt_component] 并联元件添加失败 - result={rs_add.message}")
                    if target_pin_idx is not None:
                        # 状态回滚
                        target_comp.pins[target_pin_idx] = ''
                        self.comp_pin_mapping[target_comp_key][target_pin_idx] = ''
                return rs_add

            except Exception as e:
                logger.exception(f"[add_shunt_component] 失败: {e}")
                if target_pin_idx is not None:
                    # 状态回滚
                    target_comp.pins[target_pin_idx] = ''
                    self.comp_pin_mapping[target_comp_key][target_pin_idx] = ''
                return ServiceResult.failed(message=f"添加元件失败: {str(e)}")


    def insert_series_component(
        self,
        comp_rid: Annotated[str, Field(description="需要添加的元件的RID")], 
        target_comp_label_A: Annotated[str, Field(description="其中一个目标元件的标签/名称")], 
        target_comp_label_B: Annotated[str, Field(description="另一个目标元件的标签/名称")],
        comp_label: Annotated[Optional[str], Field(description="新增元件标签/名称")] = None,
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None, 
        position: Annotated[Optional[Tuple] , Field(description="元件的位置")] = None, 
        canvas: Annotated[Optional[str], Field(description="元件所属的图纸")] = None
    ) -> ServiceResult:
        """
        在两个元件之间插入一个元件，需确保两个元件之间是直连的。
        """
        logger.info(f"[insert_series_component] 开始插入串联元件 - rid={comp_rid}, A={target_comp_label_A}, B={target_comp_label_B}")
        logger.debug(f"[insert_series_component] label={comp_label}, args={args}")

        # 前提——将元件标签转换为cloudpss内部唯一的key（自动识别label或key）
        comp_key_A = self.mapping_manager.get_comp_key(target_comp_label_A)
        comp_key_B = self.mapping_manager.get_comp_key(target_comp_label_B)
        if comp_key_A is None:
            logger.warning(f"[insert_series_component] 未找到元件: {target_comp_label_A}")
            return ServiceResult.failed(message=f"未找到元件: {target_comp_label_A}")
        if comp_key_B is None:
            logger.warning(f"[insert_series_component] 未找到元件: {target_comp_label_B}")
            return ServiceResult.failed(message=f"未找到元件: {target_comp_label_B}")            


        # 1.校验RID
        rid_validation = self._validate_rid(comp_rid)
        if rid_validation is not True:
            logger.warning(f"[insert_series_component] RID验证失败: {rid_validation}")
            return ServiceResult.failed(message=f"RID验证失败: {rid_validation}")
        
        # 2.校验引脚数目是否大于1
        if len(self.mapping_manager.search_comp_detail_in_library(comp_rid).get('pins', {})) <= 1 and comp_rid != BUS_RID:
            logger.warning(f"[insert_series_component] 插入元件必须至少拥有两个引脚以实现串联连接")
            return ServiceResult.failed(message="插入元件必须至少拥有两个引脚以实现串联连接")
        
        # 开启事务
        with self.history.transaction(f"插入串联元件{comp_label or comp_rid}"):
            try:
                # 3.获取元件对象，用于修改引脚（连接关系）
                compA = self.model.getComponentByKey(comp_key_A)
                compB = self.model.getComponentByKey(comp_key_B)

                # 4. 通过引脚映射表获取两个元件的引脚信息，避免直接从元件对象获取引脚，方式元件通过连接线的方式连接而引脚为空
                pinA_map = self.comp_pin_mapping.get(comp_key_A)
                pinB_map = self.comp_pin_mapping.get(comp_key_B)

                # 寻找公共连接点 (Common Node)
                inv_A = {v: k for k, v in pinA_map.items()}
                inv_B = {v: k for k, v in pinB_map.items()}

                common_nodes = set(inv_A.keys()) & set(inv_B.keys())
                # 取得当前连接的引脚名
                common_node_name = list(common_nodes)[0]
                if not common_node_name :
                    return ServiceResult.failed(message=f"元件[{target_comp_label_A}]与[{target_comp_label_B}]之间不存在直连引脚")
                


                # 获取一个全局唯一的引脚名
                new_node_name = self._get_new_pin()

                def _update_pin_with_history(comp_key: str, pin_idx: str, new_val: str, action: str) -> None:
                    comp = self.model.getComponentByKey(comp_key)
                    # old_val = comp.pins.get(pin_idx) # 这里有问题
                    old_val = self.comp_pin_mapping[comp_key][pin_idx]


                    def _undo(c_key=comp_key, p_idx=pin_idx, o_val=old_val):
                        c = self.model.getComponentByKey(c_key)
                        if c:
                            c.pins[p_idx] = o_val
                        self.comp_pin_mapping[c_key][p_idx] = o_val

                    def _redo(c_key=comp_key, p_idx=pin_idx, n_val=new_val):
                        c = self.model.getComponentByKey(c_key)
                        if c:
                            c.pins[p_idx] = n_val
                        self.comp_pin_mapping[c_key][p_idx] = n_val

                    self.history.push(_undo, _redo, action)

                    # 立即应用
                    comp.pins[pin_idx] = new_val
                    self.comp_pin_mapping[comp_key][pin_idx] = new_val

                # 5. 插入新元件并建立连接
                # --------- 母线插入逻辑 ---------
                if comp_rid == BUS_RID:
                    # 1) 新增母线
                    add_bus = self.add_component(
                        comp_rid, comp_label, args,
                        pins={'0': new_node_name},
                        position=position, canvas=canvas
                    )
                    if add_bus.status == "failed":
                        return add_bus

                    # 2) 删除旧连线
                    self._remove_edge_between_nodes(comp_key_A, comp_key_B)

                    # 3) 只修改一侧（优先修改非母线）
                    if compA.definition == BUS_RID and compB.definition != BUS_RID:
                        target_comp_key = comp_key_B
                        target_inv = inv_B
                    else:
                        target_comp_key = comp_key_A
                        target_inv = inv_A

                    pin_key_to_change = target_inv.get(common_node_name)
                    if pin_key_to_change is None:
                        return ServiceResult.failed(message="无法确定需要更新的引脚")

                    _update_pin_with_history(
                        target_comp_key, pin_key_to_change, new_node_name,
                        f"更新元件[{target_comp_label_A}]的引脚"
                    )

                    # 4) 若 A 或 B 是母线，则插入传输线
                    if compA.definition == BUS_RID or compB.definition == BUS_RID:
                        rs_line = self.add_component(
                            TRANSMISSION_LINE_RID,
                            pins={'0': common_node_name, '1': new_node_name}
                        )
                        if rs_line.status == "failed":
                            return ServiceResult.failed(message=f"母线串联插入连接线失败：{rs_line.message}")

                        return ServiceResult.success(
                            data={
                                "bus_key": add_bus.data["key"],
                                "bus_label": add_bus.data["label"],
                                "line_key": rs_line.data["key"],
                                "line_label": rs_line.data["label"]
                            },
                            message="母线串联插入成功（含连接线）"
                        )
                    else:
                        # 都不是母线,同步修改B的连接
                        _update_pin_with_history(
                            comp_key_B, inv_B.get(common_node_name), new_node_name,
                            f"更新元件[{target_comp_label_B}]的引脚"
                        )


                    return ServiceResult.success(data=add_bus.data, message="母线串联插入成功")
                
                # --------- 非母线插入逻辑 ---------
                # 新元件引脚0连新节点，引脚1连原公共节点
                new_pins = {'0': new_node_name, '1': common_node_name}
                add_result = self.add_component(
                    comp_rid, comp_label, args, pins=new_pins, position=position, canvas=canvas
                )
                if add_result.status == "failed":
                    logger.info(f"[insert_series_component] 串联元件插入失败 - result={add_result.message}")
                    return add_result
                
                # 6. 清理残留的图形边 (Edge)
                # 串联插入后，物理上的直连线已失效，必须从画布中移除
                self._remove_edge_between_nodes(comp_key_A, comp_key_B)
                # 7. 在元件添加成功后，再修改comp_pin_mapping
                # 策略：如果其中一个是母线，保持母线连接不变，修改另一个元件的引脚
                
                target_comp_for_pin = None
                target_key_for_pin = None
                pin_key_to_change = None

                if compA.definition == BUS_RID:
                    # A是母线，修改B的引脚为新节点
                    target_comp_for_pin = compB
                    # target_key_for_pin = comp_key_B
                    pin_key_to_change = inv_B[common_node_name]
                else:
                    # 默认修改A的引脚为新节点
                    target_comp_for_pin = compA
                    # target_key_for_pin = comp_key_A
                    pin_key_to_change = inv_A[common_node_name]

                # # 使用默认参数捕获当前值，避免闭包引用问题
                # old_pin_val = target_comp_for_pin.pins.get(pin_key_to_change)
                # def _undo_pin_update(comp_label=target_comp_for_pin.label, p_idx=pin_key_to_change, v=old_pin_val):
                #     comp_key = self.mapping_manager.get_comp_key(comp_label)
                #     comp = self.model.getComponentByKey(comp_key)
                #     if comp:
                #         comp.pins[p_idx] = v
                #     self.comp_pin_mapping[comp_key][p_idx] = v

                # def _redo_pin_update(comp_label=target_comp_for_pin.label, p_idx=pin_key_to_change, v=new_node_name):
                #     comp_key = self.mapping_manager.get_comp_key(comp_label)
                #     comp = self.model.getComponentByKey(comp_key)
                #     if comp:
                #         comp.pins[p_idx] = v
                #     self.comp_pin_mapping[comp_key][p_idx] = v

                # self.history.push(_undo_pin_update, _redo_pin_update, f"更新元件[{target_comp_for_pin.label}]的引脚")

             
                # target_comp_for_pin.pins[pin_key_to_change] = new_node_name
                # self.comp_pin_mapping[target_comp_for_pin.id][pin_key_to_change] = new_node_name
                _update_pin_with_history(
                    target_comp_for_pin.id, pin_key_to_change, new_node_name,
                    f"更新元件[{target_comp_for_pin.label}]的引脚"
                )

                logger.info(f"[insert_series_component] 串联元件插入成功 - A={target_comp_label_A}, B={target_comp_label_B}, new_key={add_result.data.get('key')}")
                return ServiceResult.success(
                    data=add_result.data,
                    message=f"成功在[{target_comp_label_A}]和[{target_comp_label_B}]之间插入元件成功"
                )
            except Exception as e:
                logger.exception("[insert_series_component] 在两个元件之间插入元件失败")
                return ServiceResult.failed(message="在两个元件之间插入元件失败: " + str(e))


    def conn_components(
        self,
        source_comp_label: Annotated[str, Field(description="源元件标签/名称")],
        target_comp_label: Annotated[str, Field(description="目标元件标签/名称")],
        source_pin: Annotated[Optional[Dict], Field(description="源元件引脚信息")] = None, 
        target_pin: Annotated[Optional[Dict], Field(description="目标元件引脚信息")] = None
    ) -> ServiceResult:
        """
        在两个指定的元件之间建立电气连接。
        
        该方法支持两种模式：
        1. 自动连接：仅需提供元件 Key，系统将按默认规则自动选择可用引脚。（默认模式）
        2. 精确连接：通过 source_pin 和 target_pin 显式指定连接的具体引脚。
        """
        logger.info(f"[conn_components] 开始连接元件 - source={source_comp_label}, target={target_comp_label}")
        logger.debug(f"[conn_components] source_pin={source_pin}, target_pin={target_pin}")

        # 前提——将元件标签转换为cloudpss内部唯一的key（自动识别label或key）
        source_comp_key = self.mapping_manager.get_comp_key(source_comp_label)
        target_comp_key = self.mapping_manager.get_comp_key(target_comp_label)
        if source_comp_key is None:
            logger.warning(f"[conn_components] 未找到元件: {source_comp_label}")
            return ServiceResult.failed(message=f"未找到元件: {source_comp_label}")
        if target_comp_key is None:
            logger.warning(f"[conn_components] 未找到元件: {target_comp_label}")
            return ServiceResult.failed(message=f"未找到元件: {target_comp_label}")


        source_comp = self.model.getComponentByKey(source_comp_key)
        target_comp = self.model.getComponentByKey(target_comp_key)

        if source_comp.definition == BUS_RID and target_comp.definition == BUS_RID:
            logger.warning(f"[conn_components] 两条母线不能直接连接 - source={source_comp_key}, target={target_comp_key}")
            return ServiceResult.failed(message="两条母线不能直接连接")
        
        with self.history.transaction(f"连接元件{source_comp_label}和{target_comp_label}"):
            # 提供引脚的情况，直接更新
            if source_pin is not None and target_pin is not None:
                try:
                    # 记录引脚的修改历史
                    def _record_explicit_pins(comp, pins, comp_label):
                        # 使用深拷贝避免可变对象的引用问题
                        old_pins = copy.deepcopy({k: comp.pins.get(k) for k in pins})
                        new_pins = copy.deepcopy(pins)

                        # 使用默认参数捕获当前值，避免闭包引用问题
                        def _undo(c_label=comp_label, old_pins=old_pins):
                            c_key = self.mapping_manager.get_comp_key(c_label)
                            c = self.model.getComponentByKey(c_key)
                            if c:
                                c.pins.update(old_pins)
                            self.comp_pin_mapping[c_key].update(old_pins)

                        def _redo(c_label=comp_label, new_vals=new_pins):
                            c_key = self.mapping_manager.get_comp_key(c_label)
                            c = self.model.getComponentByKey(c_key)
                            if c:
                                c.pins.update(new_vals)
                            self.comp_pin_mapping[c_key].update(new_vals)

                        self.history.push(_undo, _redo, f"更新元件[{comp.label}]的引脚")

                    _record_explicit_pins(source_comp, source_pin, source_comp_label)
                    _record_explicit_pins(target_comp, target_pin, target_comp_label)

                    # 更新模型中元件的引脚
                    source_comp.pins.update(source_pin)
                    target_comp.pins.update(target_pin)
                    # 更新映射表
                    self.comp_pin_mapping[source_comp_key].update(source_pin)
                    self.comp_pin_mapping[target_comp_key].update(target_pin)
                    logger.info(f"[conn_components] 按照指定引脚连接成功")
                    return ServiceResult.success(message="按照指定的引脚连接元件成功")

                except Exception as e:
                    logger.error(f"[conn_components] 按照指定引脚连接失败: {str(e)}")
                    return ServiceResult.failed(message=f"按照指定的引脚连接元件失败: {str(e)}。请检查提供的引脚是否正确")

            try:
                # 辅助函数：统一处理引脚更新和历史记录
                def _update_and_record(comp, pin_idx, new_val, comp_label):
                    old_val = comp.pins.get(pin_idx)

                    # 使用默认参数捕获当前值，避免闭包引用问题
                    def _undo(c_label=comp_label, p_idx=pin_idx, o_val=old_val):
                        c_key = self.mapping_manager.get_comp_key(c_label)
                        c = self.model.getComponentByKey(c_key)
                        if c:
                            # c.pins.__setitem__(p_idx, o_val)
                            c.pins[p_idx] = o_val
                        self.comp_pin_mapping[c_key][p_idx] = o_val
                        # self.comp_pin_mapping[c_key].__setitem__(p_idx, o_val)

                    def _redo(c_label=comp_label, p_idx=pin_idx, n_val=new_val):
                        c_key = self.mapping_manager.get_comp_key(c_label)
                        c = self.model.getComponentByKey(c_key)
                        if c:
                            # c.pins.__setitem__(p_idx, n_val)
                            c.pins[p_idx] = n_val
                        # self.comp_pin_mapping[c_key].__setitem__(p_idx, n_val)
                        self.comp_pin_mapping[c_key][p_idx] = n_val


                    self.history.push(_undo, _redo, f"连接元件[{comp.label}]的引脚")
                    
                    # 执行更新
                    # 更新模型中元件的引脚
                    comp.pins[pin_idx] = new_val
                    # 更新映射表
                    self.comp_pin_mapping[self.mapping_manager.get_comp_key(comp_label)][pin_idx] = new_val

                if source_comp.definition == BUS_RID:
                    # 找到目标元件第一个空引脚
                    target_pin_idx = self._find_empty_pin(target_comp_key, target_comp.definition)
                    if target_pin_idx is None:
                        return ServiceResult.failed(message=f"元件[{target_comp.label}]无可用电气引脚")
                    
                    _update_and_record(target_comp, target_pin_idx, source_comp.pins['0'], target_comp_label)
                elif target_comp.definition == BUS_RID:
                    # 找到源元件第一个空引脚
                    source_pin_idx = self._find_empty_pin(source_comp_key, source_comp.definition)
                    if source_pin_idx is None:
                        return ServiceResult.failed(message=f"元件[{source_comp.label}]无可用电气引脚")
                    
                    _update_and_record(source_comp, source_pin_idx, target_comp.pins['0'], source_comp_label)
                else:
                    # 如果两个元件都不是母线

                    # 生成一个新的引脚名称
                    new_pin_name = self._get_new_pin()
                    # 找到元件第一个空引脚
                    target_pin_idx = self._find_empty_pin(target_comp_key, target_comp.definition)
                    if target_pin_idx is None:
                        return ServiceResult.failed(message=f"元件[{target_comp.label}]无可用电气引脚")
                    source_pin_idx = self._find_empty_pin(source_comp_key, source_comp.definition)
                    if source_pin_idx is None:
                        return ServiceResult.failed(message=f"元件[{source_comp.label}]无可用电气引脚")
                    
                    _update_and_record(target_comp, target_pin_idx, new_pin_name, target_comp_label)
                    _update_and_record(source_comp, source_pin_idx, new_pin_name, source_comp_label)
                
                logger.info(f"[conn_components] 元件连接成功 - source={source_comp_label}, target={target_comp_label}")
                return ServiceResult.success(message="连接元件成功")
            except Exception as e:
                logger.exception(f"[conn_components] 连接元件失败 - source={source_comp_label}, target={target_comp_label}: {str(e)}")
                return ServiceResult.failed(message=f"连接元件失败: {str(e)}")


    def create_canvas(        
        self,
        canvas: Annotated[str, Field(description="图纸的key")],
        name: Annotated[str, Field(description="图纸的名称")]
    ) -> ServiceResult:
        """
        新增图纸。
        """
        try:
            logger.info(f"[create_canvas] 创建图纸 - key={canvas}, name={name}")
            self.model.revision.implements.diagram.canvas.append({'key': canvas, 'name': name})
            self._init_canvas_pos(canvas)
            logger.info(f"[create_canvas] 图纸创建成功 - key={canvas}")
            return ServiceResult.success(message=f"图纸[{name}]创建成功")
        except Exception as e:
            logger.error(f"[create_canvas] 创建图纸失败: {str(e)}", exc_info=True)
            return ServiceResult.failed(message=f"创建图纸失败: {str(e)}")

    def update_params(
        self,
        comp_labels: Annotated[Optional[List], Field(description="元件标签/名称列表")] = None, 
        comp_rid: Annotated[Optional[str], Field(description="元件的RID")] = None, 
        args: Annotated[Optional[Dict], Field(description="期望设置的参数")] = None
    ) -> ServiceResult:
        """
        更新元件参数,支持按key批量更新和按rid批量更新两种方式，设计为更新相同的参数
        """

        logger.info(f"[update_params] 开始更新元件参数 - labels={comp_labels}, rid={comp_rid}")
        logger.debug(f"[update_params] 更新参数内容: {args}")

        # 临时存储：{key: reason}
        temp_errors = {}
        target_labels = []

        # 1. 基础校验
        if (comp_labels is None) == (comp_rid is None):
            logger.warning(f"[update_params] 参数错误：comp_labels和comp_rid必须有且仅有一个被赋值")
            return ServiceResult.failed(message="请确保 comp_labels 和 comp_rid 有且仅有一个被赋值")
        if not isinstance(args, dict) or not args:
            logger.warning(f"[update_params] 参数错误：args必须是非空字典")
            return ServiceResult.failed(message="args 必须是非空字典")

        # 2. 获取目标元件 Key 列表
        if comp_labels is not None:
            # 1. 统一转为列表处理 (应对输入可能是单字符串或 None 的情况)
            raw_list = comp_labels if isinstance(comp_labels, list) else [comp_labels]

            # 2. 一行代码完成：去None、去空字符串、去空格、去重并保留顺序
            # 逻辑拆解：
            # - str(x).strip(): 保证 "  " 变成 ""
            # - if x and str(x).strip(): 保证过滤掉 None, "", "  "
            target_labels = list(dict.fromkeys(
                str(x).strip() for x in raw_list if x and str(x).strip()
            ))
            if not target_labels:
                logger.warning("[update_params] comp_labels不能为空")
                return ServiceResult.failed(message="comp_labels不能为空")

            logger.info(f"[update_params] 按key更新，目标元件数量: {len(target_labels)}")
        else:
            rid_validation = self._validate_rid(comp_rid)
            if rid_validation is not True:
                return ServiceResult.failed(message=f"RID 校验失败: {rid_validation}")
            target_labels = list(self.model.getComponentsByRid(comp_rid).keys())
            logger.info(f"[update_params] 按rid更新，找到 {len(target_labels)} 个元件")

        # 3. 执行更新并记录错误
        success_count = 0

        # 开启事务
        with self.history.transaction(f"更新元件参数"):
            for label in target_labels:
                try:
                    key = self.mapping_manager.get_comp_key(label)
                    if key is None:
                        logger.warning(f"[update_params] 未找到元件: {label}")
                        temp_errors[label] = "元件不存在"
                        continue

                    try:
                        comp = self.model.getComponentByKey(key)
                    except Exception as e:
                        logger.warning(f"[update_params] 未找到元件: {label}")
                        temp_errors[label] = "元件不存在"
                        continue

                    # 校验参数合法性
                    standard_args = getattr(comp, 'args', {})
                    invalid_params = set(args.keys()) - set(standard_args.keys())
                    
                    if invalid_params:
                        logger.debug(f"[update_params] 参数非法 - label={label}, invalid_params={sorted(list(invalid_params))}")
                        temp_errors[label] = f"存在非法参数: {sorted(list(invalid_params))}"
                    else:
                        # 历史记录
                        # 使用默认参数捕获循环变量的当前值，避免闭包引用问题
                        # 使用深拷贝避免可变对象的引用问题
                        old_values = copy.deepcopy({k: standard_args.get(k) for k in args.keys()})
                        new_values = copy.deepcopy(args)
                        def _undo_args(comp_label=label, old_vals=old_values):
                            comp_key = self.mapping_manager.get_comp_key(comp_label)
                            c = self.model.getComponentByKey(comp_key)
                            if c:
                                c.args.update(old_vals)
                        def _redo_args(comp_label=label, new_vals=new_values):
                            comp_key = self.mapping_manager.get_comp_key(comp_label)

                            c = self.model.getComponentByKey(comp_key)
                            if c:
                                c.args.update(new_vals)
                        self.history.push(_undo_args, _redo_args, f"更新元件[{label}]的参数")

                        # 更新参数
                        standard_args.update(args)
                        success_count += 1
                        logger.debug(f"[update_params] 元件参数更新成功 - label={label}")
                except Exception as e:
                    logger.debug(f"[update_params] 更新元件时发生异常 - label={label}, error={str(e)}")
                    temp_errors[label] = f"运行时异常: {str(e)}"

        # 4. 汇总错误原因：将 {label: reason} 转换为 {reason: [labels]}
        summary_failed_details = {}
        for label, reason in temp_errors.items():
            if reason not in summary_failed_details:
                summary_failed_details[reason] = []
            summary_failed_details[reason].append(label)

        # 5. 组装最终返回
        total = len(target_labels)
        failed_count = len(temp_errors)

        if failed_count == 0:
            logger.info(f"[update_params] 更新完成 - 全部成功，共{total}个元件")
            return ServiceResult.success(message=f"成功更新全部 {total} 个元件")
        elif success_count > 0:
            logger.warning(f"[update_params] 更新完成 - 部分成功：成功{success_count}个，失败{failed_count}个")
            logger.debug(f"[update_params] 失败详情: {summary_failed_details}")
            return ServiceResult.partial(message=f"部分成功：成功{success_count}个，失败{failed_count}个", partial_details=summary_failed_details)
        else:
            logger.error(f"[update_params] 更新完成 - 全部失败，共{failed_count}个元件")
            return ServiceResult.failed(message=f"全部更新失败，共 {failed_count} 个元件", partial_details=summary_failed_details)
        
    def del_component(
        self,
        comp_labels: Annotated[Optional[List], Field(description="待删除元件标签/名称列表")] = None, 
        comp_rid: Annotated[Optional[str], Field(description="待删除元件的RID")] = None
    ) -> ServiceResult:
        """
        删除模型中的元件,支持按key批量删除和按rid批量删除两种方式。
        """
        # 删除元件的同时，也会将引脚清除 
        
        logger.info(f"[del_component] 开始删除元件 - labels={comp_labels}, rid={comp_rid}")
        # 临时存储：{key: reason}
        failed_labels = []
        target_labels = []
        # 1. 基础校验
        if (comp_labels is None) == (comp_rid is None):
            logger.warning(f"[del_component] 参数错误：comp_labels和comp_rid必须有且仅有一个被赋值")
            return ServiceResult.failed(message="请确保 comp_labels 和 comp_rid 有且仅有一个被赋值")

        # 2. 获取目标元件 Key 列表
        if comp_labels is not None:
            # 1. 统一转为列表处理 (应对输入可能是单字符串或 None 的情况)
            raw_list = comp_labels if isinstance(comp_labels, list) else [comp_labels]

            # 2. 一行代码完成：去None、去空字符串、去空格、去重并保留顺序
            # 逻辑拆解：
            # - str(x).strip(): 保证 "  " 变成 ""
            # - if x and str(x).strip(): 保证过滤掉 None, "", "  "
            target_labels = list(dict.fromkeys(
                str(x).strip() for x in raw_list if x and str(x).strip()
            ))
            if not target_labels:
                logger.warning("[del_component] comp_labels不能为空")
                return ServiceResult.failed(message="comp_labels不能为空")
            logger.info(f"[del_component] 按key删除，目标元件数量: {len(target_labels)}")
        else:
            rid_validation = self._validate_rid(comp_rid)
            if rid_validation is not True:
                return ServiceResult.failed(message=f"RID 校验失败: {rid_validation}")
            target_labels = list(self.model.getComponentsByRid(comp_rid).keys())


        # 3. 删除元件（先删除元件，在更新对应的映射表）
        success_count = 0
        logger.info(f"[del_component] 准备删除 {len(target_labels)} 个元件")
        with self.history.transaction(f"删除元件"):
            for label in target_labels:
                try:
                    key = self.mapping_manager.get_comp_key(label)
                    if key is None:
                        logger.warning(f"[del_component] 未找到元件: {label}")
                        failed_labels.append(label)
                        continue

                    # 如果被删除元件是母线，需从母线引脚状态表中移除
                    del_comp = self.model.getComponentByKey(key)
                    if del_comp.definition == BUS_RID:
                        # 删除并记录母线的引脚
                        del_bus_pin = self.bus_pin_mapping.pop(key, None)

                    # 记录被删除元件的信息
                    # saved_comp_data = copy.deepcopy(self.model.revision.implements.diagram.cells[key])
                    
                    is_success = self.model.removeComponent(key)

                    if not is_success:
                        logger.warning(f"[del_component] 删除元件失败: label={label}")
                        failed_labels.append(label)
                        # 恢复母线引脚状态表（如果之前删除了的话）
                        if del_comp.definition == BUS_RID and del_bus_pin is not None:
                            self.bus_pin_mapping.update(del_bus_pin)
                    else:
                        # 删除成功，更新元件映射表
                        self.comp_label_mapping.pop(label, None)

                        # 删除成功，更新引脚映射表（移除该元件）
                        del_pins = self.comp_pin_mapping.pop(key, None)

                        # 删除元件原来的边（如果存在）
                        self._remove_node_and_related_edges(key)

                        # 记录历史便于回退
                        # 使用默认参数捕获循环变量的当前值，避免闭包引用问题
                        # 使用深拷贝避免后续修改污染历史记录
                        def _undo_del_comp(saved_label=label, saved_rid = del_comp.definition, saved_args=copy.deepcopy(del_comp.args), saved_pins=copy.deepcopy(del_pins), saved_position=copy.deepcopy(del_comp.position), saved_canvas = del_comp.canvas):
                            with self.history.paused():
                                # 恢复元件
                                self.add_component(
                                    saved_rid,
                                    saved_label,
                                    saved_args,
                                    saved_pins,
                                    (saved_position['x'], saved_position['y']),
                                    saved_canvas
                                )

                        def _redo_del_comp(comp_label=label):
                            # 重做删除元件
                            with self.history.paused():
                                self.del_component(comp_labels=[comp_label])

                        self.history.push(_undo_del_comp, _redo_del_comp, f"删除元件{label}")

                        # 判断引脚连接的是否是母线元件
                        for del_pin_idx, del_pin_value in list(del_pins.items()):
                            # 如果当前引脚是母线元件的引脚，则无需处理
                            if del_pin_value in self.bus_pin_mapping.values():
                                del_pins.pop(del_pin_idx, None)
                                
                        # 删除元件原来的引脚（如果存在）
                        for comp_key, pins_dict in self.comp_pin_mapping.items():
                            for pins_idx, pins_value in pins_dict.items():
                                # 找到被删除元件相邻的元件
                                if pins_value in list(del_pins.values()):
                                    # 记录引脚的清理，便于回退
                                    old_val = pins_value
                                    def _undo_pin_clear(c_key=comp_key, p_idx=pins_idx, v=old_val):
                                            c = self.model.getComponentByKey(c_key)
                                            if c: c.pins[p_idx] = v
                                            if c_key in self.comp_pin_mapping: self.comp_pin_mapping[c_key][p_idx] = v
                                        
                                    def _redo_pin_clear(c_key=comp_key, p_idx=pins_idx):
                                            c = self.model.getComponentByKey(c_key)
                                            if c: c.pins[p_idx] = ''
                                            if c_key in self.comp_pin_mapping: self.comp_pin_mapping[c_key][p_idx] = ''
                                            
                                    self.history.push(_undo_pin_clear, _redo_pin_clear, f"清除元件[{comp_key}]周边引脚")
                                    

                                    # 更新模型中元件对应的引脚为空
                                    near_comp = self.model.getComponentByKey(comp_key)
                                    near_comp.pins[pins_idx] = ''
                                    # 更新映射表（将引脚设置为空）
                                    pins_dict[pins_idx] = ''

                                    
                        success_count += 1
                except Exception as e:
                    logger.error(f"[del_component] 删除元件时发生异常 - label={label}, error={str(e)}")
                    failed_labels.append(label)

        total = len(target_labels)
        failed_count = len(failed_labels)
        logger.info(f"[del_component] 删除完成 - 总数={total}, 成功={success_count}, 失败={failed_count}")


        if failed_count == 0:
            message = f"成功删除全部 {total} 个元件"
            logger.info(f"[del_component] {message}")
            return ServiceResult.success(message=message)
        elif success_count > 0:
            message = f"部分成功：成功 {success_count} 个，失败 {failed_count} 个"
            logger.warning(f"[del_component] {message}")
            return ServiceResult.partial(message=message, partial_details={"元件已被删除或权限不足": failed_labels})
        else:
            message = f"全部删除失败，共 {failed_count} 个"
            logger.warning(f"[del_component] {message}")
            return ServiceResult.failed(message=message, partial_details={"元件已被删除或权限不足": failed_labels})

    
    
    def _get_new_pin(self):
        # 生成一个随机的引脚名称，避免重复
        return f"AutoAddPin_{uuid.uuid4().hex[:8]}"

    def _add_comp_in_canvas(
        self,
        comp_rid: Annotated[str, Field(description="元件的rid")],
        canvas: Annotated[Optional[str], Field(description="元件所在的画布")] = None,
        args: Annotated[Optional[dict], Field(description="元件的参数")] = None,
        pins: Annotated[Optional[dict], Field(description="元件的引脚")] = None,
        label: Annotated[Optional[str], Field(description="元件的标签")] = None,
        pos: Annotated[Optional[tuple], Field(description="元件的位置")] = None,
    ) -> Dict[str, str]:
        """
        在图纸中新增元件，包括添加元件、为元件key及标签添加后缀、更新坐标位置等功能。

        Returns
        -------
        Tuple[str, str]
            返回新增元件的key和标签。
        """
        logger.debug(f"[_add_comp_in_canvas] rid={comp_rid}, canvas={canvas}, label={label}, pos={pos}")

        # 从元件库中获取标准属性
        comp_suffix = comp_rid.split('/')[-1]
        standard_comp = self.mapping_manager.search_comp_detail_in_library(comp_rid)
        standard_args = copy.deepcopy(standard_comp.get('args', {}))
        standard_pins = copy.deepcopy(standard_comp.get('pins', {}))
        standard_size = copy.deepcopy(standard_comp.get('size', {}))


        pins = pins if pins is not None else {}
        args = args if args is not None else {}

        standard_args.update(args)
        standard_pins.update(pins)
        try:
            # 处理标签为空的情况
            if label is None:
                if(comp_suffix not in self.comp_count.keys()):
                    self.comp_count[comp_suffix] = 0
                    label = comp_suffix + "_" + str(self.comp_count[comp_suffix])
                else:
                    self.comp_count[comp_suffix] += 1
                    label = comp_suffix + "_" + str(self.comp_count[comp_suffix])

            # 处理位置为空的情况
            if pos is not None:
                posTemp = {'x': pos[0], 'y': pos[1]}    
            else:
                posTemp = {k: v for k, v in self.pos[canvas].items() if k in ['x','y']}   
                width = max(120.0, standard_size.get('width', 120.0))
                height = max(60.0, standard_size.get('height', 60.0))
                self._add_x_pos(canvas,width,height)
                # self.pos[canvas]['x'] = self.pos[canvas]['x'] + DEFAULT_POSITION_VALUE

            new_comp_temp = self.model.addComponent(
                comp_rid, label, standard_args, standard_pins, canvas, posTemp,
                size=standard_size,
            )
            logger.debug(f"[_add_comp_in_canvas] 元件添加到画布成功 - id={new_comp_temp.id}, label={new_comp_temp.label}")
            return new_comp_temp.id, new_comp_temp.label
        except Exception as e:
            logger.exception(f"[_add_comp_in_canvas] 在画布中添加元件失败 - rid={comp_rid}, canvas={canvas}: {str(e)}")
            raise e
    def _init_canvas_pos(
        self,
        canvas: Annotated[str, Field(description="指定图纸的key")],
    ):
        """
        初始化某图层的坐标。
        """
        if not isinstance(canvas, str) or not canvas:
            raise ValueError("canvas 参数必须是非空字符串")

        self.pos[canvas] = {}
        self.pos[canvas]['dx'] = DEFAULT_POSITION_VALUE
        self.pos[canvas]['dy'] = DEFAULT_POSITION_VALUE
        self.pos[canvas]['x0'] = DEFAULT_POSITION_VALUE
        self.pos[canvas]['y0'] = DEFAULT_POSITION_VALUE
        self.pos[canvas]['x'] = self.pos[canvas]['x0']
        self.pos[canvas]['y'] = self.pos[canvas]['y0']

        self.pos[canvas]['maxdy'] = 0

    def _add_x_pos(
        self,
        canvas: Annotated[str, Field(description="当前图纸的key")],
        comp_size_width: Annotated[float, Field(description="要添加的元件的宽度")] = 120.0,
        comp_size_height: Annotated[float, Field(description="要添加的元件的高度")] = 60.0,
    ) -> None:
        """
        用于更新元件在 x 轴上的坐标，并检查是否需要换行。
        """

        self.pos[canvas]['x'] = self.pos[canvas]['x'] + comp_size_width
        self.pos[canvas]['maxdy'] = max(self.pos[canvas]['maxdy'], comp_size_height)
        if OUTPUT_CANVAS_MAX_X is not None and OUTPUT_CANVAS_MAX_X < self.pos[canvas]['x']:
            self._new_line_pos(canvas)

    def _new_line_pos(
        self,
        canvas: Annotated[str, Field(description="当前图纸的key")]
    ) -> None:
        """
        用于在图纸中执行换行操作，即将下一个元件的坐标设置为新行的起始位置。
        """

        self.pos[canvas]['x'] = self.pos[canvas]['x0']
        self.pos[canvas]['y'] = self.pos[canvas]['y'] + self.pos[canvas]['dy'] + self.pos[canvas]['maxdy']
        self.pos[canvas]['maxdy'] = 0


    def _validate_rid(self, rid:str):
        """验证rid格式是否正确"""
        if not isinstance(rid, str) or '/' not in rid:
            return f"无效的rid格式: {rid}"
        pattern = r"^model/CloudPSS/([^/]+)$"
        match = re.match(pattern, rid)
        if not match:
            return f"路径结构非法，应为 model/CloudPSS/<component>，当前为：{rid}"
        component = match.group(1)
        if component not in list(self.comp_library.keys()):
            return f"元件 {component} 不是法的CloudPSS元件，请检查"
        
        return True
    
    def _screen_comp_by_arg(
        self,
        comp_rid: Annotated[str, Field(description="元件的RID")],
        conditions: Annotated[list, Field(description="筛选条件列表")],
        comp_list: Annotated[Optional[list], Field(description="元件列表")] = None
    ) -> dict:
        """
        通过参数筛选元件。

        Returns
        -------
        dict
            筛选后的元件字典。
        """


        logger.info(f"[_screen_comp_by_arg] 开始筛选元件 - comp_rid={comp_rid}")
        logger.debug(f"[_screen_comp_by_arg] 筛选条件: {conditions}")

        # 验证rid
        rid_validation = self._validate_rid(comp_rid)
        if rid_validation is not True:
            raise ValueError(f"RID 校验失败: {rid_validation}")

        comps = self.model.getComponentsByRid(comp_rid)
        logger.debug(f"[_screen_comp_by_arg] 找到 {len(comps)} 个 {comp_rid} 类型的元件")
        screenedComps = {}
        if not isinstance(conditions,list):
            conditions = [conditions]
        
        if(comp_list!=None):
            screenedKeys = set(comps.keys()) & set(comp_list)
            comps = dict([(key, comps.get(key, None)) for key in screenedKeys])
            
        for k in comps.keys():
            flag = True
            for c in conditions:
                if(c['arg']=='label'):
                    a = comps[k].label
                else:
                    a = comps[k].args[c['arg']]
                

                flag = True
                Min = c['Min']
                Max = c['Max']
                Set = c['Set']
                if self._is_number(a) and ( Min == None or self._is_number(Min)) and (Max == None or self._is_number(Max)):
                    if(Min!=None and float(Min) > float(a)):
                        flag = False
                        break
                    if(Max!=None and float(Max) < float(a)):
                        flag = False  
                        break
                    if(Set!=None and (a not in Set)):
                        flag = False
                        break
                else:
                    if(Min!=None and Min > a):
                        flag = False
                        break
                    if(Max!=None and Max < a):
                        flag = False  
                        break
                    if(Set!=None and (a not in Set)):
                        flag = False
                        break

            if(flag):
                screenedComps[k] = comps[k]

        logger.info(f"[_screen_comp_by_arg] 筛选完成，符合条件的元件数: {len(screenedComps)}")
        return screenedComps  
          
    def _add_channel(
        self,
        pinName: Annotated[str, Field(description="需要添加输出通道的引脚名称")],
        dim: Annotated[int, Field(description="输出通道的维度（例如，1代表单相，3代表三相），默认1")] = 1,
        channelName: Annotated[Optional[str], Field(description="输出通道的名称。如果为 `None`，则使用 `pinName`")] = None
    ) -> Annotated[str, Field(description="包含通道组件的 ID 和标签的元组")]:
        """
        为指定的引脚添加输出通道，用于在仿真过程中监测和输出该引脚上的信号。

        Returns
        -------
        tuple
            包含通道组件的 ID (`str`) 和标签 (`str`) 的元组。
        """
        logger.info(f"[addChannel] 添加输出通道 - pinName={pinName}, dim={dim}, channelName={channelName}")

        try:
            if pinName not in self.channel_pin_mapping.keys():
                if(channelName == None):
                    channelName = pinName

                argsTemp = {'Name':channelName, 'Dim':dim}
                id1, label = self._add_comp_in_canvas(CHANNEL_RID, canvas = self.output_canvas, args = argsTemp, pins = {'0':pinName},label = channelName)
                self.channel_pin_mapping[pinName] = id1
                logger.info(f"[addChannel] 创建新通道 - id={id1}, label={label}")
            else:
                channelComp = self.model.getComponentByKey(self.channel_pin_mapping[pinName])
                if(channelName != None):
                    channelComp.args['Name'] = channelName
                    channelComp.label = channelName
                    logger.debug(f"[addChannel] 更新通道名称 - {channelName}")
                id1 = channelComp.id
                label = channelComp.label
                logger.info(f"[addChannel] 通道已存在 - id={id1}")

            return id1, label
        except Exception as e:
            logger.error(f"[addChannel] 添加输出通道失败: {str(e)}", exc_info=True)
            raise

    def _is_number(self, s: str) -> bool:
        """
        Descriptions
        ----------
            判断一个字符串是否可以转换为数字。

        Parameters
        ----------
            s (str): 待判断的字符串。

        Returns
        -------
            bool: 如果可以转换为数字则返回 `True`，否则返回 `False`。
        """
        try:
            float(s)
            return True
        except ValueError:
            pass

        try:
            import unicodedata
            unicodedata.numeric(s)
            return True
        except (TypeError, ValueError):
            pass

        return False
    
    def _add_outputs(
        self,
        job_name: Annotated[str, Field(description="计算方案的名称")],
        channels: Annotated[dict, Field(description="需要配置的输出通道，格式为：[输出图像名称, 输出频率, 输出图像类型, 图像宽度, 输出通道key]。")],
    ):
        """
        在EMTPS的计算方案中增加输出通道。

        Returns
        -------
            int: 输出通道的数量。
        """

        job = self.model.getModelJob(job_name)
        if not job:
            raise ValueError(f"未找到名为 '{job_name}' 的计算方案")

        if job[0]['rid'] == "job-definition/cloudpss/emtp":
            job[0]['args']['output_channels'].append(channels)
        elif job[0]['rid'] == "function/CloudPSS/emtps":
            job[0]['args']['output_channels'].append(channels)
        else:
            raise ValueError(f"计算方案 '{job_name}' 不是EMTP或EMTPS类型")

        return len(job[0]['args']['output_channels']) - 1
    
    
    # def _set_topo_edge_dict(self):
    #     """
    #     Descriptions
    #     ----------
    #         获取网络中的边（shape=diagram-edges的元件）。
    #     """
    #     # self.topo_pin_edge_dict = {}
    #     self.node_to_edges = {}
    #     self.edge_to_nodes = {}
    #     for i,j in self.model.getAllComponents().items():
    #         if(j.shape != 'diagram-edge'):
    #             continue
    #         id = j.id
    #         source = j.source['cell']
    #         target = j.target['cell']
    #         # self.topo_pin_edge_dict[frozenset((source, target))] = id
        
    #         # 为 source 和 target 分别记录这个 edge id
    #         for node in [source, target]:
    #             if node not in self.node_to_edges:
    #                 self.node_to_edges[node] = set()
    #             self.node_to_edges[node].add(id)
    #         # 记录边与两端节点的关系 (O(1) 查找邻居的关键)
    #         self.edge_to_nodes[id] = (source, target)

        # return self.node_to_edges

    def _remove_edge_completely(self, edge_id):
        """内部方法：将边从所有索引和模型中彻底抹除，并记录历史，以便回退"""
        if edge_id not in self.edge_to_nodes:
            return False

        # 1. 找到这根边的两端
        node_a, node_b = self.edge_to_nodes[edge_id]

        # 记录历史，便于回溯
        edge_data = None
        if edge_id and edge_id in self.model.revision.implements.diagram.cells:
            edge_data = copy.deepcopy(self.model.revision.implements.diagram.cells[edge_id])

        # # 历史记录辅助函数
        # # 使用默认参数捕获当前值，避免闭包引用问题
        # def _undo_remove_edge(e_id=edge_id, e_data=edge_data, n_a=node_a, n_b=node_b):
        #     # 撤销操作
        #     with self.history.paused():
        #         # 1.恢复模型中的边
        #         if e_data:
        #             self.model.revision.implements.diagram.cells[e_id] = e_data

        #         # 2.恢复边的映射表
        #         self.edge_to_nodes[e_id] = (n_a, n_b)
        #         if n_a not in self.node_to_edges:
        #             self.node_to_edges[n_a] = set()
        #         if n_b not in self.node_to_edges:
        #             self.node_to_edges[n_b] = set()
        #         self.node_to_edges[n_a].add(e_id)
        #         self.node_to_edges[n_b].add(e_id)

        # def _redo_remove_edge(e_id=edge_id):
        #     # 重做操作
        #     with self.history.paused():
        #         self._remove_edge_completely(e_id)

        # self.history.push(_undo_remove_edge, _redo_remove_edge, f"删除边")
        
        # 2. 从模型缓存中弹出
        if edge_id and edge_id in self.model.revision.implements.diagram.cells:
            self.model.revision.implements.diagram.cells.pop(edge_id)

        # 3. 从两个节点的 set 中删除该边 (set.discard 是 O(1))
        if node_a in self.node_to_edges:
            self.node_to_edges[node_a].discard(edge_id)
        if node_b in self.node_to_edges:
            self.node_to_edges[node_b].discard(edge_id)

        # 4. 删除边自身的索引
        del self.edge_to_nodes[edge_id]
    def _remove_node_and_related_edges(self, node_id):
        """
        给定单个节点，删除节点及其关联的所有边
        """
        if node_id not in self.node_to_edges:
            return False

        # 获取关联的所有边（使用 list 复制，防止一边遍历一边修改 set）
        related_edges = list(self.node_to_edges[node_id])

        if not related_edges:
            return False

        for edge_id in related_edges:
            self._remove_edge_completely(edge_id)

        # 最后移除节点自身的索引
        self.node_to_edges.pop(node_id, None)

        return True
    
    def _remove_edge_between_nodes(self, node_a, node_b):
        """
        给定两个节点，确定是否有边并删除
        """
        edges_a = self.node_to_edges.get(node_a, set())
        edges_b = self.node_to_edges.get(node_b, set())

        # 寻找共有边（交集）
        common_edges = edges_a.intersection(edges_b)

        if not common_edges:
            return False # 无边相连

        for edge_id in list(common_edges):
            self._remove_edge_completely(edge_id)
        
        return True


    def _find_empty_pin(self, comp_key: str, comp_rid: str) -> str:
        """查找指定组件的第一个空引脚"""
        # NOTE：已解决电气引脚、非电气引脚的判断；以及悬空引脚的排除
        # 获取当前元件的引脚设置情况
        pins_setting = self.comp_pin_mapping.get(comp_key, {})

        # 获取当前该类元件的引脚结构
        pins_meta = self.mapping_manager.search_comp_detail_in_library(comp_rid)["pins_meta"]


        pins_key =  next((k for k, v in pins_setting.items() if v == '' and pins_meta[k]["type"] == "electrical"), None)

        if not pins_key:
            # 如果未找到为空的引脚，再次判断是否有引脚名不为空但未创建连接的情况
            temp_pins_key = self.mapping_manager.get_unconnected_pins(comp_key, pins_meta)

            pins_key = temp_pins_key[0] if temp_pins_key else None
        
        return pins_key



