from collections import defaultdict
import copy
import logging
import time
from typing import Dict, List, Optional, Set, Tuple, Annotated
from pydantic import Field, validate_call
from auto_modeling.contracts import BaseModelObservation
from auto_modeling.core import ServiceResult
from auto_modeling.core.cloudpss import MappingManager

from cloudpss.model.model import Model



logger = logging.getLogger(__name__)

BUS_RID = 'model/CloudPSS/_newBus_3p'



class CloudPSSModelObservation(BaseModelObservation):

    def __init__(self, model: Model,mapping_manager: MappingManager):
        super().__init__()
        self.model = model
        self.mapping_manager = mapping_manager
        # self.comp_label_key_map = {}  # 用于存储标签到Key的映射
        self.bus_pin_mapping = self.mapping_manager.bus_pin_mapping  # 专门存储母线的引脚，格式：{bus_comp_key: pin_value}
        self.comp_pin_mapping = self.mapping_manager.comp_pin_mapping  # 存储所有元件的引脚映射表，格式：{comp_key: {pin_idx: pin_value}}
    
    @validate_call
    def get_topology_relation(
        self, 
        comp_label: Annotated[str,Field(description="目标元件的标签/名称")], 
        max_depth: Annotated[int,Field(description="最大遍历深度（跳数）",gt=0)] = 1, 
        min_depth: Annotated[int,Field(description="最小遍历深度，默认0。设置为 >0 可仅返回新增层级的数据。",ge=0)] = 0
    ) -> ServiceResult:
        """
        基于BFS获取指定元件周围指定跳数内的拓扑连接关系，支持增量观察（通过min_depth控制,只在连续多次观察时生效，min_depth即上一次观察使用的max_depth）。
        """

        if min_depth >= max_depth:
            logging.warning("[get_topology_relation] min_depth 必须小于 max_depth")
            return ServiceResult.failed(message="min_depth 必须小于 max_depth")


        # 前提——将元件标签转换为cloudpss内部唯一的key（自动识别label或key）
        comp_key = self.mapping_manager.get_comp_key(comp_label)
        if comp_key is None:
            logger.warning(f"[get_topology_relation] 目标元件[{comp_label}]不存在")
            return ServiceResult.failed(message=f"目标元件[{comp_label}]不存在")

        try:
            # 1. 验证目标元件
            error = self._validate_target_component(comp_key,comp_label)
            if error:
                return ServiceResult.failed(message=error)

            # 2. 初始化数据结构
            component_to_serial = {comp_key: 0}  # 元件Key -> 序列号
            next_serial_number = 1

            # 3. 构建引脚到元件的反向索引
            try:
                pin_to_components = self._build_pin_component_index()
                logger.info(f"[get_topology_relation] 构建引脚索引成功，包含{len(pin_to_components)}个引脚")
            except Exception as e:
                logger.error(f"[get_topology_relation] 构建引脚索引失败: {str(e)}")
                return ServiceResult.failed(message=f"构建引脚索引失败: {str(e)}")
                

            # 4. BFS遍历获取拓扑关系,并在此过程中分配序列号
            try:
                adjacency_list,min_start_serial = self._bfs_traverse_topology(
                    comp_key,
                    max_depth,
                    min_depth,
                    component_to_serial,
                    next_serial_number,
                    pin_to_components
                )
                logger.info(f"[get_topology_relation] BFS遍历成功，发现{len(component_to_serial)}个元件")
            except Exception as e:
                logger.error(f"[get_topology_relation] BFS遍历失败: {str(e)}", exc_info=True)
                return ServiceResult.failed(message=f"拓扑遍历失败: {str(e)}")
            # 5. 生成输出
            try:
                output = self._generate_output_string(component_to_serial, adjacency_list,min_start_serial)
                logger.info(f"[get_topology_relation] 生成输出成功")
            except Exception as e:
                logger.error(f"[get_topology_relation] 生成输出失败: {str(e)}")
                return ServiceResult.failed(message=f"生成输出失败: {str(e)}")

            return ServiceResult.success(message="获取拓扑关系成功", data=output)
            # return output + "\n".join([str(min_start_serial)])

        except ValueError as e:
            logger.warning(f"[get_topology_relation] 参数错误: {str(e)}")
            
            return ServiceResult.failed(message=str(e))
        except Exception as e:
            logger.error(f"[get_topology_relation] 未知错误: {str(e)}", exc_info=True)
            return ServiceResult.failed(message=f"获取拓扑关系时发生未知错误: {str(e)}")



    def get_comp_params(
        self,
        comp_labels: Annotated[List[str], Field(description="目标元件标签/名称列表")]
    ) -> ServiceResult:
        """
        获取指定元件的详细参数
        """
        # 1. 统一转为列表处理 (应对输入可能是单字符串或 None 的情况)
        raw_list = comp_labels if isinstance(comp_labels, list) else [comp_labels]

        # 2. 一行代码完成：去None、去空字符串、去空格、去重并保留顺序
        # 逻辑拆解：
        # - str(x).strip(): 保证 "  " 变成 ""
        # - if x and str(x).strip(): 保证过滤掉 None, "", "  "
        target_labels = list(dict.fromkeys(
            str(x).strip() for x in raw_list if x and str(x).strip()
        ))
        if not target_labels:
            logger.warning("[get_comp_params] comp_labels不能为空")
            return ServiceResult.failed(message="comp_labels不能为空")

        all_comp_params = {}
        failed_detail = defaultdict(list)
        for label in target_labels:
            key = self.mapping_manager.get_comp_key(label)
            if key is None:
                logger.warning(f"[get_comp_params] 元件[{label}]不存在")
                failed_detail["KeyError"].append(label)
                continue
            try:
                comp = self.model.getComponentByKey(key)
                if comp is None:
                    logger.warning(f"[get_comp_params] 元件[{label}]不存在")
                    failed_detail["KeyError"].append(label)
                    continue
                # 获取参数的配置信息
                comp_params = comp.args
                # 获取参数的结构信息
                comp_params_meta = self.mapping_manager.search_comp_detail_in_library(comp.definition).get('args_meta', {})
                current_comp_params = {
                    param_key: {
                        "value": param_value,
                        "description": comp_params_meta.get(param_key, "")
                    }
                    for param_key, param_value in comp_params.items()
                }

                all_comp_params[label] = current_comp_params
                logger.info(f"[get_comp_params] 元件[{label}]参数获取成功")
            except KeyError:
                logger.warning(f"[get_comp_params] 元件[{label}]不存在")
                failed_detail["KeyError"].append(label)
            except Exception as e:
                logger.error(f"[get_comp_params] 获取元件[{label}]参数失败: {str(e)}", exc_info=True)
                failed_detail["OtherError"].append(label)

        if not failed_detail:
            return ServiceResult.success(data=all_comp_params, message="所有元件参数获取成功")


        failed_msg = self._build_failed_detail_msg(failed_detail, "参数")

        if all_comp_params:
            return ServiceResult.partial(
                message="部分元件参数获取失败",
                data=all_comp_params,
                partial_details=failed_msg
            )
        else:
            return ServiceResult.failed(
                message="所有元件参数获取失败",
                partial_details=failed_msg
            )

        
    def get_comp_pins(
        self, 
        comp_labels: Annotated[List[str], Field(description="目标元件标签/名称列表")]
    ) -> Dict:
        """
        获取指定元件的引脚信息
    
        """
        # 1. 统一转为列表处理 (应对输入可能是单字符串或 None 的情况)
        raw_list = comp_labels if isinstance(comp_labels, list) else [comp_labels]

        # 2.去None、去空字符串、去空格、去重并保留顺序
        # 逻辑拆解：
        # - str(x).strip(): 保证 "  " 变成 ""
        # - if x and str(x).strip(): 保证过滤掉 None, "", "  "
        target_labels = list(dict.fromkeys(
            str(x).strip() for x in raw_list if x and str(x).strip()
        ))
        if not target_labels:
            logger.warning("[get_comp_pins] comp_labels不能为空")
            return ServiceResult.failed(message="comp_labels不能为空")


        all_comp_pins = {}
        failed_detail = defaultdict(list)
        for label in target_labels:
            key = self.mapping_manager.get_comp_key(label)
            if key is None:
                logger.warning(f"[get_comp_pins] 元件[{label}]不存在")
                failed_detail["KeyError"].append(label)
                continue
            try:
                comp = self.model.getComponentByKey(key)
                if  comp is None or key not in self.comp_pin_mapping.keys():
                    logger.warning(f"[get_comp_pins] 元件[{label}]不存在")
                    failed_detail["KeyError"].append(label)
                    continue
                # 获取引脚的配置信息
                comp_pins_data = self.comp_pin_mapping.get(key, {})
                # 获取引脚的结构信息
                comp_pins_meta = self.mapping_manager.search_comp_detail_in_library(comp.definition).get('pins_meta', {})
                current_comp_pins = {
                    pin_key: {
                        "value": pin_value,
                        **comp_pins_meta.get(pin_key, {})
                    }
                    for pin_key, pin_value in comp_pins_data.items()
                }

                all_comp_pins[label] = current_comp_pins
                logger.info(f"[get_comp_pins] 元件[{label}]引脚获取成功")
            except KeyError:
                logger.warning(f"[get_comp_pins] 元件[{label}]不存在")
                failed_detail["KeyError"].append(label)
            except Exception as e:
                logger.error(f"[get_comp_pins] 获取元件[{label}]引脚失败: {str(e)}", exc_info=True)
                failed_detail["OtherError"].append(label)

        if not failed_detail:
            return ServiceResult.success(data=all_comp_pins, message="所有元件引脚获取成功")
        failed_msg = self._build_failed_detail_msg(failed_detail, "引脚")

        if all_comp_pins:
            return ServiceResult.partial(
                message="部分元件引脚获取失败",
                data=all_comp_pins,
                partial_details=failed_msg
            )
        else:
            return ServiceResult.failed(
                message="所有元件引脚获取失败",
                partial_details=failed_msg
            )


    def _validate_target_component(self, comp_key: str, comp_label: str) -> Optional[Dict]:
        """
        验证目标元件是否存在且有引脚信息

        Returns:
            有错误时返回错误字典，无错误时返回None
        """
        # 检查元件是否存在
        try:
            self.model.getComponentByKey(comp_key)
        except Exception:
            logger.warning(f"[get_topology_relation] 元件[{comp_label}]不存在")
            return f"元件[{comp_label}]不存在"

        # 检查是否有引脚信息
        if not self.comp_pin_mapping.get(comp_key, {}).values():
            logger.warning(f"[get_topology_relation] 元件[{comp_label}]无引脚信息")
            return f"元件[{comp_label}]无引脚信息，无法获取拓扑关系，请刷新拓扑后重试"

        return None


    def _build_pin_component_index(self) -> Dict[str, List[str]]:
        """
        构建引脚值到元件Key列表的反向索引

        Returns:
            字典 {pin_value: [comp_key1, comp_key2, ...]}
        """
        pin_to_components = defaultdict(list)

        for comp_key, pin_map in self.comp_pin_mapping.items():
            for pin_value in pin_map.values():
                if pin_value:  # 忽略空引脚值
                    pin_to_components[pin_value].append(comp_key)

        return dict(pin_to_components)



    def _bfs_traverse_topology(
        self,
        start_comp_key: str,
        max_depth: int,
        min_depth: int,
        component_to_serial: Dict[str, int],
        next_serial_number: int,
        pin_to_components: Dict[str, List[str]]
    ) -> Tuple[Dict[int, Set[int]], int]:
        """
        使用BFS遍历拓扑关系，构建邻接表

        Args:
            start_comp_key: 起始元件Key
            max_depth: 最大遍历深度
            component_to_serial: 元件到序列号的映射（会被修改）
            next_serial_number: 下一个可用的序列号
            pin_to_components: 引脚到元件的索引

        Returns:
            邻接表 {serial_number: {connected_serial_numbers}}

        Raises:
            RuntimeError: 当遍历过程中发生严重错误时
        """
        visited = {start_comp_key}
        current_layer_comp = {start_comp_key}
        adjacency_list = {}
        # current_layer_cnt = 1 # 记录当前正在遍历的层级
        min_start_serial = 0  # 记录min_depth开始的序列号

        try:
            for depth in range(1, max_depth + 1):
                logger.info(f"[get_topology_relation] BFS遍历深度: {depth}")
                next_layer = set()

                if min_depth > 0 and depth == min_depth + 1:
                    # 记录min_depth开始的序列号
                    min_start_serial = next_serial_number

                # 对当前层的元件按 key 排序，确保遍历顺序确定
                for comp_key in sorted(current_layer_comp):
                    try:
                        # 获取当前元件连接的所有元件
                        connected_components = self._find_connected_components(
                            comp_key,
                            pin_to_components
                        )
                    except Exception as e:
                        logger.warning(
                            f"获取元件[{comp_key}]的连接关系失败: {str(e)}，跳过该元件"
                        )
                        #TODO: 考虑是否需要在邻接表中记录为空的元件
                        # adjacency_list[component_to_serial.get(comp_key, -1)] = set()
                        continue

                    # 分配序列号并记录未访问的元件
                    connected_serials = set()
                    # 对连接的元件按 key 排序，确保编号分配顺序确定
                    for connected_key in sorted(connected_components):
                        if connected_key == comp_key:
                            continue

                        # 分配序列号
                        if connected_key not in component_to_serial:
                            component_to_serial[connected_key] = next_serial_number
                            next_serial_number += 1

                        connected_serials.add(component_to_serial[connected_key])

                        # 如果未访问且未到最大深度，加入下一层
                        if connected_key not in visited and depth < max_depth:
                            visited.add(connected_key)
                            next_layer.add(connected_key)

                    # 记录当前元件的邻接关系
                    if depth > min_depth:
                        # 只记录大于min_depth层级的元件
                        current_serial = component_to_serial.get(comp_key, -1)
                        adjacency_list[current_serial] = connected_serials

                # 准备下一层遍历
                if not next_layer or depth >= max_depth:
                    break
                current_layer_comp = next_layer

        except Exception as e:
            raise RuntimeError(f"BFS遍历过程中发生错误: {str(e)}")

        return adjacency_list,min_start_serial

    def _find_connected_components(
        self,
        comp_key: str,
        pin_to_components: Dict[str, List[str]]
    ) -> Set[str]:
        """
        查找与指定元件直接连接的所有元件

        Args:
            comp_key: 元件Key
            pin_to_components: 引脚到元件的索引

        Returns:
            连接的元件Key集合

        Raises:
            ValueError: 当元件引脚信息无效时
        """
        connected = set()

        try:
            pins = self.comp_pin_mapping.get(comp_key, {}).values()

            for pin_value in pins:
                if not pin_value:
                    continue

                try:
                    # 检查是否为母线引脚
                    if self._is_bus_pin(pin_value, comp_key):
                        bus_key = self._get_bus_by_pin(pin_value)
                        if bus_key:
                            connected.add(bus_key)
                    else:
                        # 普通引脚，查找所有使用该引脚的元件
                        components = pin_to_components.get(pin_value, [])
                        connected.update(components)
                except Exception as e:
                    logger.warning(
                        f"处理元件[{comp_key}]的引脚[{pin_value}]时出错: {str(e)}，跳过该引脚"
                    )
                    continue

        except Exception as e:
            raise ValueError(f"查找元件[{comp_key}]的连接关系失败: {str(e)}")

        return connected

    def _is_bus_pin(self, pin_value: str, comp_key: str) -> bool:
        """判断是否为母线引脚"""
        return (
            pin_value in self.bus_pin_mapping.values() and
            comp_key not in self.bus_pin_mapping.keys()
        )

    def _get_bus_by_pin(self, pin_value: str) -> Optional[str]:
        """根据引脚值获取母线Key"""
        for bus_key, bus_pin in self.bus_pin_mapping.items():
            if bus_pin == pin_value:
                return bus_key
        return None

    def _generate_output_string(
        self,
        component_to_serial: Dict[str, int],
        adjacency_list: Dict[int, Set[int]],
        min_start_serial: int
    ) -> str:
        """
        生成拓扑关系的输出字符串

        Args:
            component_to_serial: 元件到序列号的映射
            adjacency_list: 邻接表

        Returns:
            格式化的拓扑关系字符串
        """
        # 生成映射表部分
        mapping_lines = self._generate_mapping_section(component_to_serial,min_start_serial)

        # 生成拓扑关系部分
        topology_lines = self._generate_topology_section(adjacency_list)

        return "\n".join(mapping_lines) + "\n" + "\n".join(topology_lines)

    def _generate_mapping_section(
        self,
        component_to_serial: Dict[str, int],
        min_start_serial: int
    ) -> List[str]:
        """生成映射表部分"""
        lines = [
            "//该部分为一个映射表。维护了ComponentID(拓扑中元件ID)、"
            "ComponentLabel(拓扑中元件label)和SerialNumber(编号)之间的映射关系",
            "<mapping>",
            "@ComponentID ComponentLabel SerialNumber"
        ]

        for comp_key, serial in sorted(component_to_serial.items(), key=lambda x: x[1]):
            if serial >= min_start_serial:
                comp_label = self._get_component_label(comp_key)
                lines.append(f"# {comp_key} {comp_label} {serial}")

        lines.append("</mapping>\n")
        return lines

    def _generate_topology_section(
        self,
        adjacency_list: Dict[int, Set[int]]
    ) -> List[str]:
        """生成拓扑关系部分"""
        lines = [
            "//SerialNumber:拓扑中元件编号;"
            "ConnectedSerialNumber:与该SerialNumber相连的元件的编号",
            "<Topology>",
            "@SerialNumber ConnectedSerialNumber"
        ]

        for serial in sorted(adjacency_list.keys()):
            connected = adjacency_list[serial]
            connected_str = ",".join(map(str, sorted(connected))) if connected else ""
            lines.append(f"# {serial} {connected_str}")

        lines.append("</Topology>\n")
        return lines

    def _get_component_label(self, comp_key: str) -> str:
        """获取元件标签"""
        try:
            comp = self.model.getComponentByKey(comp_key)
            return comp.label if comp and hasattr(comp, 'label') else "N/A"
        except Exception:
            return "N/A"

    def _build_failed_detail_msg(self, failed_detail: dict, detail: str):
        # parts = []
        result = {} 
        if failed_detail.get('KeyError'):
            result["元件不存在"] = failed_detail['KeyError']
            # parts.append(f"元件{failed_detail['KeyError']}不存在")
        if failed_detail.get('OtherError'):
            result[f"元件获取{detail}时发生错误"] = failed_detail['OtherError']
            # parts.append(f"元件{failed_detail['OtherError']}获取{type}时发生错误")
        # return "，".join(parts)
        return result
