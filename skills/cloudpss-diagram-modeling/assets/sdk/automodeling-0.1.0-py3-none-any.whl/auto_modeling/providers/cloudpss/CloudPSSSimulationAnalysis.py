import logging
import os
import time
from typing import List, Dict, Any, Optional, Annotated, Literal
import h5py
import numpy as np
from pydantic import Field
from auto_modeling.contracts import BaseSimulationAnalysis
from auto_modeling.core import ServiceResult
from auto_modeling.core import safe_get_env, generate_unique_path
import copy
from cloudpss.model.model import Model

logger = logging.getLogger(__name__)


class SimulationStatus:
    """仿真状态常量"""
    RUNNING = 0          # 仿真运行中
    COMPLETED = 1        # 仿真完成
    FAILED = -1          # 仿真失败/错误
    NOT_STARTED = -2     # 未开始
# 重试和超时常量
MAX_RETRY_COUNT = int(safe_get_env('CET_MAX_RETRY_COUNT', '5'))                 # 最大重试次数
RETRY_SLEEP_SECONDS = int(safe_get_env('CET_RETRY_SLEEP_SECONDS', '60'))            # 重试间隔(秒)
STATUS_CHECK_INTERVAL = int(safe_get_env('CET_STATUS_CHECK_INTERVAL', '3'))          # 状态检查间隔(秒)
JOB_FETCH_WAIT_SECONDS = int(safe_get_env('CET_JOB_FETCH_WAIT_SECONDS', '2'))          # 任务获取等待间隔(秒)
SHOWLOGS = int(safe_get_env('SHOWLOGS', '1'))  # 是否打印仿真执行日志
VOLTAGE_LOW_THRESHOLD = float(safe_get_env('PSA_VOLTAGE_LOW_THRESHOLD', '0.7'))
VOLTAGE_LOW_DURATION_LIMIT = float(safe_get_env('PSA_VOLTAGE_LOW_DURATION_LIMIT', '1.0'))  # 秒
POWER_ANGLE_DIFF_MAX = float(safe_get_env('PSA_POWER_ANGLE_DIFF_MAX', '360.0'))  # 度

# 频率限制
FREQUENCY_MIN = float(safe_get_env('PSA_FREQUENCY_MIN', '49.0'))  # Hz
FREQUENCY_MAX = float(safe_get_env('PSA_FREQUENCY_MAX', '51.0'))  # Hz
FREQUENCY_BASE = float(safe_get_env('PSA_FREQUENCY_BASE', '50.0'))  # Hz
RATED_FREQUENCY = float(safe_get_env('PSA_RATED_FREQUENCY', '50.0'))  # Hz


class CloudPSSSimulationAnalysis(BaseSimulationAnalysis):


    def __init__(self, model: Model):
        super().__init__()
        self.model = model
        self.runner = None

        self.pfJob_Init = {'args': {'@debug': '',
                '@priority': 0,
                '@queue': 1,
                '@tres': 'cpu=1',#逻辑核心数
                'CheckInput': 1,
                'MaxIteration': 30,
                'ShowRunLog': 2,
                'SkipPF': 0,
                'UseBusAngleAsInit': 1,
                'UseBusVoltageAsInit': 1,
                'UseReactivePowerLimit': 1,
                'UseVoltageLimit': 1},
            'name': 'CA潮流计算方案',
            'rid': 'function/CloudPSS/power-flow'}


        self.emtpsJob_Init = {'args': {'@debug': '',
                '@priority': 0,
                '@queue': 1,
                '@tres': 'cpu=1',#逻辑核心数
                'begin_time': 0,
                'comm': [],
                'comm_freq': 1,
                'comm_protocol': 0,
                'comm_type': 0,
                'ctrlparallel_option': 0,
                'debug': 0,
                'dev_id': 1,
                'dev_num': 1,
                'end_time': 15,
                'event_option': 0,
                'init_cfg': 0,
                'initial_type': 0,
                'kernel_option': 1,
                'load_snapshot': '0',
                'load_snapshot_name': '',
                'max_initial_time': 1,
                'mergeBusNode': 0,
                'multi_dev_partition': [],
                'n_cpu': 1, #实际使用的核心数
                'n_ele_cpu': 1,
                'only_partition': 0,
                'output_channels': [],
                'partition_info': [{'0': 0, '1': '', '2': '', 'ɵid': 25021700}],
                'partition_msg_output': 1,
                'partition_option': 0,
                'ramping_time': 0,
                'realtime_timeout': 10,
                'save_snapshot': 0,
                'save_snapshot_name': 'snapshot',
                'save_snapshot_time': 1,
                'sim_option': 0,
                'snapshot_cfg': 0,
                'solver': 0,
                'solver_option': 0, # 0:常规，1:分网，2:CPU-turbo
                'step_time': 0.00001,
                'task_cmd': '',},
                'name': 'CA电磁暂态仿真方案_新',
                'rid': 'function/CloudPSS/emtps'}

        self.proj_Config_Init = {'args': {}, 'name': 'CA参数方案', 'pins': {}}


    def create_or_update_job(
        self, 
        flag: Annotated[str, Literal["create", "update"], Field(description="操作标识，表示创建一个计算方案还是修改已有的计算方案。'create'表示创建，'update'表示修改")], 
        stype: Annotated[str, Literal["emtps", "power-flow"], Field(description="计算方案的类型，'emtps'表示电磁暂态仿真，'power-flow'表示潮流计算")], 
        name: Annotated[str, Field(description="计算方案的名称")], 
        param: Annotated[Optional[Dict], Field(description="计算方案的参数")] = None
    ) -> ServiceResult:
        """
        创建或更新一个计算方案
        """
        logger.info(f"[create_or_update_job] 开始执行 - flag={flag}, stype={stype}, name={name}")
        logger.debug(f"[create_or_update_job] 参数详情 - param={param}")


        param = param or {}

        try:
            # 1. 获取目标对象（Job）
            if flag == "create":
                if stype == "emtps":
                    job_obj = copy.deepcopy(self.emtpsJob_Init)
                elif stype == "power-flow":
                    job_obj = copy.deepcopy(self.pfJob_Init)
                else:
                    logger.debug(f"[create_or_update_job] 不支持的计算方案类型: {stype}")
                    return ServiceResult.failed(message=f"不支持的计算方案类型: {stype}")
            
                if name: job_obj['name'] = name
            else:
                # update 逻辑：先查找是否存在
                jobs = self.model.getModelJob(name)
                if not jobs:
                    logger.debug(f"[create_or_update_job] 未找到名为 '{name}' 的方案，无法更新")
                    return ServiceResult.failed(message=f"未找到名为 '{name}' 的方案，无法更新")
                job_obj = jobs[0]

            # 2. 统一参数合法性检查
            valid_keys = job_obj.get('args', {}).keys()
            invalid_params = [k for k in param.keys() if k not in valid_keys]
            if invalid_params:
                msg = f"提供的参数中包含无效参数: {invalid_params}"
                logger.debug(f"[create_or_update_job] {msg}")
                return ServiceResult.failed(message=msg)

            # 3. 更新参数并提交
            job_obj['args'].update(param)
            
            if flag == "create":
                self.model.addJob(job_obj)
            
            msg = f"计算方案 '{name}' ({stype}) 已成功 { '创建' if flag == 'create' else '更新' }"
            logger.info(f"[create_or_update_job] {msg}")
            return ServiceResult.success(message=msg)

        except Exception as e:
            logger.error(f"[create_or_update_job] 操作失败: {str(e)}", exc_info=True)
            return ServiceResult.failed(message=f"内部错误: {str(e)}")

    def create_or_update_config(
        self,
        flag: Annotated[str, Literal["create", "update"], Field(description="操作标识，表示创建一个参数方案还是修改已有的参数方案。'create'表示创建，'update'表示修改")],
        name: Annotated[str, Field(description="参数方案的名称")],
        param: Annotated[Optional[Dict], Field(description="参数方案的参数")] = None,
        pins: Annotated[Optional[Dict], Field(description="仿真配置引脚信息")] = None
    ) -> ServiceResult:
        """
        创建或更新一个参数方案
        """
        logger.info(f"[create_or_updata_config]开始执行 - flag = {flag}, name={name}")
        logger.debug(f"[create_or_updata_config] 参数详情 -  param={param}, pins={pins}")

        try:
            param = param or {}
            pins = pins or {}

            if flag == "create":
                config_obj = copy.deepcopy(self.proj_Config_Init)
                if name :
                    config_obj['name'] = name
            else:
                configs = self.model.getModelConfig(name)
                if not configs : 
                    logger.debug(f"[create_or_updata_config] 未找到名为 '{name}' 的方案，无法更新")
                    return ServiceResult.failed(message=f"未找到名为 '{name}' 的方案，无法更新")

                config_obj = configs[0]

            # 参数方案的内容完全由用户控制的，不太方便进行统一的参数验证
            config_obj['args'].update(param)
            config_obj['pins'].update(pins)

            if flag == "create":
                self.model.addConfig(config_obj)

            msg = f"参数方案 - {name} 已成功{'创建' if flag == 'create' else '更新'}"
            logger.info(f"[create_or_updata_config]{msg}")
            return ServiceResult.success(message=msg)

        except Exception as e:
            logger.error(f"[create_or_updata_config] 操作失败：{str(e)}", exc_info=True)
            return ServiceResult.failed(message=f"内部错误：{str(e)}")
                
    def get_current_job(
        self, 
        job_name: Annotated[Optional[str],Field(description="计算方案名称，不指定时查询所有")] = None,
        stype: Annotated[Optional[str], Literal["emtps","power-flow"], Field(description="'emtps'或'power-flow'，表示电磁暂态仿真或潮流计算。")] = None
    ) -> ServiceResult:
        """
        获取模型中当前已有的计算方案
        """
        # TODO:映射机制还需完善
        logger.info(f"[get_current_job]查询计算方案 - stype={stype}, jobName={job_name if job_name else '全部'}")

        emtps_mapping = {"sim_option":"仿真类型","begin_time":"开始时间","end_time":"结束时间","step_time":"积分步长","output_channels":"输出通道","solver":"求解器","init_cfg":"是否配置启动参数","snapshot_cfg":"是否配置断面参数",
        "solver_option":"计算选项","n_cpu":"核心数","n_ele_cpu":"电气核心数","ctrlparallel_option":"控制系统与电气系统并行","partition_option":"配置负载均衡策略",
        "@queue":"任务队列","@tres":"计算资源","@priority":"优先级"}
        emtps_value_mapping={
            "仿真类型":{0:"离线仿真",1:"实时仿真",2:"组网仿真"},
            "求解器":{0:"常规",1:"开关/离散事件处理增强"},
            "计算选项":{0:"常规",1:"分网并行",2:"CPU Turbo",3:"CPU Super Turbo"},
            "任务队列":{1:"默认队列",2:"超算中心",3:"Function队列"},
            "是否配置启动参数":{0:"关",1:"开"},
            "是否配置断面参数":{0:"关",1:"开"},
            "控制系统与电气系统并行":{0:"关",1:"开"},
            "配置负载均衡策略":{0:"关",1:"开"},
        }

        powerFlow_mapping = {
            'UseBusVoltageAsInit': "使用母线电压幅值",
            'UseBusAngleAsInit': "使用母线电压相角",
            'UseVoltageLimit':"考虑电压约束",
            'UseReactivePowerLimit': "考虑无功约束",
            "Method":"求解方式",
            'MaxIteration': "最大迭代次数",
            "Tolerance":"迭代容差",
            '@queue': "任务队列",
            '@tres': '计算资源',
            '@priority':"优先级"}
        powerFlow_value_mapping={
            "使用母线电压幅值":{0:"关",1:"开"},
            "使用母线电压相角":{0:"关",1:"开"},
            "考虑电压约束":{0:"关",1:"开"},
            "考虑无功约束":{0:"关",1:"开"},
            "求解方式":{"power_flow":"潮流计算","power_imbalance":"功率不平衡求解","common_format":"生成潮流文件"},
            "任务队列":{1:"默认队列",3:"Function队列"},
        }

        # 1. 定义不同类型的配置映射，方便后续扩展
        type_configs = {
            "emtps": {
                "rid": "function/CloudPSS/emtps",
                "mapping": emtps_mapping,
                "val_mapping": emtps_value_mapping,
                "name_label": "名称"
            },
            "power-flow": {
                "rid": "function/CloudPSS/power-flow",
                "mapping": powerFlow_mapping,
                "val_mapping": powerFlow_value_mapping,
                "name_label": "名称（不可修改）"
            }
        }

        try:
            # 提取方案
            if job_name :
                jobs = self.model.getModelJob(job_name)
                if not jobs :
                    logger.debug(f"[get_current_job] 未找到名为{job_name}的计算方案")
                    return ServiceResult.failed(message=f"未找到名为{job_name}的计算方案")
            else:
                jobs = self.model.jobs
                if not jobs :
                    logger.debug(f"[get_current_job] 当前模型无计算方案")
                    return ServiceResult.failed(message=f"当前模型无计算方案")
            
            finally_jobs = []

            # 解析方案
            for job in jobs:
                rid = job.get('rid',"")

                # 识别当前Job的类型
                current_job_stype = None
                for k, config in type_configs.items():
                    if rid == config['rid']:
                        current_job_stype = k
                        break
                
                # 过滤逻辑
                # 如果stype为空，直接跳过，不用处理；如果stype不为空，则需要获取类型为stype的计算方案,跳过其他方案
                if stype and current_job_stype != stype:
                    continue

                # 如果是未知的类型且 stype 为空（即获取所有时），可以选择跳过或报错
                if not current_job_stype:
                    logger.warning(f"[get_current_job] 跳过未知的计算方案类型: {rid}")
                    continue


                # 执行解析逻辑
                conf = type_configs[current_job_stype]
                job_args = job.get('args', {})
                
                # 字段映射转换
                job_dict = {conf['mapping'][k]: {k:v} for k, v in job_args.items() if k in conf['mapping']}
                # 值转换 (解码)
                job_dict = self._decode_dict_tool(job_dict, conf['val_mapping'])
                
                # 补充基础信息
                job_dict[conf['name_label']] = job.get('name')
                job_dict['rid'] = rid
                
                finally_jobs.append(job_dict)

            logger.info(f"[get_current_job] 找到{len(finally_jobs)} 个符合条件的计算方案")
            return ServiceResult.success(message=f"找到{len(finally_jobs)} 个符合条件的计算方案",data=finally_jobs)
        except Exception as e :
            logger.error(f"[get_current_job]操作失败：{str(e)}",exc_info=True)
            return ServiceResult.failed(message=f"内部错误：{str(e)}")
        
    def get_current_config(
        self, 
        config_name: Annotated[Optional[str], Field(description="参数方案名称，不指定时查询所有")] = None
    ) -> ServiceResult:
        """
        获取模型中当前已有的参数方案
        """
        logger.info(f"[get_current_config]查询参数方案 - configName={config_name if config_name else '全部'}")

        try:
            if config_name : 
                configs = self.model.getModelConfig(config_name)
                if not configs :
                    logger.debug(f"[get_current_config] 未找到名为{config_name}的参数方案")
                    return ServiceResult.failed(message=f"未找到名为{config_name}的参数方案")
            else :
                configs = self.model.configs
                if not configs :
                    logger.debug(f"[get_current_config] 当前模型无参数方案")
                    return ServiceResult.failed(message=f"当前模型无参数方案")
                
            finally_configs = []
            for config in configs:
                finally_configs.append({"名称":config['name'],"参数配置":config['args']})
            logger.info(f"[get_current_config] 找到 {len(finally_configs)} 个参数方案")
            
            return ServiceResult.success(message=f"找到 {len(finally_configs)} 个参数方案",data=finally_configs)
        except Exception as e :
            logger.error(f"[get_current_config] 操作失败：{str(e)}")
            return ServiceResult.failed(message=f"内部错误：{str(e)}")
        

    def run_simulation(
        self, 
        job_name: Annotated[str,Field(description="计算方案名称")], 
        config_name: Annotated[str, Field(description="参数方案名称")]
    ) -> ServiceResult:
        """
        运行仿真。会一直运行，直到仿真结束
        """
        logger.info(f"[run_simulation] 开始运行仿真 - jobName={job_name}, configName={config_name}")

        # 获取指定参数方案和计算方案
        job = self.model.getModelJob(job_name)[0]
        config = self.model.getModelConfig(config_name)[0]

        if not job :
            logger.debug(f"[run_simulation] 当前计算方案 {job} 不存在")
            return ServiceResult.failed(message=f"当前计算方案 {job} 不存在")
         
        if not config :
            logger.debug(f"[run_simulation] 当前参数方案 {config} 不存在")
            return ServiceResult.failed(message=f"当前参数方案 {config} 不存在")
        
        logger.info(f"[run_simulation] 获取到计算方案: {job['name']}, 获取到参数方案: {config['name']}")

        # 启动仿真
        for i in range(MAX_RETRY_COUNT):
            try:
                logger.info(f"[run_simulation] 第 {i+1} 次尝试启动 runner")
                self.runner = self.model.run(job=job, config=config)
                logger.info(f"[run_simulation] Runner 启动成功, runner_id={self.runner.id}")

                break
            except Exception as e :
                logger.warning(f"[run_simulation] 第 {i+1} 次启动 runner 失败: {str(e)}, {RETRY_SLEEP_SECONDS}秒后重试")
                if i == MAX_RETRY_COUNT - 1:
                    logger.error(f"[run_simulation] Runner 启动失败，已重试{MAX_RETRY_COUNT}次", exc_info=True)
                time.sleep(RETRY_SLEEP_SECONDS)
        
        if(job['rid']==self.emtpsJob_Init['rid']):
            endstime = float(job['args']['end_time'])
            logger.info(f"[run_simulation] 仿真预计结束时间: {endstime}s")

        time_start=time.time()
        time_end=0

        # 判断仿真状态并记录日志
        while self.runner.status() < SimulationStatus.COMPLETED:
            time_end = time.time()
            elapsed_time = time_end - time_start

            if int(SHOWLOGS) :
                for log in self.runner.result.getLogs():
                    if 'data' in log.keys() and 'content' in log['data'].keys():
                        logger.info(f"[run_simulation:SimLog] {log['data']['content']}")
            
            if job['rid'] in [self.pfJob_Init['rid'],self.emtpsJob_Init['rid']] and self.runner.result.getPlot(0) is not None : 
                ckeytemp = self.runner.result.getPlotChannelNames(0)[0]
                stime = self.runner.result.getPlotChannelData(0, ckeytemp)['x'][-1]

                progress_pct = (stime / endstime * 100) if endstime > 0 else 0
                logger.info(f'[run_simulation] 进度: {round(stime,2)}s / {endstime}s ({progress_pct:.1f}%), 已耗时: {elapsed_time:.1f}s, Status: {self.runner.status()}')
                
                if round(stime, 2) == endstime:
                    logger.info(f"[run_simulation] 仿真已完成到目标时间")
                    break
            else:
                logger.info(f'[run_simulation] 耗时: {elapsed_time:.1f}s, Runner Status: {self.runner.status()}')

            time.sleep(STATUS_CHECK_INTERVAL)

            if self.runner.status() == SimulationStatus.FAILED:
                logger.error('[run_simulation] 仿真失败')
                #TODO：捕获并返回失败的日志
                return ServiceResult.failed(message="仿真失败")
        
        logger.info(f"[run_simulation] 仿真成功完成, runner_id={self.runner.id}, 总耗时: {time.time()-time_start:.1f}s")
        return ServiceResult.success(message="仿真成功", data={"runner_id": self.runner.id})

    def check_simulation_status(
        self, 
        # simulation_id: Annotated[str,Field(description="仿真结果ID")]
    ) -> ServiceResult:
        """
        检查当前仿真状态。
        """
        logger.info("[check_simulation_status] 检查仿真状态")

        if self.runner is None:
            logger.warning("[check_simulation_status] Runner 未初始化")
            return ServiceResult.success(message="仿真未开始")
        
        # if self.runner.id != simulation_id:
        #     logger.warning("[check_simulation_status] Runner ID 不匹配")
        #     return ServiceResult.success(message="仅支持查看最新一次仿真的执行状态，请检查ID是否正确")
        try:
            status = self.runner.status()
            logger.info(f"[check_simulation_status] Runner 状态: {status}")

            if status == 0:
                return ServiceResult.success(message="仿真正在进行中...") 
            elif status == 1:
                return ServiceResult.success(message="仿真已完成")
            else:
                #TODO：获取失败原因
                return ServiceResult.failed(message="仿真失败")
        except Exception as e:
            logger.error(f"[check_simulation_status] 检查仿真状态失败: {str(e)}")
            return ServiceResult.failed(message=f"检查仿真状态失败,内部错误: {str(e)}")


    def save_simulation_results(
        self, 
        # simulation_id: Annotated[str,Field(description="仿真结果ID")] = None,
        job_name: Annotated[str, Field(description="当前仿真使用的计算方案名称")],
        # save_path: Annotated[str,Field(description="仿真结果保存路径")] = None,
    ) -> ServiceResult:
        """
        保存当前仿真结果。
        """
        #TODO: 暂时未考虑潮流数据的保存
        logger.info("[save_simulation_results] 保存仿真结果")
        if  not self.runner:
            logger.warning("[save_simulation_results] 当前没有已执行的仿真任务")
            return ServiceResult.failed(message="当前没有已执行的仿真任务")
        try:
            # 提取EMT数据
            try:
                PAresult = self.runner.result.getPlots()
                if not PAresult :
                    logger.warning("[save_simulation_results] 当前仿真数据为空")
                    return ServiceResult.failed(message="当前仿真数据为空")
            except Exception as e:
                logger.error(f"[save_simulation_results] 获取仿真结果失败：{str(e)}")
                return ServiceResult.failed(message=f"获取仿真结果失败：{str(e)}")
            PAresult_values = list(PAresult)

            # 查看仿真计算方案，确定每条量测数据量测的点位
            current_job = self.model.getModelJob(job_name)

            if not current_job:
                logger.warning("[save_simulation_results] 当前仿真计算方案不存在")
                return ServiceResult.failed(message="当前仿真计算方案不存在")
            
            output_channels = current_job[0]["args"]["output_channels"]
            all_channel_result = []
            for channel_idx, output_channel in enumerate(output_channels):
                channel_name = output_channel["0"]
                channel_value = np.array([trace['y'] for trace in PAresult_values[channel_idx]['data']['traces']])
                all_channel_result.append({"name":channel_name,"value":channel_value})

            # 将数据保存到本地
            emt_object_path = generate_unique_path(self.model.name,"emt_result","emt","h5")
            init_state = [job_name, self.runner.id]
            local_emt_url = self._save_emt_to_hdf5_local(
                emt_object_path,init_state,all_channel_result
            )

            return ServiceResult.success(data={"local_emt_url":local_emt_url}, message="仿真结果保存成功")
        except Exception as e:
            logger.error(f"[save_simulation_results] 保存仿真结果失败：{str(e)}")
            return ServiceResult.failed(message=f"保存仿真结果失败：{str(e)}")

    def check_voltage(
        self, 
        job_name: Annotated[str, Field(description="当前使用的计算方案名称")],
        bus_channel_idx: Annotated[int, Field(description="母线电压通道索引")],
    ) -> ServiceResult:
        """
        检查电压稳定性，并返回最低电压值。

        """
        logger.info("[check_voltage] 开始检查电压稳定性")

        current_job = self.model.getModelJob(job_name)

        if not current_job:
            logger.warning("[check_voltage] 当前仿真计算方案不存在")
            return ServiceResult.failed(message="当前仿真计算方案不存在")
        # 提取仿真步长
        step_time = current_job[0]["args"]["step_time"]

        # 提取电压数据
        PAresult = self.runner.result.getPlots()
        PAresult_values = list(PAresult)
        bus_voltage_data = np.array([trace['y'] for trace in PAresult_values[bus_channel_idx]['data']['traces']])


        min_voltage = 100.0  # 初始化为一个非常高的值

        try:
            is_stable = True
            
            # 优化：先计算全局最低电压，再进行持续时间判断
            if bus_voltage_data.size > 0:
                # 找到所有母线、所有时刻中的最小值
                min_voltage = np.min(bus_voltage_data)
            else:
                min_voltage = 0.0 # 处理空数据情况

            # 检查持续低压：这是判断稳定性的关键
            for i in range(len(bus_voltage_data)):
                voltage = bus_voltage_data[i]
                below_threshold_time = 0.0
                for j in range(len(voltage)):
                    
                    # 检查电压是否低于阈值
                    if voltage[j] < VOLTAGE_LOW_THRESHOLD:
                        below_threshold_time += step_time
                    else:
                        below_threshold_time = 0.0

                    # 如果电压持续低于阈值超过限制时间，判定为不合格
                    if below_threshold_time >= VOLTAGE_LOW_DURATION_LIMIT:
                        logger.warning(f'[check_voltage] 电压不合格 - 母线索引={i}, 持续低压时间={below_threshold_time:.4f}s')
                        is_stable = False
                        # 但根据原代码的逻辑，一旦发现不合格项就应该立即返回
                        # return False, min_voltage
                        return ServiceResult.success(message="电压检查未通过",data={"min_voltage":min_voltage})
            
            if is_stable:
                logger.info("[check_voltage] 电压检查通过")
                return ServiceResult.success(message="电压检查通过",data={"min_voltage":min_voltage})

        except Exception as e:
            logger.error(f"[check_voltage] 电压检查失败: {str(e)}", exc_info=True)
            # 异常情况下，返回 False，并返回当前已知的最低电压（或默认值）
            # return False, min_voltage if min_voltage != 10.0 else 0.0
            return ServiceResult.failed(message=f"电压检查失败,内部错误: {str(e)}")

    def check_power_angle_diff(
        self,
        job_name: Annotated[str, Field(description="当前使用的计算方案名称")],
        bus_channel_idx: Annotated[int, Field(description="母线电压通道索引")],
    ) -> ServiceResult:
        """
        检查功角差，并返回最大功角差 (deg)。
        """
        logger.info("[check_power_angle_diff] 开始检查功角差")
        max_diff = 0.0

        current_job = self.model.getModelJob(job_name)

        if not current_job:
            logger.warning("[check_voltage] 当前仿真计算方案不存在")
            return ServiceResult.failed(message="当前仿真计算方案不存在")

        # 提取电压数据
        # 设置功角数据的时间限制
        time_limit = 3.0  # 秒
        PAresult = self.runner.result.getPlots()
        PAresult_values = list(PAresult)
        power_angle_data = np.array([
                np.array(trace['y'])[np.array(trace['x']) <= time_limit]
                for trace in PAresult_values[bus_channel_idx]['data']['traces']
            ])

        try:
            power_angle_array = np.array(power_angle_data)
            num_generators = len(power_angle_array)
            
            if num_generators < 2:
                logger.info("[check_power_angle_diff] 发电机数量不足，功角差检查通过")
                return ServiceResult.failed(message="发电机数量较少，无法进行攻角检查")

            # 初始化一个空列表来存储所有时刻、所有发电机对的功角差
            all_diffs = []

            # 遍历每一对发电机
            for i in range(num_generators):
                for j in range(i + 1, num_generators):
                    # 功角差是两个发电机功角时间序列的逐点绝对差值
                    # 假设 power_angle_array[i] 和 power_angle_array[j] 都是时间序列
                    # 简化：原代码的四层循环有误，不应遍历 power_angle_array[i] 和 power_angle_array[j] 的内部
                    # 应该比较的是同一时刻 (k) 两个发电机 i 和 j 的功角
                    
                    # 计算两个时间序列的逐点差值
                    diff_series = np.abs(power_angle_array[i] - power_angle_array[j])
                    
                    # 记录这组发电机对的最大差值
                    all_diffs.append(np.max(diff_series))
                    
            # 找到所有发电机对、所有时刻中的最大差值 (报告指标)
            if all_diffs:
                max_diff = np.max(all_diffs)
            
            # 检查是否合格 (稳定性判断)
            if max_diff > POWER_ANGLE_DIFF_MAX:
                logger.warning(f'[check_power_angle_diff] 功角不合格 - 最大角度差={max_diff:.2f}度')
                return ServiceResult.success(message="功角检查未通过",data={"max_diff":max_diff})
            
            logger.info("[check_power_angle_diff] 功角检查通过")
            return ServiceResult.success(message="功角检查通过",data={"max_diff":max_diff})
            
        except Exception as e:
            logger.error(f"[check_power_angle_diff] 功角检查失败: {str(e)}", exc_info=True)
            # 异常情况下返回 False 和 0.0
            return ServiceResult.failed(message=f"功角检查失败,内部错误: {str(e)}")

    def check_frequency(
        self,
        job_name: Annotated[str, Field(description="当前使用的计算方案名称")],
        bus_channel_idx: Annotated[int, Field(description="母线电压通道索引")],
    ) -> ServiceResult:
        """
        检查频率稳定性，并返回最大频率偏移值 (Hz)。

        """
        logger.info("[check_frequency] 开始检查频率稳定性")
        
        current_job = self.model.getModelJob(job_name)

        if not current_job:
            logger.warning("[check_voltage] 当前仿真计算方案不存在")
            return ServiceResult.failed(message="当前仿真计算方案不存在")

        # 提取电压数据
        PAresult = self.runner.result.getPlots()
        PAresult_values = list(PAresult)
        channel_data = np.array([trace['y'] for trace in PAresult_values[bus_channel_idx]['data']['traces']]) 

        # TODO:由于simstudio中无法直接量测得到频率，因此，无法保证输出通道中输出的是转速还是频率,此处简单通过平均值进行判断
        mean_val = np.mean(channel_data)

        if 45 <= mean_val <= 55:
            frequency_data = channel_data
        else:
            frequency_data = channel_data * FREQUENCY_BASE
        


        max_freq_deviation = 0.0
        try:
            if frequency_data.size == 0:
                logger.warning("[check_frequency] 频率数据为空")
                return ServiceResult.failed(message="频率数据为空，无法进行检查")
                            
            # 计算所有时刻的频率相对于额定频率 (50Hz 或 60Hz) 的偏移量
            
            # 检查是否超出范围 (稳定性判断)
            is_stable = np.all((frequency_data >= FREQUENCY_MIN) &
                            (frequency_data <= FREQUENCY_MAX))
                            
            # 计算最大频率偏移 (报告指标)
            # 偏移量 = 实际频率 - 额定频率。我们关心的是最大的绝对偏差
            
            # 假设我们关注的是与额定频率的绝对最大偏差
            rated_freq = RATED_FREQUENCY
                
            # 计算绝对偏差的最大值
            max_freq_deviation = np.max(np.abs(frequency_data - rated_freq))
            
            if not is_stable:
                logger.warning(f'[check_frequency] 频率不合格 - 超出{FREQUENCY_MIN}-{FREQUENCY_MAX}Hz范围')
                return ServiceResult.success(message="频率检查未通过",data={"max_freq_deviation":max_freq_deviation})
            else:
                logger.info("[check_frequency] 频率检查通过")
                return ServiceResult.success(message="频率检查通过",data={"max_freq_deviation":max_freq_deviation})
            
        except Exception as e:
            logger.error(f"[check_frequency] 频率检查失败: {str(e)}", exc_info=True)
            return ServiceResult.failed(message=f"频率检查失败,内部错误: {str(e)}")

            

    def _build_local_path(self,object_name: str) -> str:

        # 获取当前工作目录作为默认值
        work_dir = os.getcwd()
        base_dir = safe_get_env("LOCAL_SAVE_DIR", os.path.join(work_dir, "outputs"))

        local_path = os.path.normpath(os.path.join(base_dir, object_name))
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        return local_path
    def _create_or_append_hdf5_dataset(
        self,
        group: h5py.Group,
        dataset_name: str,
        data: np.ndarray
    ) -> None:
        """
        在HDF5组中创建或追加数据集

        Args:
            group: HDF5组对象
            dataset_name: 数据集名称
            data: 要保存的数据
        """
        if dataset_name in group:
            dataset = group[dataset_name]
            old_shape = dataset.shape
            new_shape = (old_shape[0] + data.shape[0],) + dataset.shape[1:]
            dataset.resize(new_shape)
            dataset[old_shape[0]:] = data
        else:
            group.create_dataset(
                dataset_name,
                data=data,
                maxshape=(None,) + data.shape[1:],
                chunks=True
            )
    def _save_emt_to_hdf5_local(
        self,
        object_path: str,
        initial_state: List[Any],
        all_data: List
    ) -> str:
        """
        将暂态仿真结果保存到本地的 HDF5 文件（独立函数，无锁）

        Args:
            object_path: 本地对象路径
            initial_state: 初始状态标识
            bus_voltage_data: 母线电压数据
            power_data: 功率数据
            frequency_data: 频率数据
            power_angle_data: 功角数据

        Returns:
            保存成功的本地路径
        """
        local_path = self._build_local_path(object_path)

        with h5py.File(local_path, "a") as f:
            group_name = str(initial_state)

            if group_name not in f:
                grp = f.create_group(group_name)
            else:
                grp = f[group_name]

            for emt_data in all_data:
                dataset_name = emt_data["name"]
                data = emt_data["value"]
                self._create_or_append_hdf5_dataset(grp, dataset_name, data[None, ...])

        return local_path
    def _decode_dict_tool(self, data_dict, code_mapping):
        """
        解码字典，将编码值转换为实际值。

        Parameters
        ----------
        data_dict : dict
            要解码的数据字典
        code_mapping : dict
            编码映射字典

        Returns
        -------
        dict
            解码后的字典
        """
        decoded = {}
        for key, value_dict in data_dict.items():
            v_key, v_value = next(iter(value_dict.items()))
            if isinstance(v_value, list):
                # 跳过 list 类型的 value
                continue
            mapping = code_mapping.get(key, {})
            decoded[key] = {v_key: mapping.get(v_value, v_value)}
        return decoded
