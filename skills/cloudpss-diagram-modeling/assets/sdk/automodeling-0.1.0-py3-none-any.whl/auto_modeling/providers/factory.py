from .manager import CloudPSSProvider 

class ProviderFactory:
    @staticmethod
    def create_provider(config: dict):
        platform_type = config.get("platform_type", "ansys").lower()
        
        if platform_type == "cloudpss":
            return CloudPSSProvider(config.get("cloudpss_settings", {}))
        else:
            raise ValueError(f"Unsupported platform: {platform_type}")