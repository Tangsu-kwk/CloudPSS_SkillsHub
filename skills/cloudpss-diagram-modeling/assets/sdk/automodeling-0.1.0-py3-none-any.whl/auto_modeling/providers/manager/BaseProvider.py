from abc import ABC, abstractmethod
from auto_modeling.contracts import BaseModelEdit, BaseModelObservation, BaseSimulationAnalysis, BaseExtension


class BaseProvider(ABC):
    """
    所有平台供应商的基类。
    它确保了无论切换到哪个平台，上层服务都能通过统一的属性访问对应的功能。
    """

    # 强制要求子类必须具备这些实例属性
    model_edit: BaseModelEdit
    model_observation: BaseModelObservation
    simulation_analysis: BaseSimulationAnalysis
    extension: BaseExtension



    @abstractmethod
    def __init__(self, config: dict):
        """所有供应商必须通过 config 初始化"""
        pass