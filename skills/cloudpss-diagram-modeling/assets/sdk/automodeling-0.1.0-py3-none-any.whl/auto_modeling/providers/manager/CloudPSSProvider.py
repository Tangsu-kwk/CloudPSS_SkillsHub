import copy
import json
import time
import functools
from pathlib import Path
import os
import logging

import cloudpss
from .BaseProvider import BaseProvider
from auto_modeling.providers import CloudPSSModelEdit,CloudPSSExtension,CloudPSSModelObservation,CloudPSSSimulationAnalysis

from auto_modeling.core.cloudpss import MappingManager, HistoryManager


logger = logging.getLogger(__name__)

BUS_RID = 'model/CloudPSS/_newBus_3p'


class CloudPSSProvider(BaseProvider):
    def __init__(self, config: dict):
        """
        初始化 CloudPSSProvider

        :param config: 初始化配置
        """
        logger.info("开始初始化 CloudPSSProvider...")
        self.cloudpss_api_url = config.get('api_url', 'https://cloudpss.net/')
        self.cloudpss_token = config.get('token')
        self.cloudpss_model = config.get('model')
        self.auto_save = bool(config.get('auto_save', False))
        self.auto_save_name = config.get('auto_save_name', 'test_tool')

        if not self.cloudpss_token or not self.cloudpss_model:
            raise ValueError("requires 'token' and 'model' in config")

        # 在构造函数中初始化所有实例属性
        self.comp_library = {}
        self.model = None
        self.topo = None

        logger.info(
            "配置加载完成: api_url=%s, model=%s",
            self.cloudpss_api_url,
            self.cloudpss_model,
        )
        self._init_cloudpss_env()

        # 初始化映射管理组件
        self.mapping_manager = MappingManager(self.model)

        # 初始化历史记录管理器
        self.history_manager = HistoryManager(max_history=100)
        logger.info("历史记录管理器初始化完成")

        # 初始化功能组件
        self.model_edit = CloudPSSModelEdit(
            model=self.model,
            # comp_library=self.comp_library,
            mapping_manager=self.mapping_manager,
            history=self.history_manager
        )
        self.model_observation = CloudPSSModelObservation(self.model, self.mapping_manager)
        self.simulation_analysis = CloudPSSSimulationAnalysis(self.model)

        # 初始化平台扩展功能
        self.extension = CloudPSSExtension(self.model_edit)
        logger.info("CloudPSS 平台扩展功能初始化完成")

        if self.auto_save:
            self._enable_auto_save()

        logger.info("CloudPSSProvider 初始化完成。")

    def _init_cloudpss_env(self):
        """
        初始化 CloudPSS 环境

        :return: None
        """
        # 初始化 CloudPSS 环境
        logger.info("初始化 CloudPSS 环境...")
        cloudpss.setToken(self.cloudpss_token)
        os.environ['CLOUDPSS_API_URL'] = self.cloudpss_api_url
        self.model = cloudpss.Model.fetch(self.cloudpss_model)
        logger.info("CloudPSS 模型获取成功。")


    # ------测试用，后续删除------
    def _enable_auto_save(self):
        """
        启用自动保存

        :return: None
        """
        logger.info("已启用自动保存: name=%s", self.auto_save_name)
        self._wrap_methods_for_auto_save(self.model_edit)
        self._wrap_methods_for_auto_save(self.extension)

    def _wrap_methods_for_auto_save(self, target_obj):
        """
        为目标对象的方法包装自动保存逻辑

        :param target_obj: 目标对象
        :return: None
        """
        for attr_name in dir(target_obj):
            if attr_name.startswith("_"):
                continue
            attr = getattr(target_obj, attr_name, None)
            if not callable(attr):
                continue
            if getattr(attr, "__auto_save_wrapped__", False):
                continue

            @functools.wraps(attr)
            def _wrapped(*args, __attr=attr, **kwargs):
                result = __attr(*args, **kwargs)
                self._auto_save_if_needed(result)
                return result

            _wrapped.__auto_save_wrapped__ = True
            setattr(target_obj, attr_name, _wrapped)

    def _auto_save_if_needed(self, result):
        """
        根据执行结果自动保存模型

        :param result: 方法执行结果
        :return: None
        """
        if not self.auto_save:
            return
        status = getattr(result, "status", None)
        if status not in (None, "success", "partial_success"):
            return
        try:
            self.model.save(self.auto_save_name)
            logger.info("模型已自动保存: %s", self.auto_save_name)
        except Exception as exc:
            logger.warning("模型自动保存失败: %s", exc)
