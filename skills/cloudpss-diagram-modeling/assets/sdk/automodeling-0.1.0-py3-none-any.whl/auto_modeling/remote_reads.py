"""GraphQL adapters for the four remote read MCP tools in this batch."""
from copy import deepcopy
import base64
import json
import os
import math
from .component_model import _error_diagnostics

ACCOUNT_QUERY = """query($input: AccountInput!) {
  account(input: $input) { name displayName type }
}"""
MEMBERSHIPS_QUERY = """query($input: AccountInput!) {
  account(input: $input) { name displayName type ... on AccountUser {
    ownerOf { name displayName type }
    moderatorOf { name displayName type }
    memberOf { name displayName type }
  } }
}"""
MODELS_QUERY = """query($input: ModelsInput!) {
  models(input: $input) { items { rid name description tags keywords } cursor count total }
}"""
MODEL_METADATA_QUERY = '''query ComponentSearchUsedModel($rid:ResourceId!){
  model(input:{rid:$rid}){rid name description tags keywords}
}'''
TEMPLATE_OWNERS = ("CloudPSS", "open-cloudpss", "CloudPSSIESSimulation",
                   "IESLabPlan", "DSlab", "IESLabOpt")

class RemoteReadError(RuntimeError):
    def __init__(self, message, graphql_errors=None):
        super().__init__(message)
        self.graphql_errors = graphql_errors

def _request(query, variables, requester=None):
    if requester is None:
        from cloudpss.utils import graphql_request
        requester = graphql_request
    try:
        response = requester(query, variables, timeout=30)
    except Exception as exc:
        # SDK raises HTTPError before parsing GraphQL validation errors (400).
        # Preserve structured service diagnostics; never expose request headers.
        try:
            response=exc.response.json()
        except Exception:
            response=None
        if not isinstance(response,dict) or not response.get('errors'):
            raise RemoteReadError("GraphQL request failed; check connectivity, API URL and API token") from None
    if not isinstance(response, dict):
        raise RemoteReadError("Invalid GraphQL response")
    if response.get("errors"):
        raise RemoteReadError("GraphQL returned errors", _error_diagnostics(response["errors"]))
    if not isinstance(response.get("data"), dict):
        raise RemoteReadError("Invalid GraphQL response: missing data")
    return response["data"]

def get_account(*, requester=None):
    data = _request(ACCOUNT_QUERY, {"input": {"name": _current_user_name()}}, requester)
    account = data.get("account")
    if account is None:
        return None
    if not isinstance(account, dict) or any(type(account.get(k)) is not str for k in ("name", "displayName", "type")):
        raise RemoteReadError("Invalid account response")
    return {"name": account["name"], "display_name": account["displayName"], "type": account["type"]}

def _current_user_name():
    token = os.environ.get("CLOUDPSS_TOKEN", "").strip()
    if not token:
        raise RemoteReadError("CLOUDPSS_TOKEN is required to identify the current account")
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        value = json.loads(base64.urlsafe_b64decode(payload).decode("utf-8"))
        name = value.get("username")
    except Exception:
        name = None
    if not isinstance(name, str) or not name:
        raise RemoteReadError("CloudPSS token does not contain a username")
    return name

def list_accounts(*, requester=None):
    """Self, owned groups, moderated groups, member groups in source order.

    Preserve repeated memberships across roles, as the official client does.
    Query the token-identified account directly: accountToken requires browser
    authentication on deployments where API tokens cannot resolve that field.
    """
    account = _request(MEMBERSHIPS_QUERY, {"input": {"name": _current_user_name()}}, requester).get("account")
    if not isinstance(account, dict) or any(type(account.get(k)) is not str for k in ("name", "type")):
        raise RemoteReadError("Invalid account response")
    def project(item, role):
        if not isinstance(item, dict) or not isinstance(item.get('name'), str) or not isinstance(item.get('type'), str):
            raise RemoteReadError('Invalid organization membership data')
        return {'name':item['name'], 'display_name':item.get('displayName')
                if item.get('displayName') is not None else item['name'], 'type':item['type'], 'role':role}
    result = [project(account, 'OWNER')]
    for field, role in (("ownerOf", "OWNER"), ("moderatorOf", "MODERATOR"), ("memberOf", "MEMBER")):
        groups = account.get(field)
        if not isinstance(groups, list):
            raise RemoteReadError("Missing organization membership data")
        result.extend(project(item, role) for item in groups)
    return result

def _condition(value):
    if isinstance(value, list):
        if not value or value[0] != 'or' or any(not isinstance(v, str) for v in value[1:]):
            raise ValueError("owner condition must be a string or ['or', ...]")
        return value
    if not isinstance(value, str):
        raise TypeError("condition must be a string or list")
    return value

def list_projects(filter, *, limit=25, cursor=None, requester=None):
    """Official personal/shared/public/template filters and transparent cursor.

    Search uses the official browser client's _search input, verified against MCP.
    Presets use archived resolveResourceFilter, including the six configured
    template owners. No template tag is invented from the prose description.
    """
    if limit is None: limit = 25
    if type(limit) not in (int,float) or not math.isfinite(limit):
        raise TypeError('limit must be a finite number or None')
    if cursor is not None and not isinstance(cursor,list):
        raise TypeError('cursor must be a list or None')
    if isinstance(filter, str):
        if filter == 'personal':
            fields = {'owner': _current_user_name()}
        elif filter == 'shared':
            username = _current_user_name()
            owners = [a['name'] for a in list_accounts(requester=requester) if a['name'] != username]
            if not owners:
                return {'items': [], 'total': 0, 'cursor': []}
            fields = {'owner': ['or', *owners]}
        elif filter == 'public':
            fields = {'permissionEveryone': ['b_any', 2]}
        elif filter == 'template':
            fields = {'owner': ['or', *TEMPLATE_OWNERS], 'access': {'permission': 2}}
        else:
            raise ValueError('Unknown project filter preset')
    elif isinstance(filter, dict):
        if set(filter) - {"search", "owner"}:
            raise TypeError("project filter supports search and owner")
        fields = {}
        if "search" in filter:
            if not isinstance(filter["search"], str): raise TypeError("search must be a string")
            if filter["search"]: fields["_search"] = filter["search"]
        if "owner" in filter: fields["owner"] = _condition(filter["owner"])
    else:
        raise TypeError("filter must be a preset or object")
    if int(limit) == limit:
        limit = int(limit)
    # The MCP schema permits fractional/zero/negative numbers and arbitrary
    # JSON cursor elements. Forward them; preserve the service's own errors.
    inp = {"orderBy": ["updatedAt<", "owner", "key"], "limit": limit, **fields}
    if cursor is not None: inp["cursor"] = deepcopy(cursor)
    data = _request(MODELS_QUERY, {"input": inp}, requester)
    page = data.get("models")
    if not isinstance(page, dict) or not isinstance(page.get("items"), list): raise RemoteReadError("Invalid projects response")
    unique={}
    for item in page['items']:
        if not isinstance(item,dict) or not isinstance(item.get('rid'),str):
            raise RemoteReadError('Invalid project item')
        unique.setdefault(item['rid'],item)
    duplicates=len(page['items'])-len(unique)
    return {"items": [{k:deepcopy(x[k]) for k in ('rid','name','description') if k in x} for x in unique.values()],
            "total": page.get("total")-duplicates if duplicates else page.get('total'), "cursor": deepcopy(page.get("cursor"))}

def find_component_models(keywords, *, subscribedOnly=False, official=None, model=None, requester=None, catalogue=None):
    """Weighted official multi-keyword search over a detached model catalogue.

    ``catalogue`` optionally supplies an ordered local metadata snapshot. Without
    it, fetch every page independently through GraphQL. No browser is required.
    """
    if not isinstance(keywords, list) or any(not isinstance(k, str) for k in keywords): raise TypeError("keywords must be a list of strings")
    if subscribedOnly is None: subscribedOnly=False
    if type(subscribedOnly) is not bool or (official is not None and type(official) is not bool): raise TypeError("flags must be booleans")
    if not any(keywords): return []
    if model is None:
        raise ValueError("model is required for current document library context")
    subscriptions = model.context.get("groupSubscriptions")
    if not isinstance(subscriptions, list): raise RemoteReadError("Missing document library subscriptions")
    if any(not isinstance(s,dict) for s in subscriptions):
        raise RemoteReadError('Invalid document library subscriptions')
    from .component_subscriptions import official_subscriptions
    supported = [s['key'] for s in official_subscriptions()]
    # Registry insertion order resolves score ties. Official service loads the
    # official pool first, then user-provided models; each uses updatedAt<.
    inp = {"orderBy": ["updatedAt<"], "limit": 1000000,
           'tags':'project-category:component', 'access': {"permission": 65536}}
    if catalogue is None:
        registry={};cursors=set()
        # The official registry inserts nonofficial definitions used by cells
        # first, even if their category/access excludes them from pool queries.
        document=model.toJSON()
        cells=document.get('revision',{}).get('implements',{}).get('diagram',{}).get('cells',{})
        used=dict.fromkeys(c.get('definition') for c in cells.values() if isinstance(c,dict)
                           and isinstance(c.get('definition'),str) and len(c['definition'].split('/'))==3
                           and c['definition'].startswith('model/')
                           and c['definition'].split('/')[1].lower() not in {o.lower() for o in TEMPLATE_OWNERS})
        for rid in used:
            item=_request(MODEL_METADATA_QUERY,{'rid':rid},requester).get('model')
            if item is None:continue
            if not isinstance(item,dict) or item.get('rid')!=rid:
                raise RemoteReadError('Invalid used component model response')
            registry[rid]=item
        for owner in (['or',*TEMPLATE_OWNERS],['not',['or',*TEMPLATE_OWNERS]]):
            inputs={**inp,'owner':owner};cursors=set();received=0
            for _ in range(10000):
                page=_request(MODELS_QUERY,{'input':deepcopy(inputs)},requester).get('models')
                if (not isinstance(page,dict) or not isinstance(page.get('items'),list)
                    or type(page.get('count')) is not int or type(page.get('total')) is not int
                    or page['count']!=len(page['items']) or min(page['count'],page['total'])<0):
                    raise RemoteReadError('Invalid component model response')
                for item in page['items']:
                    if not isinstance(item,dict) or not isinstance(item.get('rid'),str):
                        raise RemoteReadError('Invalid component model item')
                    # Map.set replaces metadata while retaining insertion order.
                    registry[item['rid']]=item
                received+=page['count']
                if page['count']==0 and received<page['total']:
                    raise RemoteReadError('Catalogue incomplete; empty page with remaining models')
                if received>=page['total']:break
                cursor=page.get('cursor')
                if not isinstance(cursor,list) or not cursor:
                    raise RemoteReadError('Catalogue incomplete; missing next cursor')
                marker=json.dumps(cursor,sort_keys=True)
                if marker in cursors:raise RemoteReadError('Catalogue incomplete; repeated cursor')
                cursors.add(marker);inputs['cursor']=deepcopy(cursor)
            else:raise RemoteReadError('Catalogue page limit exceeded')
        catalogue=list(registry.values())
    if not isinstance(catalogue,list):raise TypeError('catalogue must be a list')
    cleaned=[];groups=set()
    for item in catalogue:
        if not isinstance(item,dict) or not isinstance(item.get('rid'),str) or len(item['rid'].split('/'))!=3:
            raise RemoteReadError('Invalid component model item')
        tags=item.get('tags') or []
        if not isinstance(tags,list) or any(not isinstance(t,str) for t in tags):
            raise RemoteReadError('Invalid component model tags')
        owner=item['rid'].split('/')[1]
        tags=[t for t in tags if not t.startswith('project-group:') or '/' not in t.split(':')[1]
              or t.split(':')[1].split('/')[0]==owner]
        groups.update(t.split(':')[1] for t in tags if t.startswith('project-group:') and t.split(':')[1])
        cleaned.append((item,tags))
    visible=[]
    if subscribedOnly:
        username=_current_user_name()
        defaults=official_subscriptions()+[{'key':g,'type':'self','visible':True}
                                           for g in groups if g.startswith(username+'/')]
        for default in defaults:
            stored=next((s for s in subscriptions if s.get('key')==default['key'] and s.get('type')==default['type']),default)
            if stored.get('visible'):
                visible.append(default['key'] if default['type']=='official' else 'project-group:'+default['key'])
        visible.extend('project-group:'+s['key'] for s in subscriptions
                       if s.get('type')=='thirdParty' and s.get('key') in groups and s.get('visible'))
    terms=[k.lower() for k in keywords if k]
    def length(value):return len(value.encode('utf-16-le','surrogatepass'))/2
    def score(text):
        if not text:return 0
        total=0;lower=text.lower()
        for term in terms:
            if text==term:total+=5
            elif text.startswith(term) or text.endswith(term):total+=2*length(term)/length(text)
            elif term in lower:total+=length(term)/length(text)
        return total
    ranked=[]
    for item,tags in cleaned:
        support_tags = [t for t in tags if t.startswith("project-support:")]
        if support_tags and not any(t in supported for t in support_tags): continue
        if 'project-support:job-definition/cloudpss/ies-simulation' in tags:continue
        owner=item['rid'].split('/')[1]
        if subscribedOnly and visible and not any(t in visible for t in tags): continue
        is_official = owner.lower() in {o.lower() for o in TEMPLATE_OWNERS}
        if official is True and not is_official: continue
        if official is False and is_official: continue
        value=score(item['rid'])*10+score(item.get('name'))*5+score(item.get('description'))
        if value>0 and is_official:value*=3
        if value>0:ranked.append((value,item))
    ranked.sort(key=lambda pair:-pair[0])
    result=[]
    for value,item in ranked:
        if len(result)>=10 and value<10:break
        result.append({k:deepcopy(item[k]) for k in ('rid','name','description') if k in item})
    return result
