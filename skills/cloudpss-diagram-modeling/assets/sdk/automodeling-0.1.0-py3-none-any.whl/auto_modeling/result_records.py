"""SDK-owned receiver records, following official 53788/804 storage rules.

These are new local observations, never reconstructed browser history. Raw
transport messages remain unchanged and are stored separately by JobResults.
"""
from copy import deepcopy
from datetime import datetime, timezone
import secrets
import string


def receiver_records(messages, received_at=None, *, previous_raw=None, previous_records=None):
    """Assign stable identities, retaining an unchanged replay prefix.

    Independent reads replay the stream from the beginning. Preserve existing
    identities only while the raw prefix matches; divergence establishes a new
    observation. IDs count all stored v1 messages, not just filtered logs.
    """
    previous_raw = previous_raw or []
    previous_records = previous_records or []
    previous = iter(previous_records)
    prefix = True
    output = []
    for index, raw in enumerate(messages):
        prefix = prefix and index < len(previous_raw) and raw == previous_raw[index]
        if raw.get('version') != 1 or raw.get('type') == 'progress': continue
        old = next(previous, None) if prefix else None
        if old is not None:
            output.append(deepcopy(old))
            continue
        message = {'verb':'', **deepcopy(raw)}
        message.pop('id', None)
        if message.get('type') == 'terminate':
            data = message['data']
            if data.get('succeeded') is not None and not data.get('status'):
                data['status'] = 'resolved' if data['succeeded'] else 'rejected'
        stamp = received_at[index] if received_at is not None and index < len(received_at) else None
        message['when'] = stamp or datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        message['sender'] = message.get('sender') or 'remote'
        message['key'] = message.get('key') or ''.join(secrets.choice(string.ascii_letters+string.digits) for _ in range(24))
        message['id'] = len(output) + 1
        output.append(message)
    return output
