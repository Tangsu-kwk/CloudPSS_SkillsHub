﻿"""Known scheduler callbacks from SimStudio modules 73251/65628/2928.

Policies are explicit browser-compatible snapshots (queue, tres list,
minPriority/maxPriority, functions and users). No network reads occur here.
"""
from copy import deepcopy
import math
from .job_inputs import _resource_policy, JobInputError, _js_truth
from .parameter_checks import _number, _strict_equal, _string

QUEUE_MESSAGE='没有可用于此函数的队列，请联系管理员'
RESOURCE_MESSAGE='没有可用于此函数的计算资源组合，请联系管理员'
CPU_MESSAGE='核心数应小于等于计算资源中配置的值'


def parse_tres(value):
    try:return _resource_policy(value)
    except JobInputError:return None


def format_tres(value):
    return ' '.join(f'{k}={_string(value.get(k,0))}' for k in ('cpu','ecpu','mem') if value.get(k)) or 'cpu=0'


def _accessible(policy):
    return policy.get('users') is None or len(policy['users'])>0


def validate_runtime(runtime):
    if runtime is None:return
    if not isinstance(runtime,dict) or set(runtime)!={'policies'} or not isinstance(runtime['policies'],list):
        raise TypeError('runtime must contain an explicit policies list')
    for p in runtime['policies']:
        if (not isinstance(p,dict) or not isinstance(p.get('queue'),dict) or 'id' not in p['queue']
                or not isinstance(p.get('tres'),list)
                or any(not isinstance(t,dict) or set(t)!={'cpu','ecpu','mem'} for t in p['tres'])
                or type(p.get('minPriority')) not in (int,float) or type(p.get('maxPriority')) not in (int,float)
                or any(p.get(k) is not None and not isinstance(p[k],list) for k in ('users','functions'))):
            raise TypeError('runtime policy requires queue, tres, minPriority/maxPriority and optional lists')
        if not math.isfinite(p['minPriority']) or not math.isfinite(p['maxPriority']):
            raise TypeError('runtime priority endpoints must be finite')
        if any(type(t[k]) not in (int,float) or not math.isfinite(t[k]) or t[k]<0
               for t in p['tres'] for k in ('cpu','ecpu','mem')):
            raise TypeError('runtime resource values must be nonnegative finite numbers')


def _scheduler(runtime,rid,args):
    policies=[p for p in runtime['policies'] if p.get('functions') is None or rid in p['functions']]
    usable=any(_accessible(p) for p in policies)
    queue_choices=[]
    for p in policies:
        item=next((c for c in queue_choices if _strict_equal(c['key'],p['queue']['id'])),None)
        if item is None:
            item={'key':p['queue']['id'],'condition':False};queue_choices.append(item)
        item['condition']=item['condition'] or _accessible(p)
    selected=args.get('@queue')
    matching=[p for p in policies if _strict_equal(p['queue']['id'],selected)]
    resources={}
    if _js_truth(selected) and any(_accessible(p) for p in matching):
        for p in matching:
            for tres in p['tres']:
                key=format_tres(tres)
                resources[key]=resources.get(key,False) or _accessible(p)
    resource_choices=[{'key':k,'condition':v} for k,v in resources.items()]
    resource_choices.sort(key=lambda c:tuple(parse_tres(c['key'])[k] for k in ('cpu','ecpu','mem')))
    selected_tres=parse_tres(args.get('@tres'));ranges=[]
    if _js_truth(selected) and selected_tres is not None:
        for p in matching:
            if _accessible(p) and selected_tres in p['tres']:ranges.append([p['minPriority'],p['maxPriority']])
    merged=[]
    for lo,hi in sorted(ranges,key=lambda pair:pair[0]):
        if merged and lo<=merged[-1][1]:merged[-1][1]=max(hi,merged[-1][1])
        else:merged.append([lo,hi])
    return usable,queue_choices,resource_choices,merged


def resolve_runtime_field(field,*,runtime,rid,args,value):
    """Replace only recognized serialized callbacks; report other missing code."""
    result=deepcopy(field);key=field['key'];pending=[]
    callbacks={('@queue','choice'):QUEUE_MESSAGE,('@tres','choice'):RESOURCE_MESSAGE,
               ('@priority','real'):'value not in range',('n_cpu','integer'):CPU_MESSAGE}
    expected=callbacks.get((key,field.get('type')))
    for i,rule in enumerate(result.get('constraints') or []):
        if not isinstance(rule,dict) or 'condition' in rule:continue
        if expected is None or rule.get('message')!=expected or (key!='n_cpu' and runtime is None):
            pending.append(i);continue
        if key=='n_cpu':
            tres=parse_tres(args.get('@tres'))
            rule['condition']=tres is None or tres['cpu']==0 or _number(value)<=tres['cpu']
        else:
            usable,queues,resources,ranges=_scheduler(runtime,rid,args)
            if key in ('@queue','@tres'):
                result['choices']=queues if key=='@queue' else resources
                result['_runtime_dynamic_choice']=True
                rule['condition']=usable
            else:
                number=_number(value)
                rule['condition']=math.isfinite(number) and (not ranges or any(lo<=number<=hi for lo,hi in ranges))
                rule['messageData']={'range':', '.join(f'{_string(lo)}~{_string(hi)}' for lo,hi in ranges)} if ranges else {}
        rule['_runtime_resolved']=True
    return result,pending
