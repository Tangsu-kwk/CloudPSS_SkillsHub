"""Detached in-memory scenarios. Submission and persistence stay explicit."""
from copy import deepcopy
from .component_args import update_diagram_components_args


class ScenarioSet:
    """Build independent SDK models from one immutable baseline snapshot.

    patches maps component IDs to parameter dictionaries, preserving expression
    values. This class does not save projects or create remote tasks.
    """

    def __init__(self, model, *, definition_resolver=None):
        self._baseline = deepcopy(model.toJSON())
        self._definition_resolver = definition_resolver

    def build(self, patches):
        from cloudpss import Model
        scenario = Model(deepcopy(self._baseline))
        for component_id, values in patches.items():
            update_diagram_components_args(scenario, [component_id], values,
                                           definition_resolver=self._definition_resolver)
        return scenario

    def build_batch(self, specifications):
        """Return named independent scenarios; no shared mutable model state."""
        return {name: self.build(patches) for name, patches in specifications.items()}
