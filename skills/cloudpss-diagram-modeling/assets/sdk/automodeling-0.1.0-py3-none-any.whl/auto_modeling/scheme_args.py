"""Official edit-time default conversion and __fill_args, without evaluation.

Source: SimStudio 5.0.39 modules 14366 and 4fa21a50dd902b02d701.
Constraints and conditions belong to validation/UI, not these write handlers.
"""
from copy import deepcopy
from .job_inputs import _convert, _expression, _fields, _json_numbers, _KINDS

_UNDEFINED = object()


def _converted(value, field):
    # Unknown future field types use the official identity/fallback converter.
    try:
        return _convert(value, field, None)
    except NotImplementedError:
        if field.get("type") not in _KINDS:
            return deepcopy(value)
        raise


def _default_args(parameters, args):
    if not isinstance(args, dict):
        raise TypeError("Updating must be a record")
    fields = _fields(parameters)
    result = deepcopy(args)
    if not parameters:
        return result
    original_keys = set(result)
    for field in fields:
        key = field["key"]
        value = result.get(key) if key in original_keys else None
        if value is None:
            if "value" not in field:
                value = _UNDEFINED
            else:
                value = deepcopy(field["value"])
            if _expression(value):
                value = {"source": value.get("source"), "ɵexp": ""}
            else:
                converted = _converted(None if value is _UNDEFINED else value, field)
                if converted is not None:
                    value = converted
        elif not _expression(value):
            converted = _converted(value, field)
            if converted is not None:
                value = converted
        if value is _UNDEFINED:
            result.pop(key, None)
        else:
            result[key] = value
        original_keys.discard(key)
    for key in original_keys:
        if not key.startswith(("_", "$", "@", "ɵ")):
            del result[key]
    return result


def default_args(parameters, args):
    """Detached JSON-visible defaultArgs; preserve expressions unevaluated."""
    return _json_numbers(_default_args(parameters, args))


def _kind(value):
    if value is None:
        return "nil"
    return {bool: "boolean", int: "number", float: "number", str: "string",
            list: "array", dict: "record"}.get(type(value), type(value).__name__)


def fill_args(original, updating, parameters):
    """Validate supplied keys/types, convert values, preserve unspecified keys.

    A default expression also bypasses the type check, as in official __fill_args.
    No defaults are inserted for omitted update keys; no expressions execute.
    """
    if not isinstance(original, dict):
        raise TypeError("Original must be a record")
    if not isinstance(updating, dict):
        raise TypeError("Updating must be a record")
    if any(not isinstance(k, str) for k in updating):
        raise TypeError("Argument keys must be strings")
    defaults = _default_args(parameters, {})
    converted = _default_args(parameters, updating)
    result = deepcopy(original)
    for key, value in updating.items():
        if key not in defaults:
            raise ValueError(f"Unknown argument: {key}")
        default = defaults[key]
        if _expression(value) or _expression(default):
            result[key] = deepcopy(value)
            continue
        actual, expected = _kind(value), _kind(default)
        if actual != expected:
            raise ValueError(f"Argument {key} has invalid type: expected {expected}, got {actual}")
        result[key] = deepcopy(converted[key])
    return _json_numbers(result)
