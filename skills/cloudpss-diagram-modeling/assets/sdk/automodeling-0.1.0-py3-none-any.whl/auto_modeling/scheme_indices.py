"""MiraScript numeric list reads versus document field-path writes."""
from copy import deepcopy
import math


def numeric_index(index):
    if type(index) not in (int, float) or not math.isfinite(index):
        raise TypeError("scheme index must be a finite number")
    return math.trunc(index)


def read_index(items, index, kind):
    position = numeric_index(index)
    if position < 0:
        position += len(items)
    if not 0 <= position < len(items):
        raise IndexError(f"panic: {kind} index {index} out of range")
    return position


def write_index(items, index, value):
    # dangerously_set_field interpolates the ORIGINAL number into a dot path.
    # Thus 1.5 writes items[1]['5']; -1 reads the last item but writes nothing.
    from decimal import Decimal
    number = float(index)
    if number == 0:
        text = "0"
    elif 1e-6 <= abs(number) < 1e21:
        text = format(Decimal(repr(number)), "f")
        if "." in text:
            text = text.rstrip("0").rstrip(".")
    else:
        mantissa, exponent = format(Decimal(repr(number)).normalize(), "e").split("e")
        text = mantissa + "e" + ("+" if int(exponent) >= 0 else "-") + str(abs(int(exponent)))
    path = text.split(".")
    if not path[0].isdigit() or int(path[0]) >= len(items):
        return
    position = int(path[0])
    if len(path) == 1:
        items[position] = deepcopy(value)
    else:
        items[position][path[1]] = deepcopy(value)
