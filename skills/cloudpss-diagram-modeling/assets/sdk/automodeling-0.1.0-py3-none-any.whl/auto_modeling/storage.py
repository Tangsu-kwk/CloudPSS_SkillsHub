"""Standalone REST storage adapters, based on official public client module 87559.

Uses SDK environment configuration, never browser cookies or MCP sessions.
Uploading writes remote storage; no upload is automatically retried.
"""
import base64
import binascii
import os
import re
from urllib.parse import quote, unquote_to_bytes, urljoin, urlsplit

MAX_BYTES = 16 * 1024 * 1024
_PREFIX = "/api/storage/"
_HASH = re.compile(r"[a-zA-Z0-9_-]{64}\Z")


class StorageError(RuntimeError):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


def _hash(value):
    if not isinstance(value, str):
        raise TypeError("The url must be a string")
    candidate = value[len(_PREFIX):] if value.startswith(_PREFIX) else value
    # Only storage URLs accept fragments; a bare hash must be exactly 64 chars.
    if value.startswith(_PREFIX):
        candidate = candidate.split("#", 1)[0]
    if not _HASH.fullmatch(candidate):
        raise TypeError(f"Invalid storage url or hash: {value}")
    return candidate


def _request(method, url, *, requester, **kwargs):
    if requester is None:
        import requests
        requester = requests.request
    try:
        return requester(method, url, timeout=30, allow_redirects=False, **kwargs)
    except Exception:
        raise StorageError("Storage transport failed; check connectivity and SDK configuration") from None


def _target(base_url, token):
    base = base_url if base_url is not None else os.environ.get("CLOUDPSS_API_URL", "https://cloudpss.net/")
    secret = token if token is not None else os.environ.get("CLOUDPSS_TOKEN")
    parsed = urlsplit(base)
    if parsed.scheme not in ("http", "https") or not parsed.netloc or parsed.username or parsed.password:
        raise ValueError("Invalid CloudPSS API URL")
    if not isinstance(secret, str) or not secret.strip():
        raise StorageError("CloudPSS SDK token is not configured")
    # SDK base is the site root; also accept an explicit /api/ base.
    api = base.rstrip("/") + "/"
    return urljoin(api, "storage" if parsed.path.rstrip("/").endswith("/api") else "api/storage"), {
        "Authorization": "Bearer " + secret}


def _status(response, *, missing=False):
    status = response.status_code
    if missing and status == 404:
        return False
    if not 200 <= status < 300:
        raise StorageError("Storage request failed" if status != 413 else "File is too large", status)
    return True


def _payload(payload, requester):
    if not isinstance(payload, str):
        raise TypeError("The payload must be a http(s)-url or a data-url")
    if payload.startswith("data:"):
        metadata, separator, encoded = payload[5:].partition(",")
        if not separator:
            raise ValueError("Malformed data URL")
        parts = metadata.split(";")
        mime = parts[0] or "text/plain"
        if parts[0] == "" and len(parts) == 1:
            mime += ";charset=US-ASCII"
        elif len(parts) > 1:
            mime += "".join(";" + p for p in parts[1:] if p.lower() != "base64")
        data = unquote_to_bytes(encoded)
        if parts[-1].lower() == "base64":
            try:
                data = re.sub(rb"[\t\n\f\r ]", b"", data)
                if len(data) % 4 == 1:
                    raise ValueError()
                data = base64.b64decode(data + b"=" * (-len(data) % 4), validate=True)
            except (binascii.Error, ValueError):
                raise ValueError("Malformed base64 data URL") from None
        if len(data) > MAX_BYTES:
            raise StorageError("File is too large", 413)
        return data, mime
    parsed = urlsplit(payload)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise TypeError("The payload must be a http(s)-url or a data-url")
    # Payload retrieval is public and must never receive the SDK token. Follow
    # redirects explicitly so every hop remains HTTP(S).
    url = payload
    for _ in range(6):
        response = _request("GET", url, requester=requester, stream=True)
        try:
            if response.status_code in (301, 302, 303, 307, 308):
                location = response.headers.get("Location")
                if not location:
                    raise StorageError("Payload redirect has no location")
                url = urljoin(url, location)
                if urlsplit(url).scheme not in ("http", "https"):
                    raise StorageError("Unsupported payload redirect")
                continue
            # Browser fetch().blob() does not reject an HTTP error body.
            mime = response.headers.get("Content-Type", "application/octet-stream")
            chunks, length = [], 0
            try:
                for chunk in response.iter_content(65536):
                    length += len(chunk)
                    if length > MAX_BYTES:
                        raise StorageError("File is too large", 413)
                    chunks.append(chunk)
            except StorageError:
                raise
            except Exception:
                raise StorageError("Payload download failed") from None
            return b"".join(chunks), mime
        finally:
            response.close()
    raise StorageError("Too many payload redirects")


def put_storage(payload, filename=None, *, requester=None, token=None, base_url=None):
    """Upload URL/data-URL bytes and return a relative storage link.

    Filename is a link fragment, not a multipart filename. Extra keyword
    arguments configure/test transport; ordinary usage reads SDK environment.
    """
    if filename is not None and not isinstance(filename, str):
        raise TypeError("The filename must be a string")
    url, headers = _target(base_url, token)
    data, mime = _payload(payload, requester)
    mime = mime.lower()
    if mime.startswith("application/json"):
        mime = "text/plain"
    elif mime.startswith("application/ubjson"):
        mime = "application/octet-stream"
    response = _request("PUT", url, requester=requester, headers={**headers, "Content-Type": mime}, data=data)
    try:
        _status(response)
        location = response.headers.get("Location", "")
        if "/storage/" not in location:
            raise StorageError("Invalid storage upload response")
        candidate = location.rsplit("/storage/", 1)[1][:64]
        if not _HASH.fullmatch(candidate):
            raise StorageError("Invalid storage upload response")
        result = _PREFIX + candidate
        return result + "#filename=" + quote(filename, safe="-_.!~*'()") if filename else result
    finally:
        response.close()


def check_storage(url, *, requester=None, token=None, base_url=None):
    """Return False only for HTTP 404; auth/network/server failures raise."""
    hash_value = _hash(url)
    target, headers = _target(base_url, token)
    response = _request("HEAD", target + "/" + hash_value, requester=requester, headers=headers)
    try:
        return _status(response, missing=True)
    finally:
        response.close()
